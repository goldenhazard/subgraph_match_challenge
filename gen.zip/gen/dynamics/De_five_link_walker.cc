/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:29:46 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1)
{
  double t12532;
  double t12438;
  double t12572;
  double t12587;
  double t12760;
  double t12763;
  double t12769;
  double t12805;
  double t12814;
  double t12904;
  double t12910;
  double t12952;
  double t12957;
  double t12968;
  double t12969;
  double t12973;
  double t12596;
  double t12728;
  double t12736;
  double t12575;
  double t12590;
  double t12592;
  double t12762;
  double t12765;
  double t12766;
  double t12768;
  double t12816;
  double t12857;
  double t12865;
  double t12866;
  double t12869;
  double t12870;
  double t12871;
  double t12872;
  double t12944;
  double t12945;
  double t12946;
  double t12906;
  double t12911;
  double t12912;
  double t12956;
  double t12960;
  double t12961;
  double t12962;
  double t12974;
  double t12975;
  double t12981;
  double t12982;
  double t12986;
  double t12988;
  double t12990;
  double t13023;
  double t13171;
  double t13172;
  double t13173;
  double t13179;
  double t13180;
  double t13181;
  double t13182;
  double t13183;
  double t13185;
  double t13186;
  double t13187;
  double t13224;
  double t13225;
  double t13226;
  double t13227;
  double t13228;
  double t13229;
  double t13230;
  double t13231;
  double t13233;
  double t13234;
  double t13235;
  double t13091;
  double t13092;
  double t13112;
  double t13113;
  double t13118;
  double t13119;
  double t13120;
  double t13121;
  double t13125;
  double t13126;
  double t13127;
  double t13128;
  double t13129;
  double t13130;
  double t13131;
  double t13132;
  double t13133;
  double t13153;
  double t13154;
  double t13155;
  double t13156;
  double t13157;
  double t13158;
  double t13159;
  double t13160;
  double t12445;
  double t12485;
  double t12569;
  double t12571;
  double t12753;
  double t12758;
  double t12947;
  double t12951;
  double t13165;
  double t13166;
  double t13167;
  double t13168;
  double t13169;
  double t13184;
  double t13188;
  double t13189;
  double t13191;
  double t13192;
  double t13193;
  double t13211;
  double t13215;
  double t13217;
  double t13219;
  double t13220;
  double t13232;
  double t13236;
  double t13237;
  double t13239;
  double t13240;
  double t13241;
  double t13255;
  double t13256;
  double t13257;
  double t13247;
  double t13250;
  double t13251;
  double t13252;
  double t13267;
  double t13268;
  double t13269;
  double t13262;
  double t13263;
  double t13264;
  double t13265;
  double t13161;
  double t13170;
  double t13190;
  double t13208;
  double t13223;
  double t13238;
  double t13244;
  double t13245;
  double t13290;
  double t13291;
  double t13292;
  double t13293;
  double t13294;
  double t13295;
  double t13296;
  double t13297;
  double t13246;
  double t13254;
  double t13258;
  double t13259;
  double t13298;
  double t13299;
  double t13302;
  double t13303;
  double t13325;
  double t13326;
  double t13327;
  double t13328;
  double t13260;
  double t13304;
  double t13329;
  double t13330;
  double t13342;
  double t13343;
  double t13261;
  double t13266;
  double t13270;
  double t13271;
  double t13305;
  double t13308;
  double t13309;
  double t13310;
  double t13331;
  double t13332;
  double t13333;
  double t13334;
  double t13272;
  double t13311;
  double t13335;
  double t13336;
  double t13349;
  double t13350;
  t12532 = Sin(var1[2]);
  t12438 = Cos(var1[2]);
  t12572 = Cos(var1[3]);
  t12587 = Sin(var1[3]);
  t12760 = Cos(var1[4]);
  t12763 = Sin(var1[4]);
  t12769 = t12572*t12760;
  t12805 = -1.*t12587*t12763;
  t12814 = t12769 + t12805;
  t12904 = Cos(var1[5]);
  t12910 = Sin(var1[5]);
  t12952 = Cos(var1[6]);
  t12957 = Sin(var1[6]);
  t12968 = t12904*t12952;
  t12969 = -1.*t12910*t12957;
  t12973 = t12968 + t12969;
  t12596 = t12438*t12572;
  t12728 = -1.*t12532*t12587;
  t12736 = t12596 + t12728;
  t12575 = t12572*t12532;
  t12590 = t12438*t12587;
  t12592 = t12575 + t12590;
  t12762 = -1.*t12760*t12587;
  t12765 = -1.*t12572*t12763;
  t12766 = t12762 + t12765;
  t12768 = t12532*t12766;
  t12816 = t12438*t12814;
  t12857 = t12768 + t12816;
  t12865 = t12760*t12587;
  t12866 = t12572*t12763;
  t12869 = t12865 + t12866;
  t12870 = t12438*t12869;
  t12871 = t12532*t12814;
  t12872 = t12870 + t12871;
  t12944 = t12438*t12904;
  t12945 = -1.*t12532*t12910;
  t12946 = t12944 + t12945;
  t12906 = t12904*t12532;
  t12911 = t12438*t12910;
  t12912 = t12906 + t12911;
  t12956 = -1.*t12952*t12910;
  t12960 = -1.*t12904*t12957;
  t12961 = t12956 + t12960;
  t12962 = t12532*t12961;
  t12974 = t12438*t12973;
  t12975 = t12962 + t12974;
  t12981 = t12952*t12910;
  t12982 = t12904*t12957;
  t12986 = t12981 + t12982;
  t12988 = t12438*t12986;
  t12990 = t12532*t12973;
  t13023 = t12988 + t12990;
  t13171 = -1.*t12760;
  t13172 = 1. + t13171;
  t13173 = 0.4*t13172;
  t13179 = 0.64*t12760;
  t13180 = t13173 + t13179;
  t13181 = t13180*t12587;
  t13182 = 0.24*t12572*t12763;
  t13183 = t13181 + t13182;
  t13185 = t12572*t13180;
  t13186 = -0.24*t12587*t12763;
  t13187 = t13185 + t13186;
  t13224 = -1.*t12952;
  t13225 = 1. + t13224;
  t13226 = 0.4*t13225;
  t13227 = 0.64*t12952;
  t13228 = t13226 + t13227;
  t13229 = t13228*t12910;
  t13230 = 0.24*t12904*t12957;
  t13231 = t13229 + t13230;
  t13233 = t12904*t13228;
  t13234 = -0.24*t12910*t12957;
  t13235 = t13233 + t13234;
  t13091 = -1.*t12572*t12532;
  t13092 = -1.*t12438*t12587;
  t13112 = t13091 + t13092;
  t13113 = 6.8*t13112*t12736;
  t13118 = 6.8*t12592*t12736;
  t13119 = t12438*t12766;
  t13120 = -1.*t12532*t12814;
  t13121 = t13119 + t13120;
  t13125 = 3.2*t12857*t13121;
  t13126 = -1.*t12532*t12869;
  t13127 = t13126 + t12816;
  t13128 = 3.2*t13127*t12872;
  t13129 = -1.*t12904*t12532;
  t13130 = -1.*t12438*t12910;
  t13131 = t13129 + t13130;
  t13132 = 6.8*t13131*t12946;
  t13133 = 6.8*t12912*t12946;
  t13153 = t12438*t12961;
  t13154 = -1.*t12532*t12973;
  t13155 = t13153 + t13154;
  t13156 = 3.2*t12975*t13155;
  t13157 = -1.*t12532*t12986;
  t13158 = t13157 + t12974;
  t13159 = 3.2*t13158*t13023;
  t13160 = t13113 + t13118 + t13125 + t13128 + t13132 + t13133 + t13156 + t13159;
  t12445 = Power(t12438,2);
  t12485 = 12.*t12445;
  t12569 = Power(t12532,2);
  t12571 = 12.*t12569;
  t12753 = Power(t12736,2);
  t12758 = 6.8*t12753;
  t12947 = Power(t12946,2);
  t12951 = 6.8*t12947;
  t13165 = Power(t12572,2);
  t13166 = 0.11*t13165;
  t13167 = Power(t12587,2);
  t13168 = 0.11*t13167;
  t13169 = t13166 + t13168;
  t13184 = -1.*t13183*t12814;
  t13188 = -1.*t12766*t13187;
  t13189 = t13184 + t13188;
  t13191 = t13183*t12869;
  t13192 = t12814*t13187;
  t13193 = t13191 + t13192;
  t13211 = Power(t12904,2);
  t13215 = 0.11*t13211;
  t13217 = Power(t12910,2);
  t13219 = 0.11*t13217;
  t13220 = t13215 + t13219;
  t13232 = -1.*t13231*t12973;
  t13236 = -1.*t12961*t13235;
  t13237 = t13232 + t13236;
  t13239 = t13231*t12986;
  t13240 = t12973*t13235;
  t13241 = t13239 + t13240;
  t13255 = t13180*t12763;
  t13256 = -0.24*t12760*t12763;
  t13257 = t13255 + t13256;
  t13247 = t13180*t12760;
  t13250 = Power(t12763,2);
  t13251 = 0.24*t13250;
  t13252 = t13247 + t13251;
  t13267 = t13228*t12957;
  t13268 = -0.24*t12952*t12957;
  t13269 = t13267 + t13268;
  t13262 = t13228*t12952;
  t13263 = Power(t12957,2);
  t13264 = 0.24*t13263;
  t13265 = t13262 + t13264;
  t13161 = 2.88*t12438;
  t13170 = 6.8*t12736*t13169;
  t13190 = 3.2*t12872*t13189;
  t13208 = 3.2*t12857*t13193;
  t13223 = 6.8*t12946*t13220;
  t13238 = 3.2*t13023*t13237;
  t13244 = 3.2*t12975*t13241;
  t13245 = t13161 + t13170 + t13190 + t13208 + t13223 + t13238 + t13244;
  t13290 = -2.88*t12532;
  t13291 = 6.8*t13112*t13169;
  t13292 = 3.2*t13127*t13189;
  t13293 = 3.2*t13121*t13193;
  t13294 = 6.8*t13131*t13220;
  t13295 = 3.2*t13158*t13237;
  t13296 = 3.2*t13155*t13241;
  t13297 = t13290 + t13291 + t13292 + t13293 + t13294 + t13295 + t13296;
  t13246 = 0.748*t12736;
  t13254 = 3.2*t13252*t12857;
  t13258 = 3.2*t13257*t12872;
  t13259 = t13246 + t13254 + t13258;
  t13298 = 0.748*t13112;
  t13299 = 3.2*t13257*t13127;
  t13302 = 3.2*t13252*t13121;
  t13303 = t13298 + t13299 + t13302;
  t13325 = 0.748*t13169;
  t13326 = 3.2*t13257*t13189;
  t13327 = 3.2*t13252*t13193;
  t13328 = 0.67 + t13325 + t13326 + t13327;
  t13260 = 0.768*t12857;
  t13304 = 0.768*t13121;
  t13329 = 0.768*t13193;
  t13330 = 0.2 + t13329;
  t13342 = 0.768*t13252;
  t13343 = 0.2 + t13342;
  t13261 = 0.748*t12946;
  t13266 = 3.2*t13265*t12975;
  t13270 = 3.2*t13269*t13023;
  t13271 = t13261 + t13266 + t13270;
  t13305 = 0.748*t13131;
  t13308 = 3.2*t13269*t13158;
  t13309 = 3.2*t13265*t13155;
  t13310 = t13305 + t13308 + t13309;
  t13331 = 0.748*t13220;
  t13332 = 3.2*t13269*t13237;
  t13333 = 3.2*t13265*t13241;
  t13334 = 0.67 + t13331 + t13332 + t13333;
  t13272 = 0.768*t12975;
  t13311 = 0.768*t13155;
  t13335 = 0.768*t13241;
  t13336 = 0.2 + t13335;
  t13349 = 0.768*t13265;
  t13350 = 0.2 + t13349;
  p_output1[0]=t12485 + t12571 + 6.8*Power(t12592,2) + t12758 + 3.2*Power(t12857,2) + 3.2*Power(t12872,2) + 6.8*Power(t12912,2) + t12951 + 3.2*Power(t12975,2) + 3.2*Power(t13023,2);
  p_output1[1]=t13160;
  p_output1[2]=t13245;
  p_output1[3]=t13259;
  p_output1[4]=t13260;
  p_output1[5]=t13271;
  p_output1[6]=t13272;
  p_output1[7]=t13160;
  p_output1[8]=t12485 + t12571 + t12758 + t12951 + 6.8*Power(t13112,2) + 3.2*Power(t13121,2) + 3.2*Power(t13127,2) + 6.8*Power(t13131,2) + 3.2*Power(t13155,2) + 3.2*Power(t13158,2);
  p_output1[9]=t13297;
  p_output1[10]=t13303;
  p_output1[11]=t13304;
  p_output1[12]=t13310;
  p_output1[13]=t13311;
  p_output1[14]=t13245;
  p_output1[15]=t13297;
  p_output1[16]=3.3612 + 6.8*Power(t13169,2) + 3.2*Power(t13189,2) + 3.2*Power(t13193,2) + 6.8*Power(t13220,2) + 3.2*Power(t13237,2) + 3.2*Power(t13241,2);
  p_output1[17]=t13328;
  p_output1[18]=t13330;
  p_output1[19]=t13334;
  p_output1[20]=t13336;
  p_output1[21]=t13259;
  p_output1[22]=t13303;
  p_output1[23]=t13328;
  p_output1[24]=1.58228 + 3.2*Power(t13252,2) + 3.2*Power(t13257,2);
  p_output1[25]=t13343;
  p_output1[26]=0;
  p_output1[27]=0;
  p_output1[28]=t13260;
  p_output1[29]=t13304;
  p_output1[30]=t13330;
  p_output1[31]=t13343;
  p_output1[32]=1.2143199999999998;
  p_output1[33]=0;
  p_output1[34]=0;
  p_output1[35]=t13271;
  p_output1[36]=t13310;
  p_output1[37]=t13334;
  p_output1[38]=0;
  p_output1[39]=0;
  p_output1[40]=1.58228 + 3.2*Power(t13265,2) + 3.2*Power(t13269,2);
  p_output1[41]=t13350;
  p_output1[42]=t13272;
  p_output1[43]=t13311;
  p_output1[44]=t13336;
  p_output1[45]=0;
  p_output1[46]=0;
  p_output1[47]=t13350;
  p_output1[48]=1.2143199999999998;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "One input(s) required (var1).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 7, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1);


}

#else // MATLAB_MEX_FILE

#include "De_five_link_walker.hh"

namespace SymExpression
{

void De_five_link_walker_raw(double *p_output1, const double *var1)
{
  // Call Subroutines
  output1(p_output1, var1);

}

}

#endif // MATLAB_MEX_FILE
