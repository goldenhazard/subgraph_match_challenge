/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:29:48 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1)
{
  double t3497;
  double t3724;
  double t3735;
  double t3830;
  double t3910;
  double t3938;
  double t4017;
  double t7474;
  double t7588;
  double t7592;
  double t7598;
  double t7600;
  double t7684;
  double t7704;
  double t7708;
  double t7709;
  double t7711;
  double t7877;
  double t7921;
  double t7923;
  double t7924;
  double t7926;
  double t7452;
  double t7525;
  double t7544;
  double t7563;
  double t7624;
  double t7628;
  double t7634;
  double t7636;
  double t7641;
  double t7650;
  double t7667;
  double t8015;
  double t8029;
  double t8030;
  double t7876;
  double t7890;
  double t7910;
  double t7920;
  double t7940;
  double t7947;
  double t7948;
  double t7959;
  double t7961;
  double t7967;
  double t7968;
  double t8060;
  double t8069;
  double t8072;
  t3497 = Sin(var1[2]);
  t3724 = Cos(var1[3]);
  t3735 = -1.*t3724*t3497;
  t3830 = Cos(var1[2]);
  t3910 = Sin(var1[3]);
  t3938 = -1.*t3830*t3910;
  t4017 = t3735 + t3938;
  t7474 = Cos(var1[4]);
  t7588 = -1.*t3830*t3724;
  t7592 = t3497*t3910;
  t7598 = t7588 + t7592;
  t7600 = Sin(var1[4]);
  t7684 = Cos(var1[5]);
  t7704 = -1.*t7684*t3497;
  t7708 = Sin(var1[5]);
  t7709 = -1.*t3830*t7708;
  t7711 = t7704 + t7709;
  t7877 = Cos(var1[6]);
  t7921 = -1.*t3830*t7684;
  t7923 = t3497*t7708;
  t7924 = t7921 + t7923;
  t7926 = Sin(var1[6]);
  t7452 = 7.33788*t4017;
  t7525 = -1.*t7474;
  t7544 = 1. + t7525;
  t7563 = 0.4*t7544*t4017;
  t7624 = -0.4*t7598*t7600;
  t7628 = t7474*t4017;
  t7634 = t7598*t7600;
  t7636 = t7628 + t7634;
  t7641 = 0.64*t7636;
  t7650 = t7563 + t7624 + t7641;
  t7667 = 31.392000000000003*t7650;
  t8015 = t3830*t3724;
  t8029 = -1.*t3497*t3910;
  t8030 = t8015 + t8029;
  t7876 = 7.33788*t7711;
  t7890 = -1.*t7877;
  t7910 = 1. + t7890;
  t7920 = 0.4*t7910*t7711;
  t7940 = -0.4*t7924*t7926;
  t7947 = t7877*t7711;
  t7948 = t7924*t7926;
  t7959 = t7947 + t7948;
  t7961 = 0.64*t7959;
  t7967 = t7920 + t7940 + t7961;
  t7968 = 31.392000000000003*t7967;
  t8060 = t3830*t7684;
  t8069 = -1.*t3497*t7708;
  t8072 = t8060 + t8069;
  p_output1[0]=0;
  p_output1[1]=313.92;
  p_output1[2]=-28.252799999999997*t3497 + t7452 + t7667 + t7876 + t7968;
  p_output1[3]=t7452 + t7667;
  p_output1[4]=31.392000000000003*(-0.4*t4017*t7474 + 0.4*t7600*t8030 + 0.64*(t7628 - 1.*t7600*t8030));
  p_output1[5]=t7876 + t7968;
  p_output1[6]=31.392000000000003*(-0.4*t7711*t7877 + 0.4*t7926*t8072 + 0.64*(t7947 - 1.*t7926*t8072));
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "One input(s) required (var1).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1);


}

#else // MATLAB_MEX_FILE

#include "Ge_five_link_walker.hh"

namespace SymExpression
{

void Ge_five_link_walker_raw(double *p_output1, const double *var1)
{
  // Call Subroutines
  output1(p_output1, var1);

}

}

#endif // MATLAB_MEX_FILE
