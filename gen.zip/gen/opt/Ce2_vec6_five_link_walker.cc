/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:48 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t10639;
  double t9772;
  double t9806;
  double t10654;
  double t11124;
  double t3760;
  double t10338;
  double t10987;
  double t11121;
  double t11199;
  double t11200;
  double t11202;
  double t11203;
  double t11204;
  double t11123;
  double t11125;
  double t11126;
  double t11127;
  double t11135;
  double t11145;
  double t11185;
  double t11190;
  double t11191;
  double t11270;
  double t11273;
  double t11274;
  double t11222;
  double t11233;
  double t11234;
  double t11235;
  double t11236;
  double t11237;
  double t11278;
  double t11279;
  double t11280;
  double t11321;
  double t11322;
  double t11323;
  double t11324;
  double t11325;
  double t11327;
  double t11404;
  double t11405;
  double t11434;
  double t11435;
  double t11436;
  double t11439;
  double t11442;
  double t11443;
  double t11450;
  double t11453;
  double t11473;
  double t11407;
  double t11410;
  double t11411;
  double t11391;
  double t11392;
  double t11395;
  double t11218;
  double t11219;
  double t11220;
  double t11239;
  double t11240;
  double t11241;
  double t11242;
  double t11276;
  double t11397;
  double t11398;
  double t11332;
  double t11333;
  double t11354;
  double t11385;
  double t11387;
  double t11396;
  double t11403;
  double t11406;
  double t11412;
  double t11416;
  double t11420;
  double t11423;
  double t11427;
  double t11428;
  double t11431;
  double t11432;
  double t11438;
  double t11444;
  double t11446;
  double t11475;
  double t11477;
  double t11480;
  double t11481;
  double t11482;
  double t11489;
  double t11490;
  double t11491;
  double t11493;
  double t11494;
  double t11495;
  double t11496;
  double t11497;
  double t11550;
  double t11551;
  double t11552;
  double t11554;
  double t11555;
  double t11557;
  double t11433;
  double t11447;
  double t11488;
  double t11492;
  double t11521;
  double t11527;
  double t11534;
  double t11535;
  double t11536;
  double t11537;
  double t11198;
  double t11238;
  double t11243;
  double t11245;
  double t11564;
  double t11565;
  double t11568;
  t10639 = Cos(var1[5]);
  t9772 = Cos(var1[6]);
  t9806 = Sin(var1[5]);
  t10654 = Sin(var1[6]);
  t11124 = Sin(var1[2]);
  t3760 = Cos(var1[2]);
  t10338 = -1.*t9772*t9806;
  t10987 = -1.*t10639*t10654;
  t11121 = t10338 + t10987;
  t11199 = -1.*t9772;
  t11200 = 1. + t11199;
  t11202 = 0.4*t11200;
  t11203 = 0.64*t9772;
  t11204 = t11202 + t11203;
  t11123 = t3760*t11121;
  t11125 = -1.*t10639*t9772;
  t11126 = t9806*t10654;
  t11127 = t11125 + t11126;
  t11135 = t11124*t11127;
  t11145 = t11123 + t11135;
  t11185 = -1.*t10639*t11124;
  t11190 = -1.*t3760*t9806;
  t11191 = t11185 + t11190;
  t11270 = t3760*t10639;
  t11273 = -1.*t11124*t9806;
  t11274 = t11270 + t11273;
  t11222 = t11124*t11121;
  t11233 = t10639*t9772;
  t11234 = -1.*t9806*t10654;
  t11235 = t11233 + t11234;
  t11236 = t3760*t11235;
  t11237 = t11222 + t11236;
  t11278 = t10639*t11124;
  t11279 = t3760*t9806;
  t11280 = t11278 + t11279;
  t11321 = t9772*t9806;
  t11322 = t10639*t10654;
  t11323 = t11321 + t11322;
  t11324 = t3760*t11323;
  t11325 = t11124*t11235;
  t11327 = t11324 + t11325;
  t11404 = -1.*t11124*t11235;
  t11405 = t11123 + t11404;
  t11434 = t11204*t9806;
  t11435 = 0.24*t10639*t10654;
  t11436 = t11434 + t11435;
  t11439 = t10639*t11204;
  t11442 = -0.24*t9806*t10654;
  t11443 = t11439 + t11442;
  t11450 = -1.*t11204*t9806;
  t11453 = -0.24*t10639*t10654;
  t11473 = t11450 + t11453;
  t11407 = -1.*t11124*t11121;
  t11410 = t3760*t11127;
  t11411 = t11407 + t11410;
  t11391 = -1.*t3760*t10639;
  t11392 = t11124*t9806;
  t11395 = t11391 + t11392;
  t11218 = t11204*t10654;
  t11219 = -0.24*t9772*t10654;
  t11220 = t11218 + t11219;
  t11239 = t11204*t9772;
  t11240 = Power(t10654,2);
  t11241 = 0.24*t11240;
  t11242 = t11239 + t11241;
  t11276 = 13.6*t11191*t11274;
  t11397 = -1.*t11124*t11323;
  t11398 = t11397 + t11236;
  t11332 = Power(t11191,2);
  t11333 = 6.8*t11332;
  t11354 = 6.8*t11191*t11280;
  t11385 = Power(t11274,2);
  t11387 = 6.8*t11385;
  t11396 = 6.8*t11274*t11395;
  t11403 = 3.2*t11237*t11398;
  t11406 = 3.2*t11405*t11327;
  t11412 = 3.2*t11237*t11411;
  t11416 = 3.2*t11405*t11145;
  t11420 = t11333 + t11354 + t11387 + t11396 + t11403 + t11406 + t11412 + t11416;
  t11423 = Power(t10639,2);
  t11427 = 0.11*t11423;
  t11428 = Power(t9806,2);
  t11431 = 0.11*t11428;
  t11432 = t11427 + t11431;
  t11438 = -1.*t11436*t11235;
  t11444 = -1.*t11121*t11443;
  t11446 = t11438 + t11444;
  t11475 = t11473*t11235;
  t11477 = t11436*t11235;
  t11480 = t11121*t11443;
  t11481 = t11323*t11443;
  t11482 = t11475 + t11477 + t11480 + t11481;
  t11489 = t11436*t11323;
  t11490 = t11235*t11443;
  t11491 = t11489 + t11490;
  t11493 = -1.*t11121*t11473;
  t11494 = -1.*t11121*t11436;
  t11495 = -1.*t11235*t11443;
  t11496 = -1.*t11443*t11127;
  t11497 = t11493 + t11494 + t11495 + t11496;
  t11550 = 6.8*t11395*t11432;
  t11551 = 3.2*t11405*t11446;
  t11552 = 3.2*t11405*t11482;
  t11554 = 3.2*t11491*t11411;
  t11555 = 3.2*t11398*t11497;
  t11557 = t11550 + t11551 + t11552 + t11554 + t11555;
  t11433 = 6.8*t11191*t11432;
  t11447 = 3.2*t11237*t11446;
  t11488 = 3.2*t11237*t11482;
  t11492 = 3.2*t11491*t11145;
  t11521 = 3.2*t11327*t11497;
  t11527 = t11433 + t11447 + t11488 + t11492 + t11521;
  t11534 = 0.748*t11395;
  t11535 = 3.2*t11220*t11405;
  t11536 = 3.2*t11242*t11411;
  t11537 = t11534 + t11535 + t11536;
  t11198 = 0.748*t11191;
  t11238 = 3.2*t11220*t11237;
  t11243 = 3.2*t11242*t11145;
  t11245 = t11198 + t11238 + t11243;
  t11564 = 3.2*t11242*t11482;
  t11565 = 3.2*t11220*t11497;
  t11568 = t11564 + t11565;
  p_output1[0]=var2[5]*(-0.5*(6.4*t11145*t11237 + t11276 + 13.6*t11274*t11280 + 6.4*t11237*t11327)*var2[0] - 0.5*t11420*var2[1] - 0.5*t11527*var2[2] - 0.5*t11245*var2[5] - 0.384*t11145*var2[6]);
  p_output1[1]=var2[5]*(-0.5*t11420*var2[0] - 0.5*(t11276 + 13.6*t11191*t11395 + 6.4*t11398*t11405 + 6.4*t11405*t11411)*var2[1] - 0.5*t11557*var2[2] - 0.5*t11537*var2[5] - 0.384*t11411*var2[6]);
  p_output1[2]=var2[5]*(-0.5*t11527*var2[0] - 0.5*t11557*var2[1] - 0.5*(6.4*t11482*t11491 + 6.4*t11446*t11497)*var2[2] - 0.5*t11568*var2[5] - 0.384*t11482*var2[6]);
  p_output1[3]=0;
  p_output1[4]=0;
  p_output1[5]=(-0.5*t11245*var2[0] - 0.5*t11537*var2[1] - 0.5*t11568*var2[2])*var2[5];
  p_output1[6]=(-0.384*t11145*var2[0] - 0.384*t11411*var2[1] - 0.384*t11482*var2[2])*var2[5];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce2_vec6_five_link_walker.hh"

namespace RightStance
{

void Ce2_vec6_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
