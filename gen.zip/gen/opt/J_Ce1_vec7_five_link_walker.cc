/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:36 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t8289;
  double t1105;
  double t3777;
  double t8321;
  double t1002;
  double t7335;
  double t8526;
  double t8857;
  double t8863;
  double t8864;
  double t8991;
  double t8992;
  double t8993;
  double t8994;
  double t8995;
  double t9126;
  double t9127;
  double t9128;
  double t9130;
  double t9131;
  double t9121;
  double t9132;
  double t9133;
  double t9134;
  double t9135;
  double t8867;
  double t8924;
  double t8925;
  double t9201;
  double t9202;
  double t9214;
  double t9216;
  double t9217;
  double t9223;
  double t9227;
  double t9228;
  double t9238;
  double t9245;
  double t9235;
  double t9246;
  double t9247;
  double t9253;
  double t9256;
  double t8926;
  double t8930;
  double t9038;
  double t8931;
  double t9000;
  double t9272;
  double t9273;
  double t9274;
  double t9275;
  double t9276;
  double t9277;
  double t9278;
  double t9279;
  double t9286;
  double t9287;
  double t9288;
  double t9281;
  double t9282;
  double t9283;
  double t9284;
  double t9312;
  double t9314;
  double t9291;
  double t9296;
  double t9311;
  double t9315;
  double t9316;
  double t9529;
  double t9645;
  double t10111;
  double t10142;
  double t10336;
  double t10495;
  double t10607;
  double t10656;
  double t11070;
  double t11071;
  double t11074;
  double t11078;
  double t11089;
  t8289 = Cos(var1[5]);
  t1105 = Cos(var1[6]);
  t3777 = Sin(var1[5]);
  t8321 = Sin(var1[6]);
  t1002 = Sin(var1[2]);
  t7335 = -1.*t1105*t3777;
  t8526 = -1.*t8289*t8321;
  t8857 = t7335 + t8526;
  t8863 = -1.*t1002*t8857;
  t8864 = Cos(var1[2]);
  t8991 = -1.*t8289*t1105;
  t8992 = t3777*t8321;
  t8993 = t8991 + t8992;
  t8994 = t8864*t8993;
  t8995 = t8863 + t8994;
  t9126 = t1105*t3777;
  t9127 = t8289*t8321;
  t9128 = t9126 + t9127;
  t9130 = t1002*t9128;
  t9131 = t9130 + t8994;
  t9121 = -0.384*var2[2]*t8995;
  t9132 = -0.384*var2[5]*t9131;
  t9133 = -0.384*var2[6]*t9131;
  t9134 = t9121 + t9132 + t9133;
  t9135 = var2[6]*t9134;
  t8867 = t8289*t1105;
  t8924 = -1.*t3777*t8321;
  t8925 = t8867 + t8924;
  t9201 = t8864*t8857;
  t9202 = -1.*t1002*t8925;
  t9214 = t9201 + t9202;
  t9216 = t1002*t8993;
  t9217 = t9201 + t9216;
  t9223 = -1.*t8864*t8857;
  t9227 = -1.*t1002*t8993;
  t9228 = t9223 + t9227;
  t9238 = t8864*t9128;
  t9245 = t9238 + t9227;
  t9235 = -0.384*var2[2]*t9228;
  t9246 = -0.384*var2[5]*t9245;
  t9247 = -0.384*var2[6]*t9245;
  t9253 = t9235 + t9246 + t9247;
  t9256 = var2[6]*t9253;
  t8926 = -1.*t8864*t8925;
  t8930 = t8863 + t8926;
  t9038 = -0.384*var2[6]*t8995;
  t8931 = -0.384*var2[2]*t8930;
  t9000 = -0.384*var2[5]*t8995;
  t9272 = -1.*t1105;
  t9273 = 1. + t9272;
  t9274 = 0.4*t9273;
  t9275 = 0.64*t1105;
  t9276 = t9274 + t9275;
  t9277 = -1.*t9276*t3777;
  t9278 = -0.24*t8289*t8321;
  t9279 = t9277 + t9278;
  t9286 = t8289*t9276;
  t9287 = -0.24*t3777*t8321;
  t9288 = t9286 + t9287;
  t9281 = t9276*t3777;
  t9282 = 0.24*t8289*t8321;
  t9283 = t9281 + t9282;
  t9284 = t8857*t9283;
  t9312 = -0.24*t1105*t3777;
  t9314 = t9312 + t9278;
  t9291 = 0.24*t3777*t8321;
  t9296 = t9288*t8993;
  t9311 = t8857*t9279;
  t9315 = t8857*t9314;
  t9316 = t9314*t9128;
  t9529 = t8925*t9288;
  t9645 = 0.24*t8289*t1105;
  t10111 = t9645 + t9287;
  t10142 = t8925*t10111;
  t10336 = -0.24*t8289*t1105;
  t10495 = t10336 + t9291;
  t10607 = t8925*t10495;
  t10656 = t9311 + t9315 + t9284 + t9316 + t9529 + t10142 + t10607 + t9296;
  t11070 = t9279*t8925;
  t11071 = t9283*t8925;
  t11074 = t8857*t9288;
  t11078 = t9128*t9288;
  t11089 = t11070 + t11071 + t11074 + t11078;
  p_output1[0]=(t8931 + t9000 + t9038)*var2[6];
  p_output1[1]=t9135;
  p_output1[2]=t9135;
  p_output1[3]=-0.384*t9214*var2[6];
  p_output1[4]=-0.384*t9217*var2[6];
  p_output1[5]=-0.384*t9214*var2[2] - 0.384*t9217*var2[5] - 0.768*t9217*var2[6];
  p_output1[6]=var2[6]*(-0.384*(t1002*t8925 + t9223)*var2[2] - 0.384*t9228*var2[5] - 0.384*t9228*var2[6]);
  p_output1[7]=t9256;
  p_output1[8]=t9256;
  p_output1[9]=-0.384*t8930*var2[6];
  p_output1[10]=t9038;
  p_output1[11]=t8931 + t9000 - 0.768*t8995*var2[6];
  p_output1[12]=var2[6]*(-0.384*(2.*t8857*t9279 + t9128*t9279 + t9284 + 2.*t8925*t9288 + t8925*(-1.*t8289*t9276 + t9291) + t9296)*var2[5] - 0.384*t10656*var2[6]);
  p_output1[13]=var2[6]*(-0.384*t10656*var2[5] - 0.384*(t10607 + 2.*t10111*t8925 + t9284 + t9296 + 2.*t8857*t9314 + t9316)*var2[6]);
  p_output1[14]=-0.384*t11089*var2[6];
  p_output1[15]=-0.384*t11089*var2[5] - 0.768*(t11071 + t11074 + t10111*t9128 + t8925*t9314)*var2[6];
  p_output1[16]=-0.384*(0.24*Power(t1105,2) - 1.*t1105*t9276)*Power(var2[6],2);
  p_output1[17]=-0.768*(0.24*t1105*t8321 - 1.*t8321*t9276)*var2[6];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 18, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce1_vec7_five_link_walker.hh"

namespace RightStance
{

void J_Ce1_vec7_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
