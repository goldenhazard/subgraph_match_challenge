/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:29 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t61;
  double t8053;
  double t3816;
  double t7562;
  double t8729;
  double t8737;
  double t13126;
  double t13192;
  double t13277;
  double t8730;
  double t9591;
  double t9598;
  double t13389;
  double t13399;
  double t13400;
  double t13409;
  double t13640;
  double t9768;
  double t13322;
  double t13383;
  double t13667;
  double t13668;
  double t13676;
  double t13688;
  double t13689;
  double t13690;
  double t13729;
  double t13730;
  double t13731;
  double t13719;
  double t13720;
  double t13721;
  double t13755;
  double t13756;
  double t13757;
  double t13677;
  double t13716;
  double t13717;
  double t13718;
  double t13725;
  double t13728;
  double t13748;
  double t13752;
  double t13753;
  double t13754;
  double t13786;
  double t13789;
  double t13790;
  double t13791;
  double t13796;
  double t13798;
  double t13812;
  double t13813;
  double t13801;
  double t13815;
  double t13816;
  double t13803;
  double t7467;
  double t8185;
  double t8186;
  double t8247;
  double t8298;
  double t8364;
  double t8407;
  double t8513;
  double t8611;
  double t13865;
  double t13869;
  double t13880;
  double t13882;
  double t13894;
  double t13897;
  double t13898;
  double t13901;
  double t13902;
  double t13903;
  double t13904;
  double t13905;
  double t13910;
  double t13911;
  double t13912;
  double t13906;
  double t13907;
  double t13908;
  double t13881;
  double t13888;
  double t13892;
  double t13913;
  double t13914;
  double t13915;
  double t13866;
  double t13872;
  double t13873;
  double t13874;
  double t13875;
  double t13876;
  double t13877;
  double t13878;
  double t13879;
  double t13899;
  double t13909;
  double t13921;
  double t13925;
  double t13938;
  double t13939;
  double t13932;
  double t13933;
  double t13934;
  double t13927;
  double t13941;
  double t13942;
  double t13943;
  double t13950;
  double t13951;
  double t13952;
  double t13940;
  double t13945;
  double t13946;
  double t13953;
  double t13954;
  double t13955;
  double t13956;
  double t13957;
  double t13958;
  double t13967;
  double t13968;
  double t13960;
  double t13970;
  double t13971;
  double t13962;
  double t13861;
  double t13863;
  double t13724;
  double t13743;
  double t13744;
  double t13856;
  double t13857;
  double t13800;
  double t13802;
  double t13806;
  double t13987;
  double t13814;
  double t13817;
  double t13818;
  double t13989;
  double t13990;
  double t13991;
  double t13992;
  double t13820;
  double t13841;
  double t13845;
  double t13983;
  double t13984;
  double t13985;
  double t13986;
  double t13930;
  double t14007;
  double t14008;
  double t14009;
  double t14010;
  double t13931;
  double t13944;
  double t13947;
  double t13948;
  double t14014;
  double t13893;
  double t13900;
  double t13959;
  double t13961;
  double t13963;
  double t14020;
  double t13969;
  double t13972;
  double t13973;
  double t14022;
  double t14023;
  double t14024;
  double t13975;
  double t13976;
  double t13977;
  double t14052;
  double t14053;
  double t14054;
  double t14055;
  double t14057;
  double t14058;
  double t14059;
  double t14081;
  double t14082;
  double t14083;
  double t14084;
  double t14086;
  double t14087;
  double t14088;
  t61 = Cos(var1[3]);
  t8053 = Sin(var1[3]);
  t3816 = Sin(var1[2]);
  t7562 = Cos(var1[2]);
  t8729 = Cos(var1[4]);
  t8737 = Sin(var1[4]);
  t13126 = t61*t8729;
  t13192 = -1.*t8053*t8737;
  t13277 = t13126 + t13192;
  t8730 = -1.*t8729*t8053;
  t9591 = -1.*t61*t8737;
  t9598 = t8730 + t9591;
  t13389 = -1.*t8729;
  t13399 = 1. + t13389;
  t13400 = 0.4*t13399;
  t13409 = 0.64*t8729;
  t13640 = t13400 + t13409;
  t9768 = t3816*t9598;
  t13322 = t7562*t13277;
  t13383 = t9768 + t13322;
  t13667 = t13640*t8053;
  t13668 = 0.24*t61*t8737;
  t13676 = t13667 + t13668;
  t13688 = t61*t13640;
  t13689 = -0.24*t8053*t8737;
  t13690 = t13688 + t13689;
  t13729 = t8729*t8053;
  t13730 = t61*t8737;
  t13731 = t13729 + t13730;
  t13719 = -1.*t13640*t8053;
  t13720 = -0.24*t61*t8737;
  t13721 = t13719 + t13720;
  t13755 = -1.*t61*t8729;
  t13756 = t8053*t8737;
  t13757 = t13755 + t13756;
  t13677 = -1.*t13676*t13277;
  t13716 = -1.*t9598*t13690;
  t13717 = t13677 + t13716;
  t13718 = 3.2*t13383*t13717;
  t13725 = t13676*t13277;
  t13728 = t9598*t13690;
  t13748 = t13676*t13731;
  t13752 = t13277*t13690;
  t13753 = t13748 + t13752;
  t13754 = t7562*t9598;
  t13786 = t3816*t13757;
  t13789 = t13754 + t13786;
  t13790 = 3.2*t13753*t13789;
  t13791 = t7562*t13731;
  t13796 = t3816*t13277;
  t13798 = t13791 + t13796;
  t13812 = -0.24*t8729*t8053;
  t13813 = t13812 + t13720;
  t13801 = -1.*t9598*t13676;
  t13815 = 0.24*t61*t8729;
  t13816 = t13815 + t13689;
  t13803 = -1.*t13690*t13757;
  t7467 = -1.*t61*t3816;
  t8185 = -1.*t7562*t8053;
  t8186 = t7467 + t8185;
  t8247 = Power(t61,2);
  t8298 = 0.11*t8247;
  t8364 = Power(t8053,2);
  t8407 = 0.11*t8364;
  t8513 = t8298 + t8407;
  t8611 = 6.8*t8186*t8513;
  t13865 = Cos(var1[5]);
  t13869 = Sin(var1[5]);
  t13880 = Cos(var1[6]);
  t13882 = Sin(var1[6]);
  t13894 = t13865*t13880;
  t13897 = -1.*t13869*t13882;
  t13898 = t13894 + t13897;
  t13901 = -1.*t13880;
  t13902 = 1. + t13901;
  t13903 = 0.4*t13902;
  t13904 = 0.64*t13880;
  t13905 = t13903 + t13904;
  t13910 = -1.*t13880*t13869;
  t13911 = -1.*t13865*t13882;
  t13912 = t13910 + t13911;
  t13906 = t13905*t13869;
  t13907 = 0.24*t13865*t13882;
  t13908 = t13906 + t13907;
  t13881 = t13880*t13869;
  t13888 = t13865*t13882;
  t13892 = t13881 + t13888;
  t13913 = t13865*t13905;
  t13914 = -0.24*t13869*t13882;
  t13915 = t13913 + t13914;
  t13866 = -1.*t13865*t3816;
  t13872 = -1.*t7562*t13869;
  t13873 = t13866 + t13872;
  t13874 = Power(t13865,2);
  t13875 = 0.11*t13874;
  t13876 = Power(t13869,2);
  t13877 = 0.11*t13876;
  t13878 = t13875 + t13877;
  t13879 = 6.8*t13873*t13878;
  t13899 = t7562*t13898;
  t13909 = -1.*t13908*t13898;
  t13921 = -1.*t13912*t13915;
  t13925 = t13909 + t13921;
  t13938 = t3816*t13912;
  t13939 = t13938 + t13899;
  t13932 = t13908*t13892;
  t13933 = t13898*t13915;
  t13934 = t13932 + t13933;
  t13927 = t7562*t13912;
  t13941 = -1.*t13905*t13869;
  t13942 = -0.24*t13865*t13882;
  t13943 = t13941 + t13942;
  t13950 = -1.*t13865*t13880;
  t13951 = t13869*t13882;
  t13952 = t13950 + t13951;
  t13940 = 3.2*t13939*t13925;
  t13945 = t13908*t13898;
  t13946 = t13912*t13915;
  t13953 = t3816*t13952;
  t13954 = t13927 + t13953;
  t13955 = 3.2*t13934*t13954;
  t13956 = t7562*t13892;
  t13957 = t3816*t13898;
  t13958 = t13956 + t13957;
  t13967 = -0.24*t13880*t13869;
  t13968 = t13967 + t13942;
  t13960 = -1.*t13912*t13908;
  t13970 = 0.24*t13865*t13880;
  t13971 = t13970 + t13914;
  t13962 = -1.*t13915*t13952;
  t13861 = -1.*t3816*t13277;
  t13863 = t13754 + t13861;
  t13724 = t13721*t13277;
  t13743 = t13731*t13690;
  t13744 = t13724 + t13725 + t13728 + t13743;
  t13856 = -1.*t3816*t13731;
  t13857 = t13856 + t13322;
  t13800 = -1.*t9598*t13721;
  t13802 = -1.*t13277*t13690;
  t13806 = t13800 + t13801 + t13802 + t13803;
  t13987 = 3.2*t13863*t13717;
  t13814 = t13813*t13277;
  t13817 = t13731*t13816;
  t13818 = t13814 + t13725 + t13728 + t13817;
  t13989 = -1.*t3816*t9598;
  t13990 = t7562*t13757;
  t13991 = t13989 + t13990;
  t13992 = 3.2*t13753*t13991;
  t13820 = -1.*t9598*t13813;
  t13841 = -1.*t13277*t13816;
  t13845 = t13820 + t13801 + t13841 + t13803;
  t13983 = -1.*t7562*t61;
  t13984 = t3816*t8053;
  t13985 = t13983 + t13984;
  t13986 = 6.8*t13985*t8513;
  t13930 = -1.*t3816*t13898;
  t14007 = -1.*t7562*t13865;
  t14008 = t3816*t13869;
  t14009 = t14007 + t14008;
  t14010 = 6.8*t14009*t13878;
  t13931 = t13927 + t13930;
  t13944 = t13943*t13898;
  t13947 = t13892*t13915;
  t13948 = t13944 + t13945 + t13946 + t13947;
  t14014 = -1.*t3816*t13912;
  t13893 = -1.*t3816*t13892;
  t13900 = t13893 + t13899;
  t13959 = -1.*t13912*t13943;
  t13961 = -1.*t13898*t13915;
  t13963 = t13959 + t13960 + t13961 + t13962;
  t14020 = 3.2*t13931*t13925;
  t13969 = t13968*t13898;
  t13972 = t13892*t13971;
  t13973 = t13969 + t13945 + t13946 + t13972;
  t14022 = t7562*t13952;
  t14023 = t14014 + t14022;
  t14024 = 3.2*t13934*t14023;
  t13975 = -1.*t13912*t13968;
  t13976 = -1.*t13898*t13971;
  t13977 = t13975 + t13960 + t13976 + t13962;
  t14052 = t13640*t8729;
  t14053 = Power(t8737,2);
  t14054 = 0.24*t14053;
  t14055 = t14052 + t14054;
  t14057 = t13640*t8737;
  t14058 = -0.24*t8729*t8737;
  t14059 = t14057 + t14058;
  t14081 = t13905*t13880;
  t14082 = Power(t13882,2);
  t14083 = 0.24*t14082;
  t14084 = t14081 + t14083;
  t14086 = t13905*t13882;
  t14087 = -0.24*t13880*t13882;
  t14088 = t14086 + t14087;
  p_output1[0]=var2[2]*(-0.5*(3.2*t13717*t13857 + 3.2*t13753*t13863 + t13879 + 3.2*t13900*t13925 + 3.2*t13931*t13934 - 2.88*t3816 + t8611)*var2[2] - 0.5*(t13718 + 3.2*t13383*t13744 + t13790 + 3.2*t13798*t13806 + t8611)*var2[3] - 0.5*(t13718 + t13790 + 3.2*t13383*t13818 + 3.2*t13798*t13845)*var2[4] - 0.5*(t13879 + t13940 + 3.2*t13939*t13948 + t13955 + 3.2*t13958*t13963)*var2[5] - 0.5*(t13940 + t13955 + 3.2*t13939*t13973 + 3.2*t13958*t13977)*var2[6]);
  p_output1[1]=var2[2]*(-0.5*(t13986 + t14010 - 2.88*t7562 + 3.2*t13753*(t13989 - 1.*t13277*t7562) + 3.2*t13717*(t13861 - 1.*t13731*t7562) + 3.2*t13925*(t13930 - 1.*t13892*t7562) + 3.2*t13934*(t14014 - 1.*t13898*t7562))*var2[2] - 0.5*(3.2*t13806*t13857 + 3.2*t13744*t13863 + t13986 + t13987 + t13992)*var2[3] - 0.5*(3.2*t13845*t13857 + 3.2*t13818*t13863 + t13987 + t13992)*var2[4] - 0.5*(3.2*t13931*t13948 + 3.2*t13900*t13963 + t14010 + t14020 + t14024)*var2[5] - 0.5*(3.2*t13931*t13973 + 3.2*t13900*t13977 + t14020 + t14024)*var2[6]);
  p_output1[2]=var2[2]*(-0.5*(6.4*t13744*t13753 + 6.4*t13717*t13806)*var2[3] - 0.5*(6.4*t13753*t13818 + 6.4*t13717*t13845)*var2[4] - 0.5*(6.4*t13934*t13948 + 6.4*t13925*t13963)*var2[5] - 0.5*(6.4*t13934*t13973 + 6.4*t13925*t13977)*var2[6]);
  p_output1[3]=var2[2]*(-0.5*(3.2*t13744*t14055 + 3.2*t13806*t14059)*var2[3] - 0.5*(3.2*t13818*t14055 + 3.2*t13845*t14059 + 3.2*t13717*(t14052 - 0.24*Power(t8729,2)) + 3.2*t13753*(-1.*t13640*t8737 + 0.24*t8729*t8737))*var2[4]);
  p_output1[4]=var2[2]*(-0.384*t13744*var2[3] - 0.384*t13818*var2[4]);
  p_output1[5]=var2[2]*(-0.5*(3.2*t13948*t14084 + 3.2*t13963*t14088)*var2[5] - 0.5*(3.2*(0.24*t13880*t13882 - 1.*t13882*t13905)*t13934 + 3.2*t13925*(-0.24*Power(t13880,2) + t14081) + 3.2*t13973*t14084 + 3.2*t13977*t14088)*var2[6]);
  p_output1[6]=var2[2]*(-0.384*t13948*var2[5] - 0.384*t13973*var2[6]);
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce1_vec3_five_link_walker.hh"

namespace RightStance
{

void Ce1_vec3_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
