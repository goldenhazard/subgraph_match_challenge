/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:32 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t9656;
  double t9572;
  double t9620;
  double t6440;
  double t9841;
  double t6425;
  double t9659;
  double t9824;
  double t9825;
  double t9826;
  double t9839;
  double t9994;
  double t9996;
  double t9997;
  double t7964;
  double t9625;
  double t9643;
  double t9644;
  double t10081;
  double t10144;
  double t10259;
  double t9888;
  double t9920;
  double t9977;
  double t10489;
  double t9840;
  double t9848;
  double t9866;
  double t9883;
  double t9993;
  double t10276;
  double t10277;
  double t10369;
  double t10807;
  double t10808;
  double t10809;
  double t10810;
  double t10812;
  double t10813;
  double t10815;
  double t10862;
  double t10877;
  double t10889;
  double t10894;
  double t10925;
  double t10954;
  double t10956;
  double t11076;
  double t11082;
  double t11087;
  double t11090;
  double t11091;
  double t11093;
  double t10973;
  double t10986;
  double t10988;
  double t10955;
  double t10958;
  double t10971;
  double t11002;
  double t11032;
  double t11103;
  double t11128;
  double t11201;
  double t11216;
  double t11225;
  double t11553;
  double t11585;
  double t11588;
  double t11591;
  double t11592;
  double t11601;
  double t11602;
  double t11631;
  double t11429;
  double t11463;
  double t11472;
  double t11660;
  double t11682;
  double t11683;
  double t11701;
  double t10002;
  double t11774;
  double t11775;
  double t11776;
  double t11785;
  double t10003;
  double t11818;
  double t11835;
  double t10402;
  double t10494;
  double t11836;
  double t11839;
  double t11842;
  double t11845;
  double t12019;
  double t12023;
  double t12026;
  double t11854;
  double t11865;
  double t11924;
  double t12058;
  double t12063;
  double t12077;
  double t11316;
  double t11361;
  double t11370;
  double t10036;
  double t10745;
  double t10787;
  double t10789;
  double t11046;
  double t12328;
  double t12340;
  double t12353;
  double t12228;
  double t12258;
  double t12305;
  double t12425;
  double t12426;
  double t12440;
  double t12371;
  double t12378;
  double t12383;
  double t12365;
  double t12614;
  double t12657;
  double t12470;
  double t12482;
  double t12749;
  double t12751;
  double t12773;
  double t12774;
  double t12518;
  double t12558;
  double t12561;
  double t12563;
  double t12593;
  double t12605;
  double t12609;
  double t12670;
  double t12725;
  double t12752;
  double t12776;
  double t12778;
  double t12795;
  double t12798;
  double t12804;
  double t12812;
  double t12821;
  double t12824;
  double t12856;
  double t12862;
  double t12864;
  double t12869;
  double t12881;
  double t12882;
  double t12889;
  double t12894;
  double t12909;
  double t12930;
  double t12945;
  double t12954;
  double t13004;
  double t13005;
  double t13009;
  double t13011;
  double t13013;
  double t13016;
  double t13017;
  double t13046;
  double t13057;
  double t13058;
  double t13150;
  double t13156;
  double t13177;
  double t13199;
  double t13206;
  double t13490;
  double t13500;
  double t13510;
  t9656 = Cos(var1[6]);
  t9572 = Sin(var1[2]);
  t9620 = Sin(var1[5]);
  t6440 = Cos(var1[5]);
  t9841 = Sin(var1[6]);
  t6425 = Cos(var1[2]);
  t9659 = -1.*t9656;
  t9824 = 1. + t9659;
  t9825 = 0.4*t9824;
  t9826 = 0.64*t9656;
  t9839 = t9825 + t9826;
  t9994 = t6440*t9656;
  t9996 = -1.*t9620*t9841;
  t9997 = t9994 + t9996;
  t7964 = -1.*t6425*t6440;
  t9625 = t9572*t9620;
  t9643 = t7964 + t9625;
  t9644 = 0.748*t9643;
  t10081 = t9839*t9841;
  t10144 = -0.24*t9656*t9841;
  t10259 = t10081 + t10144;
  t9888 = -1.*t9656*t9620;
  t9920 = -1.*t6440*t9841;
  t9977 = t9888 + t9920;
  t10489 = -1.*t9572*t9997;
  t9840 = t9839*t9656;
  t9848 = Power(t9841,2);
  t9866 = 0.24*t9848;
  t9883 = t9840 + t9866;
  t9993 = -1.*t9572*t9977;
  t10276 = t9656*t9620;
  t10277 = t6440*t9841;
  t10369 = t10276 + t10277;
  t10807 = t6425*t9977;
  t10808 = t10807 + t10489;
  t10809 = 3.2*t10259*t10808;
  t10810 = -1.*t6440*t9656;
  t10812 = t9620*t9841;
  t10813 = t10810 + t10812;
  t10815 = t6425*t10813;
  t10862 = t9993 + t10815;
  t10877 = 3.2*t9883*t10862;
  t10889 = t9644 + t10809 + t10877;
  t10894 = Power(t9656,2);
  t10925 = -0.24*t10894;
  t10954 = t9840 + t10925;
  t10956 = t6425*t9997;
  t11076 = t9572*t10369;
  t11082 = t11076 + t10815;
  t11087 = 3.2*t9883*t11082;
  t11090 = t9572*t10813;
  t11091 = t10807 + t11090;
  t11093 = 3.2*t10259*t11091;
  t10973 = -1.*t9839*t9841;
  t10986 = 0.24*t9656*t9841;
  t10988 = t10973 + t10986;
  t10955 = -1.*t9572*t10369;
  t10958 = t10955 + t10956;
  t10971 = 3.2*t10954*t10958;
  t11002 = 3.2*t10988*t10808;
  t11032 = t10971 + t10809 + t11002 + t10877;
  t11103 = t9572*t9977;
  t11128 = t11103 + t10956;
  t11201 = 3.2*t10954*t11128;
  t11216 = 3.2*t10988*t11091;
  t11225 = t11201 + t11087 + t11093 + t11216;
  t11553 = -1.*t6440*t9572;
  t11585 = -1.*t6425*t9620;
  t11588 = t11553 + t11585;
  t11591 = 0.748*t11588;
  t11592 = 3.2*t10259*t10958;
  t11601 = 3.2*t9883*t10808;
  t11602 = t11591 + t11592 + t11601;
  t11631 = 3.2*t10259*t11128;
  t11429 = t6425*t10369;
  t11463 = t9572*t9997;
  t11472 = t11429 + t11463;
  t11660 = 3.2*t9883*t11091;
  t11682 = 3.2*t10988*t11128;
  t11683 = 3.2*t10954*t11472;
  t11701 = t11631 + t11682 + t11683 + t11660;
  t10002 = -1.*t6425*t9997;
  t11774 = t6440*t9572;
  t11775 = t6425*t9620;
  t11776 = t11774 + t11775;
  t11785 = 0.748*t11776;
  t10003 = t9993 + t10002;
  t11818 = -1.*t6425*t9977;
  t11835 = 3.2*t10259*t10003;
  t10402 = -1.*t6425*t10369;
  t10494 = t10402 + t10489;
  t11836 = -1.*t9572*t10813;
  t11839 = t11818 + t11836;
  t11842 = 3.2*t9883*t11839;
  t11845 = t11785 + t11835 + t11842;
  t12019 = 3.2*t10259*t10862;
  t12023 = t11429 + t11836;
  t12026 = 3.2*t9883*t12023;
  t11854 = 3.2*t10988*t10003;
  t11865 = 3.2*t10954*t10494;
  t11924 = t11835 + t11854 + t11865 + t11842;
  t12058 = 3.2*t10954*t10808;
  t12063 = 3.2*t10988*t10862;
  t12077 = t12058 + t12019 + t12063 + t12026;
  t11316 = -1.*t9839*t9656;
  t11361 = 0.24*t10894;
  t11370 = t11316 + t11361;
  t10036 = 3.2*t9883*t10003;
  t10745 = 3.2*t10259*t10494;
  t10787 = t9644 + t10036 + t10745;
  t10789 = -0.5*var2[2]*t10787;
  t11046 = -0.5*var2[6]*t11032;
  t12328 = t6440*t9839;
  t12340 = -0.24*t9620*t9841;
  t12353 = t12328 + t12340;
  t12228 = -1.*t9839*t9620;
  t12258 = -0.24*t6440*t9841;
  t12305 = t12228 + t12258;
  t12425 = t9839*t9620;
  t12426 = 0.24*t6440*t9841;
  t12440 = t12425 + t12426;
  t12371 = -1.*t6440*t9839;
  t12378 = 0.24*t9620*t9841;
  t12383 = t12371 + t12378;
  t12365 = -1.*t10369*t12353;
  t12614 = -0.24*t9656*t9620;
  t12657 = t12614 + t12258;
  t12470 = -1.*t12440*t10813;
  t12482 = t9977*t12440;
  t12749 = 0.24*t6440*t9656;
  t12751 = t12749 + t12340;
  t12773 = -0.24*t6440*t9656;
  t12774 = t12773 + t12378;
  t12518 = t12353*t10813;
  t12558 = t12305*t9997;
  t12561 = t12440*t9997;
  t12563 = t9977*t12353;
  t12593 = t10369*t12353;
  t12605 = t12558 + t12561 + t12563 + t12593;
  t12609 = 3.2*t10988*t12605;
  t12670 = -1.*t12657*t9997;
  t12725 = -1.*t9977*t12353;
  t12752 = -1.*t9977*t12751;
  t12776 = -1.*t9977*t12774;
  t12778 = -1.*t12305*t10813;
  t12795 = -1.*t12657*t10813;
  t12798 = t12670 + t12725 + t12365 + t12752 + t12776 + t12778 + t12795 + t12470;
  t12804 = 3.2*t10259*t12798;
  t12812 = -1.*t9977*t12305;
  t12821 = -1.*t9977*t12440;
  t12824 = -1.*t9997*t12353;
  t12856 = -1.*t12353*t10813;
  t12862 = t12812 + t12821 + t12824 + t12856;
  t12864 = 3.2*t10954*t12862;
  t12869 = t9977*t12305;
  t12881 = t9977*t12657;
  t12882 = t12657*t10369;
  t12889 = t9997*t12353;
  t12894 = t9997*t12751;
  t12909 = t9997*t12774;
  t12930 = t12869 + t12881 + t12482 + t12882 + t12889 + t12894 + t12909 + t12518;
  t12945 = 3.2*t9883*t12930;
  t12954 = t12609 + t12804 + t12864 + t12945;
  t13004 = -1.*t12440*t9997;
  t13005 = t13004 + t12725;
  t13009 = t12440*t10369;
  t13011 = t13009 + t12889;
  t13013 = t12657*t9997;
  t13016 = t10369*t12751;
  t13017 = t13013 + t12561 + t12563 + t13016;
  t13046 = -1.*t9977*t12657;
  t13057 = -1.*t9997*t12751;
  t13058 = t13046 + t12821 + t13057 + t12856;
  t13150 = 3.2*t10954*t13005;
  t13156 = 3.2*t10988*t13011;
  t13177 = 3.2*t9883*t13017;
  t13199 = 3.2*t10259*t13058;
  t13206 = t13150 + t13156 + t13177 + t13199;
  t13490 = 6.4*t10954*t10259;
  t13500 = 6.4*t10988*t9883;
  t13510 = t13490 + t13500;
  p_output1[0]=var2[5]*(t10789 + t11046 - 0.5*t10889*var2[5]);
  p_output1[1]=var2[5]*(-0.5*t10889*var2[2] - 0.5*(t11087 + t11093 + t9644)*var2[5] - 0.5*t11225*var2[6]);
  p_output1[2]=var2[5]*(-0.5*t11032*var2[2] - 0.5*t11225*var2[5] - 0.5*(t11087 + 6.4*t10988*t11091 + t11093 + 6.4*t10954*t11128 + 3.2*t11128*t11370 + 3.2*t10988*t11472)*var2[6]);
  p_output1[3]=-0.5*t11602*var2[5];
  p_output1[4]=-0.5*t11602*var2[2] - 1.*(t11591 + t11631 + t11660)*var2[5] - 0.5*t11701*var2[6];
  p_output1[5]=-0.5*t11701*var2[5];
  p_output1[6]=var2[5]*(-0.5*(3.2*t10259*(t10002 + t11076) + t11785 + 3.2*(t11463 + t11818)*t9883)*var2[2] - 0.5*t11845*var2[5] - 0.5*t11924*var2[6]);
  p_output1[7]=var2[5]*(-0.5*t11845*var2[2] - 0.5*(t11785 + t12019 + t12026)*var2[5] - 0.5*t12077*var2[6]);
  p_output1[8]=var2[5]*(-0.5*t11924*var2[2] - 0.5*t12077*var2[5] - 0.5*(6.4*t10808*t10954 + 6.4*t10862*t10988 + 3.2*t10958*t10988 + 3.2*t10808*t11370 + t12019 + t12026)*var2[6]);
  p_output1[9]=-0.5*t10787*var2[5];
  p_output1[10]=t10789 + t11046 - 1.*t10889*var2[5];
  p_output1[11]=-0.5*t11032*var2[5];
  p_output1[12]=var2[5]*(-0.5*(3.2*t10259*(-2.*t10813*t12305 + t12365 + t12470 - 2.*t12353*t9977 - 1.*t12383*t9977 - 1.*t12305*t9997) + 3.2*t9883*(t10369*t12305 + t12482 + t12518 + 2.*t12305*t9977 + 2.*t12353*t9997 + t12383*t9997))*var2[5] - 0.5*t12954*var2[6]);
  p_output1[13]=var2[5]*(-0.5*t12954*var2[5] - 0.5*(3.2*t10988*t13005 + 3.2*t11370*t13011 + 6.4*t10988*t13017 + 6.4*t10954*t13058 + 3.2*t10259*(t12365 + t12470 - 2.*t10813*t12657 + t12670 + t12776 - 2.*t12751*t9977) + 3.2*t9883*(t12482 + t12518 + t12882 + t12909 + 2.*t12657*t9977 + 2.*t12751*t9997))*var2[6]);
  p_output1[14]=-1.*(3.2*t10259*t12862 + 3.2*t12605*t9883)*var2[5] - 0.5*t13206*var2[6];
  p_output1[15]=-0.5*t13206*var2[5];
  p_output1[16]=-0.5*(6.4*Power(t10954,2) + 6.4*t10259*t10988 + 6.4*Power(t10988,2) + 6.4*t11370*t9883)*var2[5]*var2[6];
  p_output1[17]=-0.5*t13510*var2[6];
  p_output1[18]=-0.5*t13510*var2[5];
  p_output1[19]=-0.384*t11370*var2[5]*var2[6];
  p_output1[20]=-0.384*t10988*var2[6];
  p_output1[21]=-0.384*t10988*var2[5];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 22, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce1_vec6_five_link_walker.hh"

namespace RightStance
{

void J_Ce1_vec6_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
