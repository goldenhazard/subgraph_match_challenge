/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:32:13 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t131;
  double t1067;
  double t1638;
  double t1595;
  double t2872;
  double t2903;
  double t2929;
  double t2945;
  double t2946;
  double t2953;
  double t2965;
  double t2966;
  double t2968;
  double t2969;
  double t2992;
  double t2996;
  double t3012;
  double t2973;
  double t2974;
  double t2975;
  double t2891;
  double t2923;
  double t2927;
  double t3016;
  double t3017;
  double t3018;
  double t3058;
  double t3060;
  double t3069;
  double t3071;
  double t3076;
  double t3077;
  double t3083;
  double t3086;
  double t3087;
  double t3088;
  double t3089;
  double t3090;
  double t3103;
  double t3106;
  double t3107;
  double t3091;
  double t3092;
  double t3093;
  double t3070;
  double t3072;
  double t3074;
  double t3114;
  double t3115;
  double t3123;
  double t2784;
  double t2800;
  double t2839;
  double t2856;
  double t2868;
  double t3033;
  double t2976;
  double t3019;
  double t3020;
  double t3050;
  double t3051;
  double t3052;
  double t3063;
  double t3064;
  double t3065;
  double t3066;
  double t3067;
  double t3137;
  double t3102;
  double t3127;
  double t3129;
  double t3139;
  double t3140;
  double t3141;
  double t1578;
  double t2721;
  double t2780;
  double t2871;
  double t2947;
  double t3186;
  double t3187;
  double t3030;
  double t3189;
  double t3190;
  double t3194;
  double t3206;
  double t3207;
  double t3208;
  double t3148;
  double t3149;
  double t3150;
  double t3153;
  double t3041;
  double t3196;
  double t3197;
  double t3198;
  double t3202;
  double t3203;
  double t3160;
  double t2928;
  double t2949;
  double t3224;
  double t3225;
  double t3226;
  double t3227;
  double t3238;
  double t3188;
  double t3209;
  double t3210;
  double t3211;
  double t3221;
  double t3222;
  double t3223;
  double t3270;
  double t3272;
  double t3274;
  double t3275;
  double t3259;
  double t3273;
  double t3276;
  double t3277;
  double t3261;
  double t3262;
  double t3263;
  double t3279;
  double t3280;
  double t3281;
  double t3059;
  double t3061;
  double t3062;
  double t3068;
  double t3084;
  double t3299;
  double t3300;
  double t3136;
  double t3302;
  double t3303;
  double t3313;
  double t3330;
  double t3331;
  double t3332;
  double t3169;
  double t3170;
  double t3171;
  double t3172;
  double t3138;
  double t3314;
  double t3315;
  double t3316;
  double t3317;
  double t3318;
  double t3177;
  double t3075;
  double t3085;
  double t8476;
  double t8481;
  double t8492;
  double t8528;
  double t8553;
  double t3301;
  double t3770;
  double t3776;
  double t3778;
  double t8055;
  double t8068;
  double t8256;
  double t11452;
  double t11623;
  double t11755;
  double t11792;
  double t10296;
  double t11651;
  double t11801;
  double t11814;
  double t10386;
  double t10541;
  double t10588;
  double t11994;
  double t12066;
  double t12069;
  double t1066;
  double t3029;
  double t3056;
  double t3131;
  double t3142;
  double t3144;
  double t12926;
  double t12948;
  double t12961;
  double t13056;
  double t13382;
  double t13488;
  double t13529;
  double t13575;
  double t13612;
  double t13613;
  double t13639;
  double t13643;
  double t13664;
  double t13746;
  double t3204;
  double t3239;
  double t3240;
  double t3258;
  double t3260;
  double t3264;
  double t3265;
  double t3267;
  double t3268;
  double t3269;
  double t16242;
  double t16253;
  double t16294;
  double t16043;
  double t16044;
  double t16214;
  double t16224;
  double t16295;
  double t16300;
  double t16305;
  double t3156;
  double t16510;
  double t16512;
  double t3166;
  double t16364;
  double t16366;
  double t16369;
  double t16372;
  double t16377;
  double t16378;
  double t16381;
  double t16716;
  double t16717;
  double t16707;
  double t16347;
  double t16348;
  double t16354;
  double t16779;
  double t16780;
  double t16385;
  double t16386;
  double t16387;
  double t16426;
  double t16774;
  double t16775;
  double t16776;
  double t16777;
  double t16781;
  double t16783;
  double t16508;
  double t16509;
  double t16701;
  double t16708;
  double t16826;
  double t16831;
  double t16832;
  double t16833;
  double t16834;
  double t16840;
  double t16724;
  double t16734;
  double t16735;
  double t16881;
  double t16882;
  double t16883;
  double t16888;
  double t16889;
  double t16905;
  double t16907;
  double t16909;
  double t3278;
  double t3282;
  double t3286;
  double t3288;
  double t3289;
  double t3290;
  double t3294;
  double t3295;
  double t3296;
  double t3298;
  double t16784;
  double t16785;
  double t16786;
  double t16787;
  double t16788;
  double t16841;
  double t16842;
  double t16843;
  double t16845;
  double t16846;
  double t16847;
  double t16848;
  double t16849;
  double t16850;
  double t16851;
  double t16852;
  double t16853;
  double t16854;
  double t16855;
  double t16856;
  double t16857;
  double t16858;
  double t16859;
  double t16860;
  double t16861;
  double t16862;
  double t16863;
  double t16864;
  double t16865;
  double t16866;
  double t16867;
  double t16869;
  double t16873;
  double t16874;
  double t16875;
  double t16876;
  double t16880;
  double t16927;
  double t16928;
  double t16929;
  double t16978;
  double t16984;
  double t16985;
  double t17018;
  double t17019;
  double t17020;
  double t17027;
  double t17028;
  double t17029;
  double t17030;
  double t17031;
  double t3319;
  double t8599;
  double t9605;
  double t9660;
  double t10367;
  double t10685;
  double t10770;
  double t10818;
  double t10820;
  double t11319;
  double t17046;
  double t17047;
  double t17048;
  double t17042;
  double t17043;
  double t17044;
  double t17045;
  double t17049;
  double t17050;
  double t17051;
  double t3173;
  double t17073;
  double t17074;
  double t3178;
  double t17056;
  double t17057;
  double t17058;
  double t17059;
  double t17060;
  double t17061;
  double t17062;
  double t17080;
  double t17081;
  double t17077;
  double t17053;
  double t17054;
  double t17055;
  double t17109;
  double t17110;
  double t17064;
  double t17065;
  double t17066;
  double t17067;
  double t17105;
  double t17106;
  double t17107;
  double t17108;
  double t17111;
  double t17112;
  double t17071;
  double t17072;
  double t17075;
  double t17078;
  double t17118;
  double t17119;
  double t17120;
  double t17121;
  double t17122;
  double t17123;
  double t17086;
  double t17088;
  double t17089;
  double t17156;
  double t17157;
  double t17158;
  double t17159;
  double t17160;
  double t17164;
  double t17165;
  double t17166;
  double t11832;
  double t12457;
  double t12506;
  double t12607;
  double t12702;
  double t12913;
  double t12914;
  double t12917;
  double t12920;
  double t12923;
  double t17113;
  double t17114;
  double t17115;
  double t17116;
  double t17117;
  double t17124;
  double t17125;
  double t17126;
  double t17127;
  double t17128;
  double t17129;
  double t17130;
  double t17131;
  double t17132;
  double t17133;
  double t17134;
  double t17135;
  double t17136;
  double t17137;
  double t17138;
  double t17139;
  double t17140;
  double t17141;
  double t17142;
  double t17143;
  double t17144;
  double t17145;
  double t17146;
  double t17147;
  double t17148;
  double t17149;
  double t17150;
  double t17151;
  double t17152;
  double t17153;
  double t17154;
  double t17155;
  double t17177;
  double t17178;
  double t17179;
  double t17187;
  double t17188;
  double t17189;
  double t17217;
  double t17218;
  double t17219;
  double t17223;
  double t17224;
  double t17225;
  double t17226;
  double t17227;
  t131 = Cos(var1[2]);
  t1067 = Cos(var1[3]);
  t1638 = Sin(var1[3]);
  t1595 = Sin(var1[2]);
  t2872 = Cos(var1[4]);
  t2903 = Sin(var1[4]);
  t2929 = t1067*t2872;
  t2945 = -1.*t1638*t2903;
  t2946 = t2929 + t2945;
  t2953 = -1.*t2872;
  t2965 = 1. + t2953;
  t2966 = 0.4*t2965;
  t2968 = 0.64*t2872;
  t2969 = t2966 + t2968;
  t2992 = -1.*t2872*t1638;
  t2996 = -1.*t1067*t2903;
  t3012 = t2992 + t2996;
  t2973 = t2969*t1638;
  t2974 = 0.24*t1067*t2903;
  t2975 = t2973 + t2974;
  t2891 = t2872*t1638;
  t2923 = t1067*t2903;
  t2927 = t2891 + t2923;
  t3016 = t1067*t2969;
  t3017 = -0.24*t1638*t2903;
  t3018 = t3016 + t3017;
  t3058 = Cos(var1[5]);
  t3060 = Sin(var1[5]);
  t3069 = Cos(var1[6]);
  t3071 = Sin(var1[6]);
  t3076 = t3058*t3069;
  t3077 = -1.*t3060*t3071;
  t3083 = t3076 + t3077;
  t3086 = -1.*t3069;
  t3087 = 1. + t3086;
  t3088 = 0.4*t3087;
  t3089 = 0.64*t3069;
  t3090 = t3088 + t3089;
  t3103 = -1.*t3069*t3060;
  t3106 = -1.*t3058*t3071;
  t3107 = t3103 + t3106;
  t3091 = t3090*t3060;
  t3092 = 0.24*t3058*t3071;
  t3093 = t3091 + t3092;
  t3070 = t3069*t3060;
  t3072 = t3058*t3071;
  t3074 = t3070 + t3072;
  t3114 = t3058*t3090;
  t3115 = -0.24*t3060*t3071;
  t3123 = t3114 + t3115;
  t2784 = Power(t1067,2);
  t2800 = 0.11*t2784;
  t2839 = Power(t1638,2);
  t2856 = 0.11*t2839;
  t2868 = t2800 + t2856;
  t3033 = -1.*t131*t2946;
  t2976 = -1.*t2975*t2946;
  t3019 = -1.*t3012*t3018;
  t3020 = t2976 + t3019;
  t3050 = t2975*t2927;
  t3051 = t2946*t3018;
  t3052 = t3050 + t3051;
  t3063 = Power(t3058,2);
  t3064 = 0.11*t3063;
  t3065 = Power(t3060,2);
  t3066 = 0.11*t3065;
  t3067 = t3064 + t3066;
  t3137 = -1.*t131*t3083;
  t3102 = -1.*t3093*t3083;
  t3127 = -1.*t3107*t3123;
  t3129 = t3102 + t3127;
  t3139 = t3093*t3074;
  t3140 = t3083*t3123;
  t3141 = t3139 + t3140;
  t1578 = -1.*t131*t1067;
  t2721 = t1595*t1638;
  t2780 = t1578 + t2721;
  t2871 = -6.8*t2780*t2868;
  t2947 = -1.*t1595*t2946;
  t3186 = t131*t3012;
  t3187 = t3186 + t2947;
  t3030 = -1.*t1595*t3012;
  t3189 = -1.*t2969*t1638;
  t3190 = -0.24*t1067*t2903;
  t3194 = t3189 + t3190;
  t3206 = -1.*t1067*t2872;
  t3207 = t1638*t2903;
  t3208 = t3206 + t3207;
  t3148 = t1067*t1595;
  t3149 = t131*t1638;
  t3150 = t3148 + t3149;
  t3153 = -6.8*t3150*t2868;
  t3041 = t3030 + t3033;
  t3196 = t3194*t2946;
  t3197 = t2975*t2946;
  t3198 = t3012*t3018;
  t3202 = t2927*t3018;
  t3203 = t3196 + t3197 + t3198 + t3202;
  t3160 = -1.*t131*t3012;
  t2928 = -1.*t131*t2927;
  t2949 = t2928 + t2947;
  t3224 = -1.*t3012*t3194;
  t3225 = -1.*t3012*t2975;
  t3226 = -1.*t2946*t3018;
  t3227 = -1.*t3018*t3208;
  t3238 = t3224 + t3225 + t3226 + t3227;
  t3188 = -3.2*t3187*t3020;
  t3209 = t131*t3208;
  t3210 = t3030 + t3209;
  t3211 = -3.2*t3052*t3210;
  t3221 = -1.*t1595*t2927;
  t3222 = t131*t2946;
  t3223 = t3221 + t3222;
  t3270 = -0.24*t2872*t1638;
  t3272 = t3270 + t3190;
  t3274 = 0.24*t1067*t2872;
  t3275 = t3274 + t3017;
  t3259 = -3.2*t3041*t3020;
  t3273 = t3272*t2946;
  t3276 = t2927*t3275;
  t3277 = t3273 + t3197 + t3198 + t3276;
  t3261 = -1.*t1595*t3208;
  t3262 = t3160 + t3261;
  t3263 = -3.2*t3052*t3262;
  t3279 = -1.*t3012*t3272;
  t3280 = -1.*t2946*t3275;
  t3281 = t3279 + t3225 + t3280 + t3227;
  t3059 = -1.*t131*t3058;
  t3061 = t1595*t3060;
  t3062 = t3059 + t3061;
  t3068 = -6.8*t3062*t3067;
  t3084 = -1.*t1595*t3083;
  t3299 = t131*t3107;
  t3300 = t3299 + t3084;
  t3136 = -1.*t1595*t3107;
  t3302 = -1.*t3090*t3060;
  t3303 = -0.24*t3058*t3071;
  t3313 = t3302 + t3303;
  t3330 = -1.*t3058*t3069;
  t3331 = t3060*t3071;
  t3332 = t3330 + t3331;
  t3169 = t3058*t1595;
  t3170 = t131*t3060;
  t3171 = t3169 + t3170;
  t3172 = -6.8*t3171*t3067;
  t3138 = t3136 + t3137;
  t3314 = t3313*t3083;
  t3315 = t3093*t3083;
  t3316 = t3107*t3123;
  t3317 = t3074*t3123;
  t3318 = t3314 + t3315 + t3316 + t3317;
  t3177 = -1.*t131*t3107;
  t3075 = -1.*t131*t3074;
  t3085 = t3075 + t3084;
  t8476 = -1.*t3107*t3313;
  t8481 = -1.*t3107*t3093;
  t8492 = -1.*t3083*t3123;
  t8528 = -1.*t3123*t3332;
  t8553 = t8476 + t8481 + t8492 + t8528;
  t3301 = -3.2*t3300*t3129;
  t3770 = t131*t3332;
  t3776 = t3136 + t3770;
  t3778 = -3.2*t3141*t3776;
  t8055 = -1.*t1595*t3074;
  t8068 = t131*t3083;
  t8256 = t8055 + t8068;
  t11452 = -0.24*t3069*t3060;
  t11623 = t11452 + t3303;
  t11755 = 0.24*t3058*t3069;
  t11792 = t11755 + t3115;
  t10296 = -3.2*t3138*t3129;
  t11651 = t11623*t3083;
  t11801 = t3074*t11792;
  t11814 = t11651 + t3315 + t3316 + t11801;
  t10386 = -1.*t1595*t3332;
  t10541 = t3177 + t10386;
  t10588 = -3.2*t3141*t10541;
  t11994 = -1.*t3107*t11623;
  t12066 = -1.*t3083*t11792;
  t12069 = t11994 + t8481 + t12066 + t8528;
  t1066 = 2.88*t131;
  t3029 = -3.2*t2949*t3020;
  t3056 = -3.2*t3041*t3052;
  t3131 = -3.2*t3085*t3129;
  t3142 = -3.2*t3138*t3141;
  t3144 = t1066 + t2871 + t3029 + t3056 + t3068 + t3131 + t3142;
  t12926 = 2.88*t1595;
  t12948 = -1.*t1067*t1595;
  t12961 = -1.*t131*t1638;
  t13056 = t12948 + t12961;
  t13382 = -6.8*t13056*t2868;
  t13488 = -3.2*t3223*t3020;
  t13529 = -3.2*t3187*t3052;
  t13575 = -1.*t3058*t1595;
  t13612 = -1.*t131*t3060;
  t13613 = t13575 + t13612;
  t13639 = -6.8*t13613*t3067;
  t13643 = -3.2*t8256*t3129;
  t13664 = -3.2*t3300*t3141;
  t13746 = t12926 + t13382 + t13488 + t13529 + t13639 + t13643 + t13664;
  t3204 = -3.2*t3187*t3203;
  t3239 = -3.2*t3223*t3238;
  t3240 = t2871 + t3188 + t3204 + t3211 + t3239;
  t3258 = -0.5*var2[0]*t3240;
  t3260 = -3.2*t3041*t3203;
  t3264 = -3.2*t2949*t3238;
  t3265 = t3153 + t3259 + t3260 + t3263 + t3264;
  t3267 = -0.5*var2[1]*t3265;
  t3268 = t3258 + t3267;
  t3269 = var2[2]*t3268;
  t16242 = -1.*t1067*t2969;
  t16253 = 0.24*t1638*t2903;
  t16294 = t16242 + t16253;
  t16043 = 2.*t3012*t3194;
  t16044 = t3012*t2975;
  t16214 = t3194*t2927;
  t16224 = 2.*t2946*t3018;
  t16295 = t2946*t16294;
  t16300 = t3018*t3208;
  t16305 = t16043 + t16044 + t16214 + t16224 + t16295 + t16300;
  t3156 = t1595*t2927;
  t16510 = t1595*t3208;
  t16512 = t3186 + t16510;
  t3166 = t1595*t2946;
  t16364 = -1.*t3194*t2946;
  t16366 = -2.*t3012*t3018;
  t16369 = -1.*t2927*t3018;
  t16372 = -1.*t3012*t16294;
  t16377 = -2.*t3194*t3208;
  t16378 = -1.*t2975*t3208;
  t16381 = t16364 + t16366 + t16369 + t16372 + t16377 + t16378;
  t16716 = t1595*t3012;
  t16717 = t16716 + t3222;
  t16707 = t131*t2927;
  t16347 = t2969*t2903;
  t16348 = -0.24*t2872*t2903;
  t16354 = t16347 + t16348;
  t16779 = -0.24*t1067*t2872;
  t16780 = t16779 + t16253;
  t16385 = t2969*t2872;
  t16386 = Power(t2903,2);
  t16387 = 0.24*t16386;
  t16426 = t16385 + t16387;
  t16774 = t3012*t3194;
  t16775 = t3012*t3272;
  t16776 = t3272*t2927;
  t16777 = t2946*t3275;
  t16781 = t2946*t16780;
  t16783 = t16774 + t16775 + t16044 + t16776 + t3051 + t16777 + t16781 + t16300;
  t16508 = t3156 + t3209;
  t16509 = -3.2*t3052*t16508;
  t16701 = -3.2*t3020*t16512;
  t16708 = t16707 + t3166;
  t16826 = -1.*t3272*t2946;
  t16831 = -1.*t3012*t3275;
  t16832 = -1.*t3012*t16780;
  t16833 = -1.*t3194*t3208;
  t16834 = -1.*t3272*t3208;
  t16840 = t16826 + t3019 + t16369 + t16831 + t16832 + t16833 + t16834 + t16378;
  t16724 = -3.2*t3020*t3210;
  t16734 = t16707 + t3261;
  t16735 = -3.2*t3052*t16734;
  t16881 = -3.2*t16717*t3020;
  t16882 = -3.2*t16717*t3203;
  t16883 = -3.2*t3052*t16512;
  t16888 = -3.2*t16708*t3238;
  t16889 = t13382 + t16881 + t16882 + t16883 + t16888;
  t16905 = -3.2*t16426*t3203;
  t16907 = -3.2*t16354*t3238;
  t16909 = t16905 + t16907;
  t3278 = -3.2*t3187*t3277;
  t3282 = -3.2*t3223*t3281;
  t3286 = t3188 + t3278 + t3211 + t3282;
  t3288 = -0.5*var2[0]*t3286;
  t3289 = -3.2*t3041*t3277;
  t3290 = -3.2*t2949*t3281;
  t3294 = t3259 + t3289 + t3263 + t3290;
  t3295 = -0.5*var2[1]*t3294;
  t3296 = t3288 + t3295;
  t3298 = var2[2]*t3296;
  t16784 = 0.384*var2[4]*t16783;
  t16785 = -1.*t2969*t2903;
  t16786 = 0.24*t2872*t2903;
  t16787 = t16785 + t16786;
  t16788 = -3.2*t16787*t3203;
  t16841 = -3.2*t16354*t16840;
  t16842 = Power(t2872,2);
  t16843 = -0.24*t16842;
  t16845 = t16385 + t16843;
  t16846 = -3.2*t16845*t3238;
  t16847 = -3.2*t16426*t16783;
  t16848 = t16788 + t16841 + t16846 + t16847;
  t16849 = -0.5*var2[3]*t16848;
  t16850 = -3.2*t3203*t16512;
  t16851 = -3.2*t3277*t16512;
  t16852 = -3.2*t16708*t16840;
  t16853 = -3.2*t16717*t3238;
  t16854 = -3.2*t16717*t3281;
  t16855 = -3.2*t16717*t16783;
  t16856 = t16509 + t16701 + t16850 + t16851 + t16852 + t16853 + t16854 + t16855;
  t16857 = -0.5*var2[0]*t16856;
  t16858 = -3.2*t3203*t3210;
  t16859 = -3.2*t3277*t3210;
  t16860 = -3.2*t3223*t16840;
  t16861 = -3.2*t3187*t3238;
  t16862 = -3.2*t3187*t3281;
  t16863 = -3.2*t3187*t16783;
  t16864 = t16724 + t16858 + t16859 + t16735 + t16860 + t16861 + t16862 + t16863;
  t16865 = -0.5*var2[1]*t16864;
  t16866 = -6.4*t3203*t3277;
  t16867 = -6.4*t3020*t16840;
  t16869 = -6.4*t3238*t3281;
  t16873 = -6.4*t3052*t16783;
  t16874 = t16866 + t16867 + t16869 + t16873;
  t16875 = -0.5*var2[2]*t16874;
  t16876 = t16784 + t16849 + t16857 + t16865 + t16875;
  t16880 = var2[2]*t16876;
  t16927 = 2.*t3012*t3272;
  t16928 = 2.*t2946*t3275;
  t16929 = t16927 + t16044 + t16776 + t16928 + t16781 + t16300;
  t16978 = -2.*t3012*t3275;
  t16984 = -2.*t3272*t3208;
  t16985 = t16826 + t16369 + t16978 + t16832 + t16984 + t16378;
  t17018 = -3.2*t16717*t3277;
  t17019 = -3.2*t16708*t3281;
  t17020 = t16881 + t17018 + t16883 + t17019;
  t17027 = -3.2*t16845*t3020;
  t17028 = -3.2*t16787*t3052;
  t17029 = -3.2*t16426*t3277;
  t17030 = -3.2*t16354*t3281;
  t17031 = t17027 + t17028 + t17029 + t17030;
  t3319 = -3.2*t3300*t3318;
  t8599 = -3.2*t8256*t8553;
  t9605 = t3068 + t3301 + t3319 + t3778 + t8599;
  t9660 = -0.5*var2[0]*t9605;
  t10367 = -3.2*t3138*t3318;
  t10685 = -3.2*t3085*t8553;
  t10770 = t3172 + t10296 + t10367 + t10588 + t10685;
  t10818 = -0.5*var2[1]*t10770;
  t10820 = t9660 + t10818;
  t11319 = var2[2]*t10820;
  t17046 = -1.*t3058*t3090;
  t17047 = 0.24*t3060*t3071;
  t17048 = t17046 + t17047;
  t17042 = 2.*t3107*t3313;
  t17043 = t3107*t3093;
  t17044 = t3313*t3074;
  t17045 = 2.*t3083*t3123;
  t17049 = t3083*t17048;
  t17050 = t3123*t3332;
  t17051 = t17042 + t17043 + t17044 + t17045 + t17049 + t17050;
  t3173 = t1595*t3074;
  t17073 = t1595*t3332;
  t17074 = t3299 + t17073;
  t3178 = t1595*t3083;
  t17056 = -1.*t3313*t3083;
  t17057 = -2.*t3107*t3123;
  t17058 = -1.*t3074*t3123;
  t17059 = -1.*t3107*t17048;
  t17060 = -2.*t3313*t3332;
  t17061 = -1.*t3093*t3332;
  t17062 = t17056 + t17057 + t17058 + t17059 + t17060 + t17061;
  t17080 = t1595*t3107;
  t17081 = t17080 + t8068;
  t17077 = t131*t3074;
  t17053 = t3090*t3071;
  t17054 = -0.24*t3069*t3071;
  t17055 = t17053 + t17054;
  t17109 = -0.24*t3058*t3069;
  t17110 = t17109 + t17047;
  t17064 = t3090*t3069;
  t17065 = Power(t3071,2);
  t17066 = 0.24*t17065;
  t17067 = t17064 + t17066;
  t17105 = t3107*t3313;
  t17106 = t3107*t11623;
  t17107 = t11623*t3074;
  t17108 = t3083*t11792;
  t17111 = t3083*t17110;
  t17112 = t17105 + t17106 + t17043 + t17107 + t3140 + t17108 + t17111 + t17050;
  t17071 = t3173 + t3770;
  t17072 = -3.2*t3141*t17071;
  t17075 = -3.2*t3129*t17074;
  t17078 = t17077 + t3178;
  t17118 = -1.*t11623*t3083;
  t17119 = -1.*t3107*t11792;
  t17120 = -1.*t3107*t17110;
  t17121 = -1.*t3313*t3332;
  t17122 = -1.*t11623*t3332;
  t17123 = t17118 + t3127 + t17058 + t17119 + t17120 + t17121 + t17122 + t17061;
  t17086 = -3.2*t3129*t3776;
  t17088 = t17077 + t10386;
  t17089 = -3.2*t3141*t17088;
  t17156 = -3.2*t17081*t3129;
  t17157 = -3.2*t17081*t3318;
  t17158 = -3.2*t3141*t17074;
  t17159 = -3.2*t17078*t8553;
  t17160 = t13639 + t17156 + t17157 + t17158 + t17159;
  t17164 = -3.2*t17067*t3318;
  t17165 = -3.2*t17055*t8553;
  t17166 = t17164 + t17165;
  t11832 = -3.2*t3300*t11814;
  t12457 = -3.2*t8256*t12069;
  t12506 = t3301 + t11832 + t3778 + t12457;
  t12607 = -0.5*var2[0]*t12506;
  t12702 = -3.2*t3138*t11814;
  t12913 = -3.2*t3085*t12069;
  t12914 = t10296 + t12702 + t10588 + t12913;
  t12917 = -0.5*var2[1]*t12914;
  t12920 = t12607 + t12917;
  t12923 = var2[2]*t12920;
  t17113 = 0.384*var2[6]*t17112;
  t17114 = -1.*t3090*t3071;
  t17115 = 0.24*t3069*t3071;
  t17116 = t17114 + t17115;
  t17117 = -3.2*t17116*t3318;
  t17124 = -3.2*t17055*t17123;
  t17125 = Power(t3069,2);
  t17126 = -0.24*t17125;
  t17127 = t17064 + t17126;
  t17128 = -3.2*t17127*t8553;
  t17129 = -3.2*t17067*t17112;
  t17130 = t17117 + t17124 + t17128 + t17129;
  t17131 = -0.5*var2[5]*t17130;
  t17132 = -3.2*t3318*t17074;
  t17133 = -3.2*t11814*t17074;
  t17134 = -3.2*t17078*t17123;
  t17135 = -3.2*t17081*t8553;
  t17136 = -3.2*t17081*t12069;
  t17137 = -3.2*t17081*t17112;
  t17138 = t17072 + t17075 + t17132 + t17133 + t17134 + t17135 + t17136 + t17137;
  t17139 = -0.5*var2[0]*t17138;
  t17140 = -3.2*t3318*t3776;
  t17141 = -3.2*t11814*t3776;
  t17142 = -3.2*t8256*t17123;
  t17143 = -3.2*t3300*t8553;
  t17144 = -3.2*t3300*t12069;
  t17145 = -3.2*t3300*t17112;
  t17146 = t17086 + t17140 + t17141 + t17089 + t17142 + t17143 + t17144 + t17145;
  t17147 = -0.5*var2[1]*t17146;
  t17148 = -6.4*t3318*t11814;
  t17149 = -6.4*t3129*t17123;
  t17150 = -6.4*t8553*t12069;
  t17151 = -6.4*t3141*t17112;
  t17152 = t17148 + t17149 + t17150 + t17151;
  t17153 = -0.5*var2[2]*t17152;
  t17154 = t17113 + t17131 + t17139 + t17147 + t17153;
  t17155 = var2[2]*t17154;
  t17177 = 2.*t3107*t11623;
  t17178 = 2.*t3083*t11792;
  t17179 = t17177 + t17043 + t17107 + t17178 + t17111 + t17050;
  t17187 = -2.*t3107*t11792;
  t17188 = -2.*t11623*t3332;
  t17189 = t17118 + t17058 + t17187 + t17120 + t17188 + t17061;
  t17217 = -3.2*t17081*t11814;
  t17218 = -3.2*t17078*t12069;
  t17219 = t17156 + t17217 + t17158 + t17218;
  t17223 = -3.2*t17127*t3129;
  t17224 = -3.2*t17116*t3141;
  t17225 = -3.2*t17067*t11814;
  t17226 = -3.2*t17055*t12069;
  t17227 = t17223 + t17224 + t17225 + t17226;
  p_output1[0]=(-0.5*t3144*var2[0] - 0.5*(-2.88*t1595 + t3153 - 3.2*t3020*(t3033 + t3156) - 3.2*t3052*(t3160 + t3166) + t3172 - 3.2*t3129*(t3137 + t3173) - 3.2*t3141*(t3177 + t3178))*var2[1])*var2[2];
  p_output1[1]=t3269;
  p_output1[2]=t3298;
  p_output1[3]=t11319;
  p_output1[4]=t12923;
  p_output1[5]=-0.5*t13746*var2[2];
  p_output1[6]=-0.5*t3144*var2[2];
  p_output1[7]=-0.5*t13746*var2[0] - 0.5*t3144*var2[1];
  p_output1[8]=t3269;
  p_output1[9]=var2[2]*(-0.5*(t16509 + t16701 - 3.2*t16381*t16708 - 3.2*t16305*t16717 + t2871 - 6.4*t16512*t3203 - 6.4*t16717*t3238)*var2[0] - 0.5*(t16724 + t16735 + t3153 - 3.2*t16305*t3187 - 6.4*t3203*t3210 - 3.2*t16381*t3223 - 6.4*t3187*t3238)*var2[1] - 0.5*(-6.4*t16381*t3020 - 6.4*t16305*t3052 - 6.4*Power(t3203,2) - 6.4*Power(t3238,2))*var2[2] - 0.5*(-3.2*t16354*t16381 - 3.2*t16305*t16426)*var2[3] + 0.384*t16305*var2[4]);
  p_output1[10]=t16880;
  p_output1[11]=-0.5*t16889*var2[2];
  p_output1[12]=-0.5*t3240*var2[2];
  p_output1[13]=-0.5*t16889*var2[0] - 0.5*t3240*var2[1] - 1.*(-6.4*t3052*t3203 - 6.4*t3020*t3238)*var2[2] - 0.5*t16909*var2[3] + 0.384*t3203*var2[4];
  p_output1[14]=-0.5*t16909*var2[2];
  p_output1[15]=0.384*t3203*var2[2];
  p_output1[16]=t3298;
  p_output1[17]=t16880;
  p_output1[18]=var2[2]*(-0.5*(t16509 + t16701 - 3.2*t16717*t16929 - 3.2*t16708*t16985 - 6.4*t16512*t3277 - 6.4*t16717*t3281)*var2[0] - 0.5*(t16724 + t16735 - 3.2*t16929*t3187 - 3.2*t16985*t3223 - 6.4*t3210*t3277 - 6.4*t3187*t3281)*var2[1] - 0.5*(-6.4*t16985*t3020 - 6.4*t16929*t3052 - 6.4*Power(t3277,2) - 6.4*Power(t3281,2))*var2[2] - 0.5*(-3.2*t16426*t16929 - 3.2*t16354*t16985 - 3.2*t16787*t3020 - 3.2*(0.24*t16842 - 1.*t2872*t2969)*t3052 - 6.4*t16787*t3277 - 6.4*t16845*t3281)*var2[3] + 0.384*t16929*var2[4]);
  p_output1[19]=-0.5*t17020*var2[2];
  p_output1[20]=-0.5*t3286*var2[2];
  p_output1[21]=-0.5*t17020*var2[0] - 0.5*t3286*var2[1] - 1.*(-6.4*t3052*t3277 - 6.4*t3020*t3281)*var2[2] - 0.5*t17031*var2[3] + 0.384*t3277*var2[4];
  p_output1[22]=-0.5*t17031*var2[2];
  p_output1[23]=0.384*t3277*var2[2];
  p_output1[24]=t11319;
  p_output1[25]=var2[2]*(-0.5*(t17072 + t17075 - 3.2*t17062*t17078 - 3.2*t17051*t17081 + t3068 - 6.4*t17074*t3318 - 6.4*t17081*t8553)*var2[0] - 0.5*(t17086 + t17089 + t3172 - 3.2*t17051*t3300 - 6.4*t3318*t3776 - 3.2*t17062*t8256 - 6.4*t3300*t8553)*var2[1] - 0.5*(-6.4*t17062*t3129 - 6.4*t17051*t3141 - 6.4*Power(t3318,2) - 6.4*Power(t8553,2))*var2[2] - 0.5*(-3.2*t17055*t17062 - 3.2*t17051*t17067)*var2[5] + 0.384*t17051*var2[6]);
  p_output1[26]=t17155;
  p_output1[27]=-0.5*t17160*var2[2];
  p_output1[28]=-0.5*t9605*var2[2];
  p_output1[29]=-0.5*t17160*var2[0] - 0.5*t9605*var2[1] - 1.*(-6.4*t3141*t3318 - 6.4*t3129*t8553)*var2[2] - 0.5*t17166*var2[5] + 0.384*t3318*var2[6];
  p_output1[30]=-0.5*t17166*var2[2];
  p_output1[31]=0.384*t3318*var2[2];
  p_output1[32]=t12923;
  p_output1[33]=t17155;
  p_output1[34]=var2[2]*(-0.5*(t17072 - 6.4*t11814*t17074 + t17075 - 6.4*t12069*t17081 - 3.2*t17081*t17179 - 3.2*t17078*t17189)*var2[0] - 0.5*(t17086 + t17089 - 6.4*t12069*t3300 - 3.2*t17179*t3300 - 6.4*t11814*t3776 - 3.2*t17189*t8256)*var2[1] - 0.5*(-6.4*Power(t11814,2) - 6.4*Power(t12069,2) - 6.4*t17189*t3129 - 6.4*t17179*t3141)*var2[2] - 0.5*(-6.4*t11814*t17116 - 6.4*t12069*t17127 - 3.2*t17067*t17179 - 3.2*t17055*t17189 - 3.2*t17116*t3129 - 3.2*(0.24*t17125 - 1.*t3069*t3090)*t3141)*var2[5] + 0.384*t17179*var2[6]);
  p_output1[35]=-0.5*t17219*var2[2];
  p_output1[36]=-0.5*t12506*var2[2];
  p_output1[37]=-0.5*t17219*var2[0] - 0.5*t12506*var2[1] - 1.*(-6.4*t12069*t3129 - 6.4*t11814*t3141)*var2[2] - 0.5*t17227*var2[5] + 0.384*t11814*var2[6];
  p_output1[38]=-0.5*t17227*var2[2];
  p_output1[39]=0.384*t11814*var2[2];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 40, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce3_vec3_five_link_walker.hh"

namespace RightStance
{

void J_Ce3_vec3_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
