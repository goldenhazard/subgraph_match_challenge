/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:34:18 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2,const double *var3,const double *var4)
{
  double t2587;
  double t2584;
  double t2585;
  double t2588;
  double t2592;
  double t2583;
  double t2586;
  double t2589;
  double t2590;
  double t2591;
  double t2593;
  double t2594;
  double t2595;
  double t2596;
  double t2597;
  double t2615;
  double t2616;
  double t2617;
  double t2618;
  double t2619;
  double t10338;
  double t9772;
  double t9806;
  double t10368;
  double t10056;
  double t10370;
  double t10397;
  double t10605;
  double t10639;
  double t10654;
  double t10695;
  double t10696;
  double t10700;
  double t10844;
  double t10987;
  double t11105;
  double t11106;
  double t11121;
  double t2605;
  double t2606;
  double t2607;
  double t3981;
  double t8277;
  double t8394;
  double t8487;
  double t8541;
  double t8670;
  double t10769;
  double t10771;
  double t10782;
  double t11171;
  double t11180;
  double t11183;
  double t11185;
  double t11190;
  double t11191;
  double t11222;
  double t11233;
  double t11234;
  double t11270;
  double t11273;
  double t11274;
  double t11442;
  double t11443;
  double t11444;
  double t11447;
  double t11450;
  double t11453;
  double t11495;
  double t11496;
  double t11497;
  double t11527;
  double t11532;
  double t11534;
  double t2581;
  double t2582;
  double t11236;
  double t11237;
  double t11238;
  double t2599;
  double t2604;
  double t11204;
  double t11218;
  double t11219;
  double t3689;
  double t3760;
  double t3795;
  double t11240;
  double t11241;
  double t2624;
  double t2625;
  double t2626;
  double t2627;
  double t9641;
  double t9654;
  double t11278;
  double t11279;
  double t11280;
  double t10727;
  double t10734;
  double t11243;
  double t11244;
  double t11245;
  double t11135;
  double t11145;
  double t11155;
  double t11322;
  double t11323;
  double t11123;
  double t11124;
  double t11125;
  double t11126;
  double t11202;
  double t11203;
  double t11354;
  double t11385;
  double t11387;
  double t11391;
  double t11396;
  double t11397;
  double t11410;
  double t11411;
  double t11330;
  double t11345;
  double t11220;
  double t11235;
  double t11239;
  double t11242;
  double t11260;
  double t11276;
  double t11321;
  double t11324;
  double t11325;
  double t11428;
  double t11431;
  double t11433;
  double t11434;
  double t11435;
  double t11436;
  double t11438;
  double t11446;
  double t11473;
  double t11475;
  double t11480;
  double t11481;
  double t11482;
  double t11489;
  double t11490;
  double t11491;
  double t11492;
  double t11493;
  double t11521;
  double t11535;
  double t11536;
  double t11550;
  double t11551;
  double t11552;
  double t15116;
  double t15122;
  double t15123;
  double t11432;
  double t11439;
  double t11477;
  double t11488;
  double t11494;
  double t11537;
  double t11554;
  double t11555;
  double t12761;
  double t12764;
  double t12767;
  double t12780;
  double t12808;
  double t12838;
  double t12851;
  double t12852;
  double t13154;
  double t13604;
  double t13614;
  double t13627;
  double t13662;
  double t13674;
  double t13713;
  double t13739;
  double t15094;
  double t15124;
  double t15125;
  double t15207;
  double t15208;
  double t15220;
  double t15288;
  double t15290;
  double t11565;
  double t11568;
  double t11590;
  double t11610;
  double t2608;
  double t2628;
  double t8672;
  double t9526;
  double t15336;
  double t15338;
  double t15339;
  double t15341;
  double t15443;
  double t15444;
  double t15299;
  double t15312;
  double t11668;
  double t11678;
  double t11720;
  double t11721;
  double t10811;
  double t11127;
  double t11198;
  double t11199;
  double t15351;
  double t15352;
  double t15354;
  double t15355;
  double t15507;
  double t15511;
  double t15348;
  double t15349;
  t2587 = Cos(var2[3]);
  t2584 = Cos(var2[4]);
  t2585 = Sin(var2[3]);
  t2588 = Sin(var2[4]);
  t2592 = Cos(var2[2]);
  t2583 = Sin(var2[2]);
  t2586 = -1.*t2584*t2585;
  t2589 = -1.*t2587*t2588;
  t2590 = t2586 + t2589;
  t2591 = t2583*t2590;
  t2593 = t2587*t2584;
  t2594 = -1.*t2585*t2588;
  t2595 = t2593 + t2594;
  t2596 = t2592*t2595;
  t2597 = t2591 + t2596;
  t2615 = -1.*t2584;
  t2616 = 1. + t2615;
  t2617 = 0.4*t2616;
  t2618 = 0.64*t2584;
  t2619 = t2617 + t2618;
  t10338 = Cos(var2[5]);
  t9772 = Cos(var2[6]);
  t9806 = Sin(var2[5]);
  t10368 = Sin(var2[6]);
  t10056 = -1.*t9772*t9806;
  t10370 = -1.*t10338*t10368;
  t10397 = t10056 + t10370;
  t10605 = t2583*t10397;
  t10639 = t10338*t9772;
  t10654 = -1.*t9806*t10368;
  t10695 = t10639 + t10654;
  t10696 = t2592*t10695;
  t10700 = t10605 + t10696;
  t10844 = -1.*t9772;
  t10987 = 1. + t10844;
  t11105 = 0.4*t10987;
  t11106 = 0.64*t9772;
  t11121 = t11105 + t11106;
  t2605 = t2592*t2587;
  t2606 = -1.*t2583*t2585;
  t2607 = t2605 + t2606;
  t3981 = t2584*t2585;
  t8277 = t2587*t2588;
  t8394 = t3981 + t8277;
  t8487 = t2592*t8394;
  t8541 = t2583*t2595;
  t8670 = t8487 + t8541;
  t10769 = t2592*t10338;
  t10771 = -1.*t2583*t9806;
  t10782 = t10769 + t10771;
  t11171 = t9772*t9806;
  t11180 = t10338*t10368;
  t11183 = t11171 + t11180;
  t11185 = t2592*t11183;
  t11190 = t2583*t10695;
  t11191 = t11185 + t11190;
  t11222 = t2587*t2583;
  t11233 = t2592*t2585;
  t11234 = t11222 + t11233;
  t11270 = t10338*t2583;
  t11273 = t2592*t9806;
  t11274 = t11270 + t11273;
  t11442 = t2619*t2585;
  t11443 = 0.24*t2587*t2588;
  t11444 = t11442 + t11443;
  t11447 = t2587*t2619;
  t11450 = -0.24*t2585*t2588;
  t11453 = t11447 + t11450;
  t11495 = t11121*t9806;
  t11496 = 0.24*t10338*t10368;
  t11497 = t11495 + t11496;
  t11527 = t10338*t11121;
  t11532 = -0.24*t9806*t10368;
  t11534 = t11527 + t11532;
  t2581 = -1.*var1[6];
  t2582 = var3[4] + t2581;
  t11236 = t2592*t2590;
  t11237 = -1.*t2583*t2595;
  t11238 = t11236 + t11237;
  t2599 = -1.*var1[5];
  t2604 = var3[3] + t2599;
  t11204 = -1.*t2587*t2583;
  t11218 = -1.*t2592*t2585;
  t11219 = t11204 + t11218;
  t3689 = t2619*t2588;
  t3760 = -0.24*t2584*t2588;
  t3795 = t3689 + t3760;
  t11240 = -1.*t2583*t8394;
  t11241 = t11240 + t2596;
  t2624 = t2619*t2584;
  t2625 = Power(t2588,2);
  t2626 = 0.24*t2625;
  t2627 = t2624 + t2626;
  t9641 = -1.*var1[4];
  t9654 = var3[6] + t9641;
  t11278 = t2592*t10397;
  t11279 = -1.*t2583*t10695;
  t11280 = t11278 + t11279;
  t10727 = -1.*var1[3];
  t10734 = var3[5] + t10727;
  t11243 = -1.*t10338*t2583;
  t11244 = -1.*t2592*t9806;
  t11245 = t11243 + t11244;
  t11135 = t11121*t10368;
  t11145 = -0.24*t9772*t10368;
  t11155 = t11135 + t11145;
  t11322 = -1.*t2583*t11183;
  t11323 = t11322 + t10696;
  t11123 = t11121*t9772;
  t11124 = Power(t10368,2);
  t11125 = 0.24*t11124;
  t11126 = t11123 + t11125;
  t11202 = -1.*var1[1];
  t11203 = var3[1] + t11202;
  t11354 = Power(t2592,2);
  t11385 = 12.*t11354;
  t11387 = Power(t2583,2);
  t11391 = 12.*t11387;
  t11396 = Power(t2607,2);
  t11397 = 6.8*t11396;
  t11410 = Power(t10782,2);
  t11411 = 6.8*t11410;
  t11330 = -1.*var1[0];
  t11345 = var3[0] + t11330;
  t11220 = 6.8*t11219*t2607;
  t11235 = 6.8*t11234*t2607;
  t11239 = 3.2*t2597*t11238;
  t11242 = 3.2*t11241*t8670;
  t11260 = 6.8*t11245*t10782;
  t11276 = 6.8*t11274*t10782;
  t11321 = 3.2*t10700*t11280;
  t11324 = 3.2*t11323*t11191;
  t11325 = t11220 + t11235 + t11239 + t11242 + t11260 + t11276 + t11321 + t11324;
  t11428 = -1.*var1[2];
  t11431 = var3[2] + t11428;
  t11433 = Power(t2587,2);
  t11434 = 0.11*t11433;
  t11435 = Power(t2585,2);
  t11436 = 0.11*t11435;
  t11438 = t11434 + t11436;
  t11446 = -1.*t11444*t2595;
  t11473 = -1.*t2590*t11453;
  t11475 = t11446 + t11473;
  t11480 = t11444*t8394;
  t11481 = t2595*t11453;
  t11482 = t11480 + t11481;
  t11489 = Power(t10338,2);
  t11490 = 0.11*t11489;
  t11491 = Power(t9806,2);
  t11492 = 0.11*t11491;
  t11493 = t11490 + t11492;
  t11521 = -1.*t11497*t10695;
  t11535 = -1.*t10397*t11534;
  t11536 = t11521 + t11535;
  t11550 = t11497*t11183;
  t11551 = t10695*t11534;
  t11552 = t11550 + t11551;
  t15116 = -1.*t2592*t2587;
  t15122 = t2583*t2585;
  t15123 = t15116 + t15122;
  t11432 = 2.88*t2592;
  t11439 = 6.8*t2607*t11438;
  t11477 = 3.2*t8670*t11475;
  t11488 = 3.2*t2597*t11482;
  t11494 = 6.8*t10782*t11493;
  t11537 = 3.2*t11191*t11536;
  t11554 = 3.2*t10700*t11552;
  t11555 = t11432 + t11439 + t11477 + t11488 + t11494 + t11537 + t11554;
  t12761 = -2.88*t2583;
  t12764 = 6.8*t11219*t11438;
  t12767 = 3.2*t11241*t11475;
  t12780 = 3.2*t11238*t11482;
  t12808 = 6.8*t11245*t11493;
  t12838 = 3.2*t11323*t11536;
  t12851 = 3.2*t11280*t11552;
  t12852 = t12761 + t12764 + t12767 + t12780 + t12808 + t12838 + t12851;
  t13154 = 0.4*t2616*t2607;
  t13604 = -0.4*t11219*t2588;
  t13614 = t2584*t2607;
  t13627 = t11219*t2588;
  t13662 = t13614 + t13627;
  t13674 = 0.8*t13662;
  t13713 = t13154 + t13604 + t13674;
  t13739 = -1.*var4[0]*t13713;
  t15094 = 0.4*t2616*t11219;
  t15124 = -0.4*t15123*t2588;
  t15125 = t2584*t11219;
  t15207 = t15123*t2588;
  t15208 = t15125 + t15207;
  t15220 = 0.8*t15208;
  t15288 = t15094 + t15124 + t15220;
  t15290 = -1.*var4[2]*t15288;
  t11565 = 0.748*t11219;
  t11568 = 3.2*t3795*t11241;
  t11590 = 3.2*t2627*t11238;
  t11610 = t11565 + t11568 + t11590;
  t2608 = 0.748*t2607;
  t2628 = 3.2*t2627*t2597;
  t8672 = 3.2*t3795*t8670;
  t9526 = t2608 + t2628 + t8672;
  t15336 = 0.748*t11438;
  t15338 = 3.2*t3795*t11475;
  t15339 = 3.2*t2627*t11482;
  t15341 = 0.67 + t15336 + t15338 + t15339;
  t15443 = 0.768*t2627;
  t15444 = 0.2 + t15443;
  t15299 = 0.768*t11482;
  t15312 = 0.2 + t15299;
  t11668 = 0.748*t11245;
  t11678 = 3.2*t11155*t11323;
  t11720 = 3.2*t11126*t11280;
  t11721 = t11668 + t11678 + t11720;
  t10811 = 0.748*t10782;
  t11127 = 3.2*t11126*t10700;
  t11198 = 3.2*t11155*t11191;
  t11199 = t10811 + t11127 + t11198;
  t15351 = 0.748*t11493;
  t15352 = 3.2*t11155*t11536;
  t15354 = 3.2*t11126*t11552;
  t15355 = 0.67 + t15351 + t15352 + t15354;
  t15507 = 0.768*t11126;
  t15511 = 0.2 + t15507;
  t15348 = 0.768*t11552;
  t15349 = 0.2 + t15348;
  p_output1[0]=t10734*t11199 + t11203*t11325 + t11431*t11555 + 0.768*t2582*t2597 + t11345*(3.2*Power(t10700,2) + 3.2*Power(t11191,2) + 6.8*Power(t11234,2) + 6.8*Power(t11274,2) + t11385 + t11391 + t11397 + t11411 + 3.2*Power(t2597,2) + 3.2*Power(t8670,2)) + t2604*t9526 + 0.768*t10700*t9654 - 1.*var4[0];
  p_output1[1]=t11325*t11345 + t11203*(6.8*Power(t11219,2) + 3.2*Power(t11238,2) + 3.2*Power(t11241,2) + 6.8*Power(t11245,2) + 3.2*Power(t11280,2) + 3.2*Power(t11323,2) + t11385 + t11391 + t11397 + t11411) + t10734*t11721 + t11431*t12852 + 0.768*t11238*t2582 + t11610*t2604 + 0.768*t11280*t9654 - 1.*var4[2];
  p_output1[2]=t11431*(3.3612 + 6.8*Power(t11438,2) + 3.2*Power(t11475,2) + 3.2*Power(t11482,2) + 6.8*Power(t11493,2) + 3.2*Power(t11536,2) + 3.2*Power(t11552,2)) + t11345*t11555 + t11203*t12852 + t13739 + t15290 + t10734*t15355 + t15312*t2582 + t15341*t2604 + t15349*t9654;
  p_output1[3]=t11203*t11610 + t13739 + t15290 + t11431*t15341 + t15444*t2582 + t2604*(1.58228 + 3.2*Power(t2627,2) + 3.2*Power(t3795,2)) + t11345*t9526;
  p_output1[4]=0.768*t11203*t11238 + t11431*t15312 + 1.2143199999999998*t2582 + 0.768*t11345*t2597 + t15444*t2604 - 1.*(0.4*t11234*t2588 + 0.8*(t13614 - 1.*t11234*t2588) - 0.4*t2584*t2607)*var4[0] - 1.*(-0.4*t11219*t2584 + 0.4*t2588*t2607 + 0.8*(t15125 - 1.*t2588*t2607))*var4[2];
  p_output1[5]=t10734*(1.58228 + 3.2*Power(t11126,2) + 3.2*Power(t11155,2)) + t11199*t11345 + t11203*t11721 + t11431*t15355 + t15511*t9654;
  p_output1[6]=0.768*t11203*t11280 + 0.768*t10700*t11345 + t11431*t15349 + t10734*t15511 + 1.2143199999999998*t9654;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2,*var3,*var4;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 4)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Four input(s) required (var1,var2,var3,var4).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }
  mrows = mxGetM(prhs[2]);
  ncols = mxGetN(prhs[2]);
  if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var3 is wrong.");
    }
  mrows = mxGetM(prhs[3]);
  ncols = mxGetN(prhs[3]);
  if( !mxIsDouble(prhs[3]) || mxIsComplex(prhs[3]) ||
    ( !(mrows == 3 && ncols == 1) && 
      !(mrows == 1 && ncols == 3))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var4 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
  var3 = mxGetPr(prhs[2]);
  var4 = mxGetPr(prhs[3]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2,var3,var4);


}

#else // MATLAB_MEX_FILE

#include "dxDiscreteMapRightImpact.hh"

namespace RightImpact
{

void dxDiscreteMapRightImpact_raw(double *p_output1, const double *var1,const double *var2,const double *var3,const double *var4)
{
  // Call Subroutines
  output1(p_output1, var1, var2, var3, var4);

}

}

#endif // MATLAB_MEX_FILE
