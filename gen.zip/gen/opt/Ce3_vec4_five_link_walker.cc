/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:57 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t569;
  double t628;
  double t430;
  double t525;
  double t295;
  double t517;
  double t607;
  double t616;
  double t617;
  double t626;
  double t627;
  double t664;
  double t665;
  double t680;
  double t703;
  double t705;
  double t711;
  double t712;
  double t713;
  double t720;
  double t730;
  double t629;
  double t637;
  double t643;
  double t656;
  double t661;
  double t662;
  double t733;
  double t739;
  double t740;
  double t752;
  double t753;
  double t732;
  double t735;
  double t754;
  double t449;
  double t526;
  double t543;
  double t564;
  double t685;
  double t778;
  double t779;
  double t780;
  double t863;
  double t864;
  double t867;
  double t832;
  double t833;
  double t836;
  double t844;
  double t845;
  double t851;
  double t932;
  double t938;
  double t939;
  double t941;
  double t942;
  double t943;
  double t663;
  double t701;
  double t777;
  double t781;
  double t783;
  double t784;
  double t789;
  double t790;
  double t791;
  double t792;
  double t793;
  double t806;
  double t862;
  double t869;
  double t1080;
  double t1081;
  double t913;
  double t3596;
  double t3659;
  double t916;
  t569 = Cos(var1[4]);
  t628 = Sin(var1[4]);
  t430 = Sin(var1[2]);
  t525 = Sin(var1[3]);
  t295 = Cos(var1[3]);
  t517 = Cos(var1[2]);
  t607 = -1.*t569;
  t616 = 1. + t607;
  t617 = 0.4*t616;
  t626 = 0.64*t569;
  t627 = t617 + t626;
  t664 = t295*t569;
  t665 = -1.*t525*t628;
  t680 = t664 + t665;
  t703 = t627*t569;
  t705 = Power(t628,2);
  t711 = 0.24*t705;
  t712 = t703 + t711;
  t713 = -1.*t569*t525;
  t720 = -1.*t295*t628;
  t730 = t713 + t720;
  t629 = t627*t628;
  t637 = -0.24*t569*t628;
  t643 = t629 + t637;
  t656 = t569*t525;
  t661 = t295*t628;
  t662 = t656 + t661;
  t733 = -1.*t430*t680;
  t739 = -1.*t517*t295;
  t740 = t430*t525;
  t752 = t739 + t740;
  t753 = -0.748*t752;
  t732 = t517*t730;
  t735 = t732 + t733;
  t754 = -1.*t430*t730;
  t449 = -1.*t295*t430;
  t526 = -1.*t517*t525;
  t543 = t449 + t526;
  t564 = -0.748*t543;
  t685 = t517*t680;
  t778 = -1.*t295*t569;
  t779 = t525*t628;
  t780 = t778 + t779;
  t863 = t295*t627;
  t864 = -0.24*t525*t628;
  t867 = t863 + t864;
  t832 = -1.*t627*t525;
  t833 = -0.24*t295*t628;
  t836 = t832 + t833;
  t844 = t627*t525;
  t845 = 0.24*t295*t628;
  t851 = t844 + t845;
  t932 = -1.*t627*t628;
  t938 = 0.24*t569*t628;
  t939 = t932 + t938;
  t941 = Power(t569,2);
  t942 = -0.24*t941;
  t943 = t703 + t942;
  t663 = -1.*t430*t662;
  t701 = t663 + t685;
  t777 = -3.2*t643*t735;
  t781 = t517*t780;
  t783 = t754 + t781;
  t784 = -3.2*t712*t783;
  t789 = t430*t730;
  t790 = t789 + t685;
  t791 = -3.2*t643*t790;
  t792 = t430*t780;
  t793 = t732 + t792;
  t806 = -3.2*t712*t793;
  t862 = t851*t680;
  t869 = t730*t867;
  t1080 = -0.24*t569*t525;
  t1081 = t1080 + t833;
  t913 = -1.*t730*t851;
  t3596 = 0.24*t295*t569;
  t3659 = t3596 + t864;
  t916 = -1.*t867*t780;
  p_output1[0]=0;
  p_output1[1]=0;
  p_output1[2]=(-0.5*(t564 - 3.2*t643*t701 - 3.2*t712*t735)*var2[0] - 0.5*(-3.2*t643*(-1.*t517*t662 + t733) + t753 - 3.2*t712*(-1.*t517*t680 + t754))*var2[1])*var2[3];
  p_output1[3]=(-0.5*(t564 + t791 + t806)*var2[0] - 0.5*(t753 + t777 + t784)*var2[1] - 0.5*(-3.2*t712*(t680*t836 + t862 + t662*t867 + t869) - 3.2*t643*(-1.*t730*t836 - 1.*t680*t867 + t913 + t916))*var2[2])*var2[3];
  p_output1[4]=var2[3]*(-0.5*(t791 + t806 - 3.2*t790*t939 - 3.2*(t517*t662 + t430*t680)*t943)*var2[0] - 0.5*(t777 + t784 - 3.2*t735*t939 - 3.2*t701*t943)*var2[1] - 0.5*(-3.2*t712*(t3659*t662 + t1081*t680 + t862 + t869) - 3.2*t643*(-1.*t3659*t680 - 1.*t1081*t730 + t913 + t916) - 3.2*(t662*t851 + t680*t867)*t939 - 3.2*(-1.*t680*t851 - 1.*t730*t867)*t943)*var2[2] - 0.5*(-6.4*t712*t939 - 6.4*t643*t943)*var2[3] + 0.384*t939*var2[4]);
  p_output1[5]=0;
  p_output1[6]=0;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce3_vec4_five_link_walker.hh"

namespace RightStance
{

void Ce3_vec4_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
