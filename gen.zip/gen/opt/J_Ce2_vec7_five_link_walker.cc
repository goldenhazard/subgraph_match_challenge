/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:32:02 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t9486;
  double t1145;
  double t3506;
  double t9527;
  double t264;
  double t9769;
  double t10655;
  double t10677;
  double t10839;
  double t11117;
  double t11118;
  double t3508;
  double t9635;
  double t9639;
  double t12112;
  double t12233;
  double t12344;
  double t12885;
  double t13069;
  double t13477;
  double t11154;
  double t9655;
  double t9771;
  double t10099;
  double t10116;
  double t10141;
  double t10321;
  double t11583;
  double t11618;
  double t11783;
  double t12060;
  double t12574;
  double t12630;
  double t15477;
  double t15486;
  double t15525;
  double t15526;
  double t15536;
  double t15538;
  double t15539;
  double t15603;
  double t15604;
  double t15621;
  double t15622;
  double t15623;
  double t15631;
  double t15632;
  double t15637;
  double t15654;
  double t15655;
  double t15656;
  double t15663;
  double t15671;
  double t11207;
  double t11211;
  double t11478;
  double t15403;
  double t15404;
  double t15405;
  double t15696;
  double t15697;
  double t12775;
  double t12822;
  double t12877;
  double t13616;
  double t13706;
  double t15361;
  double t15574;
  double t15678;
  double t15679;
  double t15680;
  double t15630;
  double t15644;
  double t15645;
  double t15661;
  double t15662;
  double t15660;
  double t15672;
  double t15673;
  double t15736;
  double t15737;
  double t15684;
  double t15686;
  double t15683;
  double t15685;
  double t15687;
  double t15746;
  double t15747;
  double t15748;
  double t15698;
  double t15700;
  double t15701;
  double t15710;
  double t15711;
  double t15712;
  double t15713;
  double t15714;
  double t15715;
  double t15716;
  double t15717;
  double t15718;
  double t15719;
  double t15720;
  double t15724;
  double t15725;
  double t15729;
  double t15730;
  double t15731;
  double t15732;
  double t15733;
  double t15735;
  double t15743;
  double t15744;
  double t15749;
  double t15752;
  double t15764;
  double t15765;
  double t15767;
  double t15768;
  double t15814;
  double t15815;
  double t15816;
  double t15817;
  double t15818;
  double t15798;
  double t15799;
  double t15800;
  double t15802;
  double t15803;
  double t15804;
  double t15805;
  double t15806;
  double t15808;
  double t15809;
  double t15810;
  double t15811;
  double t15812;
  double t15573;
  double t15580;
  double t15493;
  double t15494;
  double t15470;
  double t15524;
  double t15540;
  double t15572;
  double t15598;
  double t15605;
  double t15606;
  double t15738;
  double t15739;
  double t15740;
  double t15745;
  double t15750;
  double t15751;
  double t15753;
  double t15755;
  double t15756;
  double t15757;
  double t15762;
  double t15763;
  double t15766;
  double t15769;
  double t15848;
  double t15776;
  double t15777;
  double t15778;
  double t15850;
  double t15852;
  double t15855;
  double t15856;
  double t15857;
  double t15858;
  double t15859;
  double t15860;
  double t15861;
  double t15862;
  double t15863;
  double t15864;
  double t15867;
  double t15785;
  double t15786;
  double t15787;
  double t15790;
  double t15791;
  double t15792;
  double t15807;
  double t15646;
  double t15676;
  double t15681;
  double t15691;
  double t15692;
  double t12671;
  double t13615;
  double t15397;
  double t15407;
  double t15410;
  double t15469;
  double t15890;
  double t15693;
  double t15840;
  double t15841;
  double t15842;
  double t15843;
  double t15844;
  double t15741;
  double t15742;
  double t15754;
  double t15758;
  double t15761;
  double t15770;
  double t15771;
  double t15865;
  double t15866;
  double t15868;
  double t15869;
  double t15870;
  double t15871;
  double t15872;
  double t15784;
  double t15788;
  double t15789;
  double t15793;
  double t15794;
  double t15882;
  double t15883;
  double t15884;
  double t15885;
  double t15886;
  double t15813;
  double t15892;
  double t15944;
  double t15945;
  double t15946;
  double t15947;
  double t15948;
  double t15940;
  double t15941;
  double t15942;
  double t15827;
  double t15828;
  double t15829;
  double t15830;
  double t15831;
  double t15849;
  double t15851;
  double t15853;
  double t15699;
  double t15702;
  double t15703;
  double t15903;
  double t15904;
  double t15905;
  double t15906;
  double t15907;
  double t15876;
  double t15877;
  double t15878;
  double t15879;
  double t15880;
  double t15775;
  double t15779;
  double t15780;
  double t15781;
  double t15782;
  double t15920;
  double t15921;
  double t15922;
  double t15923;
  double t15924;
  double t15925;
  double t15926;
  double t15819;
  double t15893;
  double t15949;
  double t15979;
  double t15980;
  double t15981;
  double t15993;
  double t15994;
  double t10523;
  t9486 = Cos(var1[5]);
  t1145 = Cos(var1[6]);
  t3506 = Sin(var1[5]);
  t9527 = Sin(var1[6]);
  t264 = Sin(var1[2]);
  t9769 = Cos(var1[2]);
  t10655 = -1.*t1145;
  t10677 = 1. + t10655;
  t10839 = 0.4*t10677;
  t11117 = 0.64*t1145;
  t11118 = t10839 + t11117;
  t3508 = -1.*t1145*t3506;
  t9635 = -1.*t9486*t9527;
  t9639 = t3508 + t9635;
  t12112 = t9486*t1145;
  t12233 = -1.*t3506*t9527;
  t12344 = t12112 + t12233;
  t12885 = t9769*t9639;
  t13069 = -1.*t264*t12344;
  t13477 = t12885 + t13069;
  t11154 = t11118*t1145;
  t9655 = -1.*t264*t9639;
  t9771 = -1.*t9486*t1145;
  t10099 = t3506*t9527;
  t10116 = t9771 + t10099;
  t10141 = t9769*t10116;
  t10321 = t9655 + t10141;
  t11583 = t1145*t3506;
  t11618 = t9486*t9527;
  t11783 = t11583 + t11618;
  t12060 = -1.*t264*t11783;
  t12574 = t9769*t12344;
  t12630 = t12060 + t12574;
  t15477 = t264*t9639;
  t15486 = t15477 + t12574;
  t15525 = -1.*t9769*t12344;
  t15526 = t9655 + t15525;
  t15536 = t9769*t11783;
  t15538 = t264*t12344;
  t15539 = t15536 + t15538;
  t15603 = t264*t10116;
  t15604 = t12885 + t15603;
  t15621 = t11118*t3506;
  t15622 = 0.24*t9486*t9527;
  t15623 = t15621 + t15622;
  t15631 = t9486*t11118;
  t15632 = -0.24*t3506*t9527;
  t15637 = t15631 + t15632;
  t15654 = -0.24*t1145*t3506;
  t15655 = -0.24*t9486*t9527;
  t15656 = t15654 + t15655;
  t15663 = 0.24*t9486*t1145;
  t15671 = t15663 + t15632;
  t11207 = Power(t1145,2);
  t11211 = -0.24*t11207;
  t11478 = t11154 + t11211;
  t15403 = Power(t9527,2);
  t15404 = 0.24*t15403;
  t15405 = t11154 + t15404;
  t15696 = t264*t11783;
  t15697 = t15696 + t10141;
  t12775 = t11118*t9527;
  t12822 = -0.24*t1145*t9527;
  t12877 = t12775 + t12822;
  t13616 = -1.*t11118*t9527;
  t13706 = 0.24*t1145*t9527;
  t15361 = t13616 + t13706;
  t15574 = -1.*t264*t10116;
  t15678 = t15623*t11783;
  t15679 = t12344*t15637;
  t15680 = t15678 + t15679;
  t15630 = -1.*t15623*t12344;
  t15644 = -1.*t9639*t15637;
  t15645 = t15630 + t15644;
  t15661 = t15623*t12344;
  t15662 = t9639*t15637;
  t15660 = t15656*t12344;
  t15672 = t11783*t15671;
  t15673 = t15660 + t15661 + t15662 + t15672;
  t15736 = -1.*t11118*t3506;
  t15737 = t15736 + t15655;
  t15684 = -1.*t9639*t15623;
  t15686 = -1.*t15637*t10116;
  t15683 = -1.*t9639*t15656;
  t15685 = -1.*t12344*t15671;
  t15687 = t15683 + t15684 + t15685 + t15686;
  t15746 = -0.24*t9486*t1145;
  t15747 = 0.24*t3506*t9527;
  t15748 = t15746 + t15747;
  t15698 = -0.384*var2[6]*t15697;
  t15700 = 3.2*t15405*t15697;
  t15701 = 3.2*t12877*t15604;
  t15710 = 6.4*t15486*t13477;
  t15711 = 3.2*t15539*t10321;
  t15712 = 3.2*t13477*t15697;
  t15713 = t15536 + t15574;
  t15714 = 3.2*t15486*t15713;
  t15715 = 3.2*t12630*t15604;
  t15716 = 6.4*t10321*t15604;
  t15717 = t15710 + t15711 + t15712 + t15714 + t15715 + t15716;
  t15718 = -0.5*var2[1]*t15717;
  t15719 = Power(t15486,2);
  t15720 = 6.4*t15719;
  t15724 = 6.4*t15486*t15697;
  t15725 = 6.4*t15539*t15604;
  t15729 = Power(t15604,2);
  t15730 = 6.4*t15729;
  t15731 = t15720 + t15724 + t15725 + t15730;
  t15732 = -0.5*var2[0]*t15731;
  t15733 = 3.2*t15680*t15697;
  t15735 = 3.2*t15645*t15604;
  t15743 = -1.*t15656*t12344;
  t15744 = -1.*t11783*t15637;
  t15749 = -1.*t9639*t15748;
  t15752 = -1.*t15623*t10116;
  t15764 = t9639*t15623;
  t15765 = t15656*t11783;
  t15767 = t12344*t15748;
  t15768 = t15637*t10116;
  t15814 = 3.2*t12877*t15486;
  t15815 = 3.2*t15361*t15486;
  t15816 = 3.2*t11478*t15539;
  t15817 = 3.2*t15405*t15604;
  t15818 = t15814 + t15815 + t15816 + t15817;
  t15798 = 6.4*t15486*t15539;
  t15799 = 6.4*t15486*t15604;
  t15800 = t15798 + t15799;
  t15802 = 3.2*t15486*t12630;
  t15803 = 3.2*t13477*t15539;
  t15804 = 3.2*t15486*t10321;
  t15805 = 3.2*t13477*t15604;
  t15806 = t15802 + t15803 + t15804 + t15805;
  t15808 = 3.2*t15486*t15645;
  t15809 = 3.2*t15486*t15673;
  t15810 = 3.2*t15680*t15604;
  t15811 = 3.2*t15539*t15687;
  t15812 = t15808 + t15809 + t15810 + t15811;
  t15573 = -1.*t9769*t9639;
  t15580 = t15573 + t15574;
  t15493 = -1.*t9769*t11783;
  t15494 = t15493 + t13069;
  t15470 = 6.4*t12630*t13477;
  t15524 = 3.2*t15486*t15494;
  t15540 = 3.2*t15526*t15539;
  t15572 = 6.4*t13477*t10321;
  t15598 = 3.2*t15486*t15580;
  t15605 = 3.2*t15526*t15604;
  t15606 = t15470 + t15524 + t15540 + t15572 + t15598 + t15605;
  t15738 = t15737*t12344;
  t15739 = t11783*t15637;
  t15740 = t15738 + t15661 + t15662 + t15739;
  t15745 = -1.*t9639*t15671;
  t15750 = -1.*t15737*t10116;
  t15751 = -1.*t15656*t10116;
  t15753 = t15743 + t15644 + t15744 + t15745 + t15749 + t15750 + t15751 + t15752;
  t15755 = -1.*t9639*t15737;
  t15756 = -1.*t12344*t15637;
  t15757 = t15755 + t15684 + t15756 + t15686;
  t15762 = t9639*t15737;
  t15763 = t9639*t15656;
  t15766 = t12344*t15671;
  t15769 = t15762 + t15763 + t15764 + t15765 + t15679 + t15766 + t15767 + t15768;
  t15848 = -0.384*var2[6]*t15713;
  t15776 = -1.*t11118*t1145;
  t15777 = 0.24*t11207;
  t15778 = t15776 + t15777;
  t15850 = 3.2*t12877*t10321;
  t15852 = 3.2*t15405*t15713;
  t15855 = Power(t13477,2);
  t15856 = 6.4*t15855;
  t15857 = 6.4*t12630*t10321;
  t15858 = Power(t10321,2);
  t15859 = 6.4*t15858;
  t15860 = 6.4*t13477*t15713;
  t15861 = t15856 + t15857 + t15859 + t15860;
  t15862 = -0.5*var2[1]*t15861;
  t15863 = -0.5*var2[0]*t15717;
  t15864 = 3.2*t15645*t10321;
  t15867 = 3.2*t15680*t15713;
  t15785 = -2.*t9639*t15671;
  t15786 = -2.*t15656*t10116;
  t15787 = t15743 + t15744 + t15785 + t15749 + t15786 + t15752;
  t15790 = 2.*t9639*t15656;
  t15791 = 2.*t12344*t15671;
  t15792 = t15790 + t15764 + t15765 + t15791 + t15767 + t15768;
  t15807 = -0.5*var2[6]*t15806;
  t15646 = 3.2*t13477*t15645;
  t15676 = 3.2*t13477*t15673;
  t15681 = 3.2*t15680*t10321;
  t15691 = 3.2*t12630*t15687;
  t15692 = t15646 + t15676 + t15681 + t15691;
  t12671 = 3.2*t11478*t12630;
  t13615 = 3.2*t12877*t13477;
  t15397 = 3.2*t15361*t13477;
  t15407 = 3.2*t15405*t10321;
  t15410 = t12671 + t13615 + t15397 + t15407;
  t15469 = -0.5*var2[5]*t15410;
  t15890 = t15470 + t15572;
  t15693 = -0.5*var2[2]*t15692;
  t15840 = 3.2*t15526*t15645;
  t15841 = 3.2*t15526*t15673;
  t15842 = 3.2*t15680*t15580;
  t15843 = 3.2*t15494*t15687;
  t15844 = t15840 + t15841 + t15842 + t15843;
  t15741 = 3.2*t15740*t15604;
  t15742 = 3.2*t15673*t15604;
  t15754 = 3.2*t15539*t15753;
  t15758 = 3.2*t15486*t15757;
  t15761 = 3.2*t15486*t15687;
  t15770 = 3.2*t15486*t15769;
  t15771 = t15733 + t15735 + t15741 + t15742 + t15754 + t15758 + t15761 + t15770;
  t15865 = 3.2*t15740*t10321;
  t15866 = 3.2*t15673*t10321;
  t15868 = 3.2*t12630*t15753;
  t15869 = 3.2*t13477*t15757;
  t15870 = 3.2*t13477*t15687;
  t15871 = 3.2*t13477*t15769;
  t15872 = t15864 + t15865 + t15866 + t15867 + t15868 + t15869 + t15870 + t15871;
  t15784 = 6.4*t15673*t15604;
  t15788 = 3.2*t15539*t15787;
  t15789 = 6.4*t15486*t15687;
  t15793 = 3.2*t15486*t15792;
  t15794 = t15733 + t15735 + t15784 + t15788 + t15789 + t15793;
  t15882 = 6.4*t15673*t10321;
  t15883 = 3.2*t12630*t15787;
  t15884 = 6.4*t13477*t15687;
  t15885 = 3.2*t13477*t15792;
  t15886 = t15864 + t15882 + t15867 + t15883 + t15884 + t15885;
  t15813 = -0.5*var2[6]*t15812;
  t15892 = -0.5*var2[6]*t15692;
  t15944 = 3.2*t11478*t15645;
  t15945 = 3.2*t15361*t15680;
  t15946 = 3.2*t15405*t15673;
  t15947 = 3.2*t12877*t15687;
  t15948 = t15944 + t15945 + t15946 + t15947;
  t15940 = 6.4*t15680*t15673;
  t15941 = 6.4*t15645*t15687;
  t15942 = t15940 + t15941;
  t15827 = 3.2*t12877*t15526;
  t15828 = 3.2*t15361*t15526;
  t15829 = 3.2*t11478*t15494;
  t15830 = 3.2*t15405*t15580;
  t15831 = t15827 + t15828 + t15829 + t15830;
  t15849 = 3.2*t11478*t13477;
  t15851 = 3.2*t15361*t10321;
  t15853 = t15849 + t15850 + t15851 + t15852;
  t15699 = 3.2*t11478*t15486;
  t15702 = 3.2*t15361*t15604;
  t15703 = t15699 + t15700 + t15701 + t15702;
  t15903 = 3.2*t15361*t15740;
  t15904 = 3.2*t12877*t15753;
  t15905 = 3.2*t11478*t15757;
  t15906 = 3.2*t15405*t15769;
  t15907 = t15903 + t15904 + t15905 + t15906;
  t15876 = 3.2*t15361*t12630;
  t15877 = 6.4*t11478*t13477;
  t15878 = 3.2*t15778*t13477;
  t15879 = 6.4*t15361*t10321;
  t15880 = t15876 + t15877 + t15878 + t15850 + t15879 + t15852;
  t15775 = 6.4*t11478*t15486;
  t15779 = 3.2*t15778*t15486;
  t15780 = 3.2*t15361*t15539;
  t15781 = 6.4*t15361*t15604;
  t15782 = t15775 + t15779 + t15780 + t15700 + t15701 + t15781;
  t15920 = 3.2*t15361*t15645;
  t15921 = 3.2*t15778*t15680;
  t15922 = 6.4*t15361*t15673;
  t15923 = 3.2*t12877*t15787;
  t15924 = 6.4*t11478*t15687;
  t15925 = 3.2*t15405*t15792;
  t15926 = t15920 + t15921 + t15922 + t15923 + t15924 + t15925;
  t15819 = -0.5*var2[6]*t15818;
  t15893 = -0.5*var2[6]*t15410;
  t15949 = -0.5*var2[6]*t15948;
  t15979 = 6.4*t11478*t12877;
  t15980 = 6.4*t15361*t15405;
  t15981 = t15979 + t15980;
  t15993 = -0.384*var2[0]*t15697;
  t15994 = -0.384*var2[1]*t15713;
  t10523 = -0.384*var2[6]*t10321;
  p_output1[0]=(t10523 + t15469 + t15693 - 0.5*(6.4*t10321*t15486 + 6.4*t12630*t15486 + 6.4*t13477*t15539 + 6.4*t13477*t15604)*var2[0] - 0.5*t15606*var2[1])*var2[6];
  p_output1[1]=(t15698 + t15718 + t15732 - 0.5*t15771*var2[2] - 0.5*t15703*var2[5])*var2[6];
  p_output1[2]=(t15698 + t15718 + t15732 - 0.5*t15794*var2[2] - 0.5*t15782*var2[5])*var2[6];
  p_output1[3]=-0.5*t15800*var2[6];
  p_output1[4]=t15807;
  p_output1[5]=t15813;
  p_output1[6]=t15819;
  p_output1[7]=-0.5*t15800*var2[0] - 0.5*t15806*var2[1] - 0.5*t15812*var2[2] - 0.5*t15818*var2[5] - 0.768*t15604*var2[6];
  p_output1[8]=var2[6]*(-0.5*t15606*var2[0] - 0.5*(6.4*t13477*t15494 + 6.4*t10321*t15526 + 6.4*t12630*t15526 + 6.4*t13477*t15580)*var2[1] - 0.5*t15844*var2[2] - 0.5*t15831*var2[5] - 0.384*t15580*var2[6]);
  p_output1[9]=(t15848 + t15862 + t15863 - 0.5*t15872*var2[2] - 0.5*t15853*var2[5])*var2[6];
  p_output1[10]=(t15848 + t15862 + t15863 - 0.5*t15886*var2[2] - 0.5*t15880*var2[5])*var2[6];
  p_output1[11]=t15807;
  p_output1[12]=-0.5*t15890*var2[6];
  p_output1[13]=t15892;
  p_output1[14]=t15893;
  p_output1[15]=t15469 + t15693 - 0.5*t15806*var2[0] - 0.5*t15890*var2[1] - 0.768*t10321*var2[6];
  p_output1[16]=(-0.5*t15692*var2[0] - 0.5*t15844*var2[1])*var2[6];
  p_output1[17]=var2[6]*(-0.5*t15771*var2[0] - 0.5*t15872*var2[1] - 0.5*(6.4*t15673*t15740 + 6.4*t15645*t15753 + 6.4*t15687*t15757 + 6.4*t15680*t15769)*var2[2] - 0.5*t15907*var2[5] - 0.384*t15769*var2[6]);
  p_output1[18]=var2[6]*(-0.5*t15794*var2[0] - 0.5*t15886*var2[1] - 0.5*(6.4*Power(t15673,2) + 6.4*Power(t15687,2) + 6.4*t15645*t15787 + 6.4*t15680*t15792)*var2[2] - 0.5*t15926*var2[5] - 0.384*t15792*var2[6]);
  p_output1[19]=t15813;
  p_output1[20]=t15892;
  p_output1[21]=-0.5*t15942*var2[6];
  p_output1[22]=t15949;
  p_output1[23]=-0.5*t15812*var2[0] - 0.5*t15692*var2[1] - 0.5*t15942*var2[2] - 0.5*t15948*var2[5] - 0.768*t15673*var2[6];
  p_output1[24]=(-0.5*t15410*var2[0] - 0.5*t15831*var2[1])*var2[6];
  p_output1[25]=(-0.5*t15703*var2[0] - 0.5*t15853*var2[1] - 0.5*t15907*var2[2])*var2[6];
  p_output1[26]=var2[6]*(-0.5*t15782*var2[0] - 0.5*t15880*var2[1] - 0.5*t15926*var2[2] - 0.5*(6.4*Power(t11478,2) + 6.4*t12877*t15361 + 6.4*Power(t15361,2) + 6.4*t15405*t15778)*var2[5] - 0.384*t15778*var2[6]);
  p_output1[27]=t15819;
  p_output1[28]=t15893;
  p_output1[29]=t15949;
  p_output1[30]=-0.5*t15981*var2[6];
  p_output1[31]=-0.5*t15818*var2[0] - 0.5*t15410*var2[1] - 0.5*t15948*var2[2] - 0.5*t15981*var2[5] - 0.768*t15361*var2[6];
  p_output1[32]=(-0.384*t10321*var2[0] - 0.384*t15580*var2[1])*var2[6];
  p_output1[33]=(t15993 + t15994 - 0.384*t15769*var2[2])*var2[6];
  p_output1[34]=(t15993 + t15994 - 0.384*t15792*var2[2] - 0.384*t15778*var2[5])*var2[6];
  p_output1[35]=-0.384*t15604*var2[6];
  p_output1[36]=t10523;
  p_output1[37]=-0.384*t15673*var2[6];
  p_output1[38]=-0.384*t15361*var2[6];
  p_output1[39]=-0.384*t15604*var2[0] - 0.384*t10321*var2[1] - 0.384*t15673*var2[2] - 0.384*t15361*var2[5];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 40, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce2_vec7_five_link_walker.hh"

namespace RightStance
{

void J_Ce2_vec7_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
