/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:29 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t3863;
  double t3694;
  double t3755;
  double t6251;
  double t45;
  double t3862;
  double t6292;
  double t6293;
  double t6299;
  double t6329;
  double t6368;
  double t6392;
  double t6406;
  double t6407;
  double t6408;
  double t6444;
  double t6451;
  double t6500;
  double t6523;
  double t7597;
  double t6441;
  double t8117;
  double t8121;
  double t8207;
  double t8262;
  double t6334;
  double t6362;
  double t6363;
  double t8306;
  double t8473;
  double t9482;
  double t9606;
  double t9615;
  double t9823;
  double t9827;
  double t9838;
  double t9857;
  double t9858;
  double t9849;
  double t9859;
  double t9860;
  double t9861;
  double t9862;
  double t6365;
  double t6366;
  double t6421;
  double t6367;
  double t6410;
  double t9890;
  double t9901;
  double t9902;
  double t9903;
  double t9915;
  double t9916;
  double t9917;
  double t9919;
  double t9978;
  double t9986;
  double t9989;
  double t9921;
  double t9922;
  double t9962;
  double t9976;
  double t10005;
  double t10006;
  double t9995;
  double t10001;
  double t10004;
  double t10007;
  double t10008;
  double t10009;
  double t10010;
  double t10011;
  double t10012;
  double t10013;
  double t10033;
  double t10034;
  double t10035;
  double t10544;
  double t10669;
  double t10690;
  double t10691;
  double t10712;
  t3863 = Cos(var1[3]);
  t3694 = Cos(var1[4]);
  t3755 = Sin(var1[3]);
  t6251 = Sin(var1[4]);
  t45 = Sin(var1[2]);
  t3862 = -1.*t3694*t3755;
  t6292 = -1.*t3863*t6251;
  t6293 = t3862 + t6292;
  t6299 = -1.*t45*t6293;
  t6329 = Cos(var1[2]);
  t6368 = -1.*t3863*t3694;
  t6392 = t3755*t6251;
  t6406 = t6368 + t6392;
  t6407 = t6329*t6406;
  t6408 = t6299 + t6407;
  t6444 = t3694*t3755;
  t6451 = t3863*t6251;
  t6500 = t6444 + t6451;
  t6523 = t45*t6500;
  t7597 = t6523 + t6407;
  t6441 = -0.384*var2[2]*t6408;
  t8117 = -0.384*var2[3]*t7597;
  t8121 = -0.384*var2[4]*t7597;
  t8207 = t6441 + t8117 + t8121;
  t8262 = var2[4]*t8207;
  t6334 = t3863*t3694;
  t6362 = -1.*t3755*t6251;
  t6363 = t6334 + t6362;
  t8306 = t6329*t6293;
  t8473 = -1.*t45*t6363;
  t9482 = t8306 + t8473;
  t9606 = t45*t6406;
  t9615 = t8306 + t9606;
  t9823 = -1.*t6329*t6293;
  t9827 = -1.*t45*t6406;
  t9838 = t9823 + t9827;
  t9857 = t6329*t6500;
  t9858 = t9857 + t9827;
  t9849 = -0.384*var2[2]*t9838;
  t9859 = -0.384*var2[3]*t9858;
  t9860 = -0.384*var2[4]*t9858;
  t9861 = t9849 + t9859 + t9860;
  t9862 = var2[4]*t9861;
  t6365 = -1.*t6329*t6363;
  t6366 = t6299 + t6365;
  t6421 = -0.384*var2[4]*t6408;
  t6367 = -0.384*var2[2]*t6366;
  t6410 = -0.384*var2[3]*t6408;
  t9890 = -1.*t3694;
  t9901 = 1. + t9890;
  t9902 = 0.4*t9901;
  t9903 = 0.64*t3694;
  t9915 = t9902 + t9903;
  t9916 = -1.*t9915*t3755;
  t9917 = -0.24*t3863*t6251;
  t9919 = t9916 + t9917;
  t9978 = t3863*t9915;
  t9986 = -0.24*t3755*t6251;
  t9989 = t9978 + t9986;
  t9921 = t9915*t3755;
  t9922 = 0.24*t3863*t6251;
  t9962 = t9921 + t9922;
  t9976 = t6293*t9962;
  t10005 = -0.24*t3694*t3755;
  t10006 = t10005 + t9917;
  t9995 = 0.24*t3755*t6251;
  t10001 = t9989*t6406;
  t10004 = t6293*t9919;
  t10007 = t6293*t10006;
  t10008 = t10006*t6500;
  t10009 = t6363*t9989;
  t10010 = 0.24*t3863*t3694;
  t10011 = t10010 + t9986;
  t10012 = t6363*t10011;
  t10013 = -0.24*t3863*t3694;
  t10033 = t10013 + t9995;
  t10034 = t6363*t10033;
  t10035 = t10004 + t10007 + t9976 + t10008 + t10009 + t10012 + t10034 + t10001;
  t10544 = t9919*t6363;
  t10669 = t9962*t6363;
  t10690 = t6293*t9989;
  t10691 = t6500*t9989;
  t10712 = t10544 + t10669 + t10690 + t10691;
  p_output1[0]=(t6367 + t6410 + t6421)*var2[4];
  p_output1[1]=t8262;
  p_output1[2]=t8262;
  p_output1[3]=-0.384*t9482*var2[4];
  p_output1[4]=-0.384*t9615*var2[4];
  p_output1[5]=-0.384*t9482*var2[2] - 0.384*t9615*var2[3] - 0.768*t9615*var2[4];
  p_output1[6]=var2[4]*(-0.384*(t45*t6363 + t9823)*var2[2] - 0.384*t9838*var2[3] - 0.384*t9838*var2[4]);
  p_output1[7]=t9862;
  p_output1[8]=t9862;
  p_output1[9]=-0.384*t6366*var2[4];
  p_output1[10]=t6421;
  p_output1[11]=t6367 + t6410 - 0.768*t6408*var2[4];
  p_output1[12]=var2[4]*(-0.384*(t10001 + 2.*t6293*t9919 + t6500*t9919 + t9976 + 2.*t6363*t9989 + t6363*(-1.*t3863*t9915 + t9995))*var2[3] - 0.384*t10035*var2[4]);
  p_output1[13]=var2[4]*(-0.384*t10035*var2[3] - 0.384*(t10001 + t10008 + t10034 + 2.*t10006*t6293 + 2.*t10011*t6363 + t9976)*var2[4]);
  p_output1[14]=-0.384*t10712*var2[4];
  p_output1[15]=-0.384*t10712*var2[3] - 0.768*(t10669 + t10690 + t10006*t6363 + t10011*t6500)*var2[4];
  p_output1[16]=-0.384*(0.24*Power(t3694,2) - 1.*t3694*t9915)*Power(var2[4],2);
  p_output1[17]=-0.768*(0.24*t3694*t6251 - 1.*t6251*t9915)*var2[4];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 18, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce1_vec5_five_link_walker.hh"

namespace RightStance
{

void J_Ce1_vec5_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
