/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:24 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t1549;
  double t1459;
  double t1517;
  double t1563;
  double t1583;
  double t1458;
  double t1518;
  double t1568;
  double t1571;
  double t1578;
  double t1595;
  double t1599;
  double t1602;
  double t1603;
  double t1606;
  double t1628;
  double t1629;
  double t1634;
  double t1635;
  double t1638;
  double t1665;
  double t1662;
  double t1663;
  double t1666;
  double t1664;
  double t1667;
  double t1668;
  double t1670;
  double t1671;
  double t1672;
  double t1673;
  double t1674;
  double t1675;
  double t1681;
  double t1682;
  double t1683;
  double t1687;
  double t1688;
  double t1612;
  double t1613;
  double t1616;
  double t1650;
  double t1651;
  double t1652;
  double t1653;
  double t1654;
  double t1658;
  double t1677;
  double t1678;
  double t1679;
  double t1703;
  double t1704;
  double t1705;
  double t1706;
  double t1707;
  double t1709;
  double t1734;
  double t1740;
  double t1742;
  double t1804;
  double t1806;
  double t1807;
  double t8183;
  double t8194;
  double t8195;
  double t8207;
  double t8216;
  double t8218;
  double t8306;
  double t8307;
  double t8308;
  double t8317;
  double t8331;
  double t8334;
  double t1744;
  double t1772;
  double t1773;
  double t1727;
  double t1728;
  double t1729;
  double t1646;
  double t1647;
  double t1649;
  double t1775;
  double t1777;
  double t1639;
  double t1642;
  double t1643;
  double t1644;
  double t3694;
  double t3973;
  double t4028;
  double t1779;
  double t1801;
  double t1802;
  double t1695;
  double t1696;
  double t1697;
  double t7597;
  double t7652;
  double t1689;
  double t1690;
  double t1691;
  double t1692;
  double t7891;
  double t7892;
  double t7922;
  double t7925;
  double t7962;
  double t7963;
  double t8046;
  double t8047;
  double t1730;
  double t1743;
  double t1774;
  double t1778;
  double t1803;
  double t1808;
  double t7561;
  double t7665;
  double t7666;
  double t8107;
  double t8108;
  double t8120;
  double t8121;
  double t8158;
  double t8206;
  double t8252;
  double t8253;
  double t8256;
  double t8258;
  double t8270;
  double t8285;
  double t8287;
  double t8291;
  double t8302;
  double t8303;
  double t8312;
  double t8349;
  double t8353;
  double t8368;
  double t8377;
  double t8380;
  double t8105;
  double t8177;
  double t8255;
  double t8282;
  double t8305;
  double t8361;
  double t8382;
  double t8386;
  double t8537;
  double t8541;
  double t8549;
  double t8553;
  double t8558;
  double t8582;
  double t8586;
  double t8593;
  double t8423;
  double t8455;
  double t8456;
  double t8457;
  double t1617;
  double t1645;
  double t1659;
  double t1660;
  double t8605;
  double t8607;
  double t8608;
  double t8612;
  double t8702;
  double t8726;
  double t8600;
  double t8601;
  double t8464;
  double t8467;
  double t8468;
  double t8470;
  double t1680;
  double t1693;
  double t1710;
  double t1711;
  double t8620;
  double t8622;
  double t8636;
  double t8640;
  double t13315;
  double t13316;
  double t8615;
  double t8616;
  t1549 = Cos(var1[3]);
  t1459 = Cos(var1[4]);
  t1517 = Sin(var1[3]);
  t1563 = Sin(var1[4]);
  t1583 = Cos(var1[2]);
  t1458 = Sin(var1[2]);
  t1518 = -1.*t1459*t1517;
  t1568 = -1.*t1549*t1563;
  t1571 = t1518 + t1568;
  t1578 = t1458*t1571;
  t1595 = t1549*t1459;
  t1599 = -1.*t1517*t1563;
  t1602 = t1595 + t1599;
  t1603 = t1583*t1602;
  t1606 = t1578 + t1603;
  t1628 = -1.*t1459;
  t1629 = 1. + t1628;
  t1634 = 0.4*t1629;
  t1635 = 0.64*t1459;
  t1638 = t1634 + t1635;
  t1665 = Cos(var1[5]);
  t1662 = Cos(var1[6]);
  t1663 = Sin(var1[5]);
  t1666 = Sin(var1[6]);
  t1664 = -1.*t1662*t1663;
  t1667 = -1.*t1665*t1666;
  t1668 = t1664 + t1667;
  t1670 = t1458*t1668;
  t1671 = t1665*t1662;
  t1672 = -1.*t1663*t1666;
  t1673 = t1671 + t1672;
  t1674 = t1583*t1673;
  t1675 = t1670 + t1674;
  t1681 = -1.*t1662;
  t1682 = 1. + t1681;
  t1683 = 0.4*t1682;
  t1687 = 0.64*t1662;
  t1688 = t1683 + t1687;
  t1612 = t1583*t1549;
  t1613 = -1.*t1458*t1517;
  t1616 = t1612 + t1613;
  t1650 = t1459*t1517;
  t1651 = t1549*t1563;
  t1652 = t1650 + t1651;
  t1653 = t1583*t1652;
  t1654 = t1458*t1602;
  t1658 = t1653 + t1654;
  t1677 = t1583*t1665;
  t1678 = -1.*t1458*t1663;
  t1679 = t1677 + t1678;
  t1703 = t1662*t1663;
  t1704 = t1665*t1666;
  t1705 = t1703 + t1704;
  t1706 = t1583*t1705;
  t1707 = t1458*t1673;
  t1709 = t1706 + t1707;
  t1734 = t1549*t1458;
  t1740 = t1583*t1517;
  t1742 = t1734 + t1740;
  t1804 = t1665*t1458;
  t1806 = t1583*t1663;
  t1807 = t1804 + t1806;
  t8183 = t1638*t1517;
  t8194 = 0.24*t1549*t1563;
  t8195 = t8183 + t8194;
  t8207 = t1549*t1638;
  t8216 = -0.24*t1517*t1563;
  t8218 = t8207 + t8216;
  t8306 = t1688*t1663;
  t8307 = 0.24*t1665*t1666;
  t8308 = t8306 + t8307;
  t8317 = t1665*t1688;
  t8331 = -0.24*t1663*t1666;
  t8334 = t8317 + t8331;
  t1744 = t1583*t1571;
  t1772 = -1.*t1458*t1602;
  t1773 = t1744 + t1772;
  t1727 = -1.*t1549*t1458;
  t1728 = -1.*t1583*t1517;
  t1729 = t1727 + t1728;
  t1646 = t1638*t1563;
  t1647 = -0.24*t1459*t1563;
  t1649 = t1646 + t1647;
  t1775 = -1.*t1458*t1652;
  t1777 = t1775 + t1603;
  t1639 = t1638*t1459;
  t1642 = Power(t1563,2);
  t1643 = 0.24*t1642;
  t1644 = t1639 + t1643;
  t3694 = t1583*t1668;
  t3973 = -1.*t1458*t1673;
  t4028 = t3694 + t3973;
  t1779 = -1.*t1665*t1458;
  t1801 = -1.*t1583*t1663;
  t1802 = t1779 + t1801;
  t1695 = t1688*t1666;
  t1696 = -0.24*t1662*t1666;
  t1697 = t1695 + t1696;
  t7597 = -1.*t1458*t1705;
  t7652 = t7597 + t1674;
  t1689 = t1688*t1662;
  t1690 = Power(t1666,2);
  t1691 = 0.24*t1690;
  t1692 = t1689 + t1691;
  t7891 = Power(t1583,2);
  t7892 = -12.*t7891;
  t7922 = Power(t1458,2);
  t7925 = -12.*t7922;
  t7962 = Power(t1616,2);
  t7963 = -6.8*t7962;
  t8046 = Power(t1679,2);
  t8047 = -6.8*t8046;
  t1730 = -6.8*t1729*t1616;
  t1743 = -6.8*t1742*t1616;
  t1774 = -3.2*t1606*t1773;
  t1778 = -3.2*t1777*t1658;
  t1803 = -6.8*t1802*t1679;
  t1808 = -6.8*t1807*t1679;
  t7561 = -3.2*t1675*t4028;
  t7665 = -3.2*t7652*t1709;
  t7666 = t1730 + t1743 + t1774 + t1778 + t1803 + t1808 + t7561 + t7665;
  t8107 = Power(t1549,2);
  t8108 = 0.11*t8107;
  t8120 = Power(t1517,2);
  t8121 = 0.11*t8120;
  t8158 = t8108 + t8121;
  t8206 = -1.*t8195*t1602;
  t8252 = -1.*t1571*t8218;
  t8253 = t8206 + t8252;
  t8256 = t8195*t1652;
  t8258 = t1602*t8218;
  t8270 = t8256 + t8258;
  t8285 = Power(t1665,2);
  t8287 = 0.11*t8285;
  t8291 = Power(t1663,2);
  t8302 = 0.11*t8291;
  t8303 = t8287 + t8302;
  t8312 = -1.*t8308*t1673;
  t8349 = -1.*t1668*t8334;
  t8353 = t8312 + t8349;
  t8368 = t8308*t1705;
  t8377 = t1673*t8334;
  t8380 = t8368 + t8377;
  t8105 = -2.88*t1583;
  t8177 = -6.8*t1616*t8158;
  t8255 = -3.2*t1658*t8253;
  t8282 = -3.2*t1606*t8270;
  t8305 = -6.8*t1679*t8303;
  t8361 = -3.2*t1709*t8353;
  t8382 = -3.2*t1675*t8380;
  t8386 = t8105 + t8177 + t8255 + t8282 + t8305 + t8361 + t8382;
  t8537 = 2.88*t1458;
  t8541 = -6.8*t1729*t8158;
  t8549 = -3.2*t1777*t8253;
  t8553 = -3.2*t1773*t8270;
  t8558 = -6.8*t1802*t8303;
  t8582 = -3.2*t7652*t8353;
  t8586 = -3.2*t4028*t8380;
  t8593 = t8537 + t8541 + t8549 + t8553 + t8558 + t8582 + t8586;
  t8423 = -0.748*t1729;
  t8455 = -3.2*t1649*t1777;
  t8456 = -3.2*t1644*t1773;
  t8457 = t8423 + t8455 + t8456;
  t1617 = -0.748*t1616;
  t1645 = -3.2*t1644*t1606;
  t1659 = -3.2*t1649*t1658;
  t1660 = t1617 + t1645 + t1659;
  t8605 = -0.748*t8158;
  t8607 = -3.2*t1649*t8253;
  t8608 = -3.2*t1644*t8270;
  t8612 = -0.67 + t8605 + t8607 + t8608;
  t8702 = -0.768*t1644;
  t8726 = -0.2 + t8702;
  t8600 = -0.768*t8270;
  t8601 = -0.2 + t8600;
  t8464 = -0.748*t1802;
  t8467 = -3.2*t1697*t7652;
  t8468 = -3.2*t1692*t4028;
  t8470 = t8464 + t8467 + t8468;
  t1680 = -0.748*t1679;
  t1693 = -3.2*t1692*t1675;
  t1710 = -3.2*t1697*t1709;
  t1711 = t1680 + t1693 + t1710;
  t8620 = -0.748*t8303;
  t8622 = -3.2*t1697*t8353;
  t8636 = -3.2*t1692*t8380;
  t8640 = -0.67 + t8620 + t8622 + t8636;
  t13315 = -0.768*t1692;
  t13316 = -0.2 + t13315;
  t8615 = -0.768*t8380;
  t8616 = -0.2 + t8615;
  p_output1[0]=(-3.2*Power(t1606,2) - 3.2*Power(t1658,2) - 3.2*Power(t1675,2) - 3.2*Power(t1709,2) - 6.8*Power(t1742,2) - 6.8*Power(t1807,2) + t7892 + t7925 + t7963 + t8047)*var2[0] + t7666*var2[1] + t8386*var2[2] + t1660*var2[3] - 0.768*t1606*var2[4] + t1711*var2[5] - 0.768*t1675*var2[6];
  p_output1[1]=t7666*var2[0] + (-6.8*Power(t1729,2) - 3.2*Power(t1773,2) - 3.2*Power(t1777,2) - 6.8*Power(t1802,2) - 3.2*Power(t4028,2) - 3.2*Power(t7652,2) + t7892 + t7925 + t7963 + t8047)*var2[1] + t8593*var2[2] + t8457*var2[3] - 0.768*t1773*var2[4] + t8470*var2[5] - 0.768*t4028*var2[6];
  p_output1[2]=t8386*var2[0] + t8593*var2[1] + (-3.3612 - 6.8*Power(t8158,2) - 3.2*Power(t8253,2) - 3.2*Power(t8270,2) - 6.8*Power(t8303,2) - 3.2*Power(t8353,2) - 3.2*Power(t8380,2))*var2[2] + t8612*var2[3] + t8601*var2[4] + t8640*var2[5] + t8616*var2[6];
  p_output1[3]=t1660*var2[0] + t8457*var2[1] + t8612*var2[2] + (-1.58228 - 3.2*Power(t1644,2) - 3.2*Power(t1649,2))*var2[3] + t8726*var2[4];
  p_output1[4]=-0.768*t1606*var2[0] - 0.768*t1773*var2[1] + t8601*var2[2] + t8726*var2[3] - 1.2143199999999998*var2[4];
  p_output1[5]=t1711*var2[0] + t8470*var2[1] + t8640*var2[2] + (-1.58228 - 3.2*Power(t1692,2) - 3.2*Power(t1697,2))*var2[5] + t13316*var2[6];
  p_output1[6]=-0.768*t1675*var2[0] - 0.768*t4028*var2[1] + t8616*var2[2] + t13316*var2[5] - 1.2143199999999998*var2[6];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "MmatDx_five_link_walker.hh"

namespace RightStance
{

void MmatDx_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
