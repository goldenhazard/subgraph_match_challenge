/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:31 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t9537;
  double t9765;
  double t261;
  double t3730;
  double t60;
  double t1043;
  double t9604;
  double t9623;
  double t9624;
  double t9653;
  double t9751;
  double t13846;
  double t13847;
  double t13852;
  double t262;
  double t3731;
  double t7975;
  double t9536;
  double t11788;
  double t11903;
  double t13745;
  double t13949;
  double t13964;
  double t13965;
  double t13855;
  double t13926;
  double t13935;
  double t13936;
  double t13937;
  double t13966;
  double t13982;
  double t13988;
  double t13993;
  double t13809;
  double t13810;
  double t13811;
  double t13994;
  double t13995;
  double t13996;
  double t13997;
  double t13998;
  double t13999;
  double t13974;
  double t14026;
  double t14027;
  double t14028;
  double t14029;
  double t13978;
  double t14030;
  double t14006;
  double t14011;
  double t14012;
  double t13819;
  double t13859;
  double t14039;
  double t14002;
  double t14003;
  double t14004;
  double t14040;
  double t14041;
  double t14042;
  double t14066;
  double t14067;
  double t14068;
  double t14051;
  double t14056;
  double t14060;
  double t14062;
  double t14063;
  double t14064;
  double t14065;
  double t14069;
  double t14096;
  double t14097;
  double t14074;
  double t14099;
  double t14100;
  double t14076;
  t9537 = Cos(var1[4]);
  t9765 = Sin(var1[4]);
  t261 = Sin(var1[2]);
  t3730 = Sin(var1[3]);
  t60 = Cos(var1[3]);
  t1043 = Cos(var1[2]);
  t9604 = -1.*t9537;
  t9623 = 1. + t9604;
  t9624 = 0.4*t9623;
  t9653 = 0.64*t9537;
  t9751 = t9624 + t9653;
  t13846 = t60*t9537;
  t13847 = -1.*t3730*t9765;
  t13852 = t13846 + t13847;
  t262 = -1.*t60*t261;
  t3731 = -1.*t1043*t3730;
  t7975 = t262 + t3731;
  t9536 = 0.748*t7975;
  t11788 = t9751*t9765;
  t11903 = -0.24*t9537*t9765;
  t13745 = t11788 + t11903;
  t13949 = -1.*t9537*t3730;
  t13964 = -1.*t60*t9765;
  t13965 = t13949 + t13964;
  t13855 = t1043*t13852;
  t13926 = t9751*t9537;
  t13935 = Power(t9765,2);
  t13936 = 0.24*t13935;
  t13937 = t13926 + t13936;
  t13966 = t1043*t13965;
  t13982 = t261*t13965;
  t13988 = t13982 + t13855;
  t13993 = 3.2*t13745*t13988;
  t13809 = t9537*t3730;
  t13810 = t60*t9765;
  t13811 = t13809 + t13810;
  t13994 = -1.*t60*t9537;
  t13995 = t3730*t9765;
  t13996 = t13994 + t13995;
  t13997 = t261*t13996;
  t13998 = t13966 + t13997;
  t13999 = 3.2*t13937*t13998;
  t13974 = -1.*t261*t13852;
  t14026 = -1.*t1043*t60;
  t14027 = t261*t3730;
  t14028 = t14026 + t14027;
  t14029 = 0.748*t14028;
  t13978 = t13966 + t13974;
  t14030 = -1.*t261*t13965;
  t14006 = Power(t9537,2);
  t14011 = -0.24*t14006;
  t14012 = t13926 + t14011;
  t13819 = -1.*t261*t13811;
  t13859 = t13819 + t13855;
  t14039 = 3.2*t13745*t13978;
  t14002 = -1.*t9751*t9765;
  t14003 = 0.24*t9537*t9765;
  t14004 = t14002 + t14003;
  t14040 = t1043*t13996;
  t14041 = t14030 + t14040;
  t14042 = 3.2*t13937*t14041;
  t14066 = t60*t9751;
  t14067 = -0.24*t3730*t9765;
  t14068 = t14066 + t14067;
  t14051 = -1.*t9751*t3730;
  t14056 = -0.24*t60*t9765;
  t14060 = t14051 + t14056;
  t14062 = t9751*t3730;
  t14063 = 0.24*t60*t9765;
  t14064 = t14062 + t14063;
  t14065 = t14064*t13852;
  t14069 = t13965*t14068;
  t14096 = -0.24*t9537*t3730;
  t14097 = t14096 + t14056;
  t14074 = -1.*t13965*t14064;
  t14099 = 0.24*t60*t9537;
  t14100 = t14099 + t14067;
  t14076 = -1.*t14068*t13996;
  p_output1[0]=var2[3]*(-0.5*(3.2*t13745*t13859 + 3.2*t13937*t13978 + t9536)*var2[2] - 0.5*(t13993 + t13999 + t9536)*var2[3] - 0.5*(t13993 + t13999 + 3.2*t13988*t14004 + 3.2*t14012*(t1043*t13811 + t13852*t261))*var2[4]);
  p_output1[1]=var2[3]*(-0.5*(3.2*t13745*(-1.*t1043*t13811 + t13974) + t14029 + 3.2*t13937*(-1.*t1043*t13852 + t14030))*var2[2] - 0.5*(t14029 + t14039 + t14042)*var2[3] - 0.5*(3.2*t13978*t14004 + 3.2*t13859*t14012 + t14039 + t14042)*var2[4]);
  p_output1[2]=var2[3]*(-0.5*(3.2*t13937*(t13852*t14060 + t14065 + t13811*t14068 + t14069) + 3.2*t13745*(-1.*t13965*t14060 - 1.*t13852*t14068 + t14074 + t14076))*var2[3] - 0.5*(3.2*t14004*(t13811*t14064 + t13852*t14068) + 3.2*t14012*(-1.*t13852*t14064 - 1.*t13965*t14068) + 3.2*t13937*(t14065 + t14069 + t13852*t14097 + t13811*t14100) + 3.2*t13745*(t14074 + t14076 - 1.*t13965*t14097 - 1.*t13852*t14100))*var2[4]);
  p_output1[3]=-0.5*(6.4*t13937*t14004 + 6.4*t13745*t14012)*var2[3]*var2[4];
  p_output1[4]=-0.384*t14004*var2[3]*var2[4];
  p_output1[5]=0;
  p_output1[6]=0;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce1_vec4_five_link_walker.hh"

namespace RightStance
{

void Ce1_vec4_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
