/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:46 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t9063;
  double t278;
  double t3696;
  double t9120;
  double t9220;
  double t121;
  double t7633;
  double t9215;
  double t9218;
  double t9219;
  double t9221;
  double t9222;
  double t9224;
  double t9225;
  double t9226;
  double t9265;
  double t9266;
  double t9280;
  double t9285;
  double t9289;
  double t11100;
  double t11092;
  double t11095;
  double t11104;
  double t11098;
  double t11108;
  double t11109;
  double t11111;
  double t11112;
  double t11116;
  double t11120;
  double t11132;
  double t11134;
  double t11147;
  double t11149;
  double t11150;
  double t11160;
  double t11161;
  double t11282;
  double t11283;
  double t11293;
  double t11231;
  double t11272;
  double t11275;
  double t9230;
  double t9233;
  double t9234;
  double t11372;
  double t11400;
  double t11418;
  double t11055;
  double t11010;
  double t11016;
  double t11038;
  double t11054;
  double t11058;
  double t11531;
  double t11546;
  double t11604;
  double t11609;
  double t11612;
  double t11579;
  double t11586;
  double t11587;
  double t11140;
  double t11142;
  double t11143;
  double t11616;
  double t11619;
  double t11622;
  double t11208;
  double t11184;
  double t11192;
  double t11193;
  double t11195;
  double t11223;
  double t11646;
  double t11681;
  double t11541;
  double t11542;
  double t11519;
  double t11538;
  double t11513;
  double t11514;
  double t11575;
  double t11576;
  double t11676;
  double t11677;
  double t11645;
  double t11647;
  double t11636;
  double t11640;
  double t11727;
  double t11731;
  double t12156;
  double t12158;
  double t12159;
  double t12164;
  double t12165;
  double t12170;
  double t12520;
  double t12521;
  double t12553;
  double t12601;
  double t12623;
  double t12628;
  double t9261;
  double t9580;
  double t10891;
  double t10949;
  double t9290;
  double t9292;
  double t9293;
  double t9297;
  double t13020;
  double t13021;
  double t13037;
  double t13038;
  double t13067;
  double t11329;
  double t11471;
  double t11498;
  double t11512;
  double t11545;
  double t11764;
  double t11765;
  double t11766;
  double t11767;
  double t11771;
  double t11803;
  double t13214;
  double t13238;
  double t12114;
  double t12120;
  double t12121;
  double t12126;
  double t12132;
  double t12139;
  double t12162;
  double t12222;
  double t12225;
  double t12356;
  double t12385;
  double t12388;
  double t13516;
  double t13528;
  double t13547;
  double t13081;
  double t13082;
  double t13084;
  double t13089;
  double t13094;
  double t13096;
  double t13103;
  double t13110;
  double t13133;
  double t13141;
  double t13266;
  double t13304;
  double t13336;
  double t13342;
  double t13365;
  double t13511;
  double t13580;
  double t13608;
  double t13698;
  double t14616;
  double t14621;
  double t14428;
  double t14630;
  double t14631;
  double t14443;
  double t11146;
  double t11173;
  double t11175;
  double t11178;
  double t11163;
  double t11165;
  double t11166;
  double t11169;
  double t14670;
  double t14671;
  double t14672;
  double t14673;
  double t14674;
  double t11614;
  double t11625;
  double t11626;
  double t11628;
  double t11680;
  double t11827;
  double t11848;
  double t11858;
  double t11869;
  double t11895;
  double t11934;
  double t14694;
  double t14695;
  double t12471;
  double t12474;
  double t12477;
  double t12503;
  double t12505;
  double t12507;
  double t12556;
  double t12793;
  double t12903;
  double t12995;
  double t12998;
  double t12999;
  double t14729;
  double t14730;
  double t14731;
  double t14675;
  double t14676;
  double t14677;
  double t14680;
  double t14682;
  double t14684;
  double t14685;
  double t14690;
  double t14691;
  double t14693;
  double t14696;
  double t14700;
  double t14702;
  double t14703;
  double t14704;
  double t14728;
  double t14733;
  double t14734;
  double t14738;
  double t14807;
  double t14808;
  double t14740;
  double t14812;
  double t14813;
  double t14742;
  double t11815;
  double t11821;
  double t11969;
  double t11979;
  double t14828;
  double t14829;
  double t14830;
  double t14831;
  double t14832;
  double t14837;
  double t14841;
  double t14845;
  double t14846;
  double t14848;
  double t14849;
  double t14850;
  double t14851;
  double t14852;
  double t14853;
  double t14854;
  double t14860;
  double t14861;
  double t14862;
  double t14863;
  double t14864;
  double t14870;
  double t14875;
  double t14876;
  double t14877;
  double t14881;
  double t14893;
  double t14894;
  double t14897;
  double t14898;
  double t14904;
  double t14905;
  double t14906;
  double t14907;
  double t11558;
  double t11571;
  double t11573;
  double t11696;
  double t11722;
  double t11723;
  double t11518;
  double t11539;
  double t11560;
  double t11578;
  double t11641;
  double t11649;
  double t11717;
  double t11750;
  double t11753;
  double t14936;
  double t14953;
  double t14954;
  double t13274;
  double t14973;
  double t13548;
  double t13634;
  double t13636;
  double t13707;
  double t14442;
  double t14444;
  double t14983;
  double t14984;
  double t14593;
  double t14597;
  double t14602;
  double t14550;
  double t14590;
  double t14591;
  double t14985;
  double t14988;
  double t14989;
  double t14990;
  double t14991;
  double t14611;
  double t14995;
  double t14625;
  double t14632;
  double t14633;
  double t14997;
  double t14662;
  double t14663;
  double t14664;
  double t14947;
  double t14961;
  double t14962;
  double t14698;
  double t14976;
  double t14732;
  double t14735;
  double t14736;
  double t14739;
  double t14741;
  double t14743;
  double t15016;
  double t15017;
  double t14777;
  double t14778;
  double t14779;
  double t14770;
  double t14774;
  double t14775;
  double t15018;
  double t15021;
  double t15022;
  double t15023;
  double t15024;
  double t14791;
  double t15028;
  double t14809;
  double t14817;
  double t14818;
  double t15030;
  double t14820;
  double t14821;
  double t14822;
  double t14891;
  double t9229;
  double t9310;
  double t11060;
  double t11061;
  double t11069;
  double t11139;
  double t11172;
  double t11226;
  double t11229;
  double t11230;
  double t15049;
  double t15050;
  double t15051;
  double t15052;
  double t15053;
  double t15054;
  double t15055;
  double t12098;
  double t12313;
  double t12404;
  double t12916;
  double t13003;
  double t13007;
  double t14972;
  double t14974;
  double t14975;
  double t14977;
  double t14978;
  double t14979;
  double t13655;
  double t14451;
  double t14512;
  double t14996;
  double t14998;
  double t14999;
  double t14661;
  double t14665;
  double t14666;
  double t15010;
  double t15011;
  double t15012;
  double t14737;
  double t14744;
  double t14745;
  double t15029;
  double t15031;
  double t15032;
  double t14819;
  double t14823;
  double t14824;
  double t15043;
  double t15044;
  double t15045;
  double t14911;
  double t14912;
  double t14913;
  double t14914;
  double t14915;
  double t14916;
  double t14917;
  double t14922;
  double t13008;
  double t14937;
  double t14938;
  double t14939;
  double t13085;
  double t14986;
  double t14592;
  double t14603;
  double t14608;
  double t15003;
  double t15004;
  double t15005;
  double t14931;
  double t15061;
  double t15108;
  double t15109;
  double t15110;
  double t15111;
  double t14932;
  double t15062;
  double t14948;
  double t14949;
  double t14951;
  double t14678;
  double t15019;
  double t14776;
  double t14780;
  double t14785;
  double t15036;
  double t15037;
  double t15038;
  double t14933;
  double t15063;
  double t15134;
  double t15135;
  double t15136;
  double t15137;
  double t14934;
  double t15064;
  t9063 = Cos(var1[3]);
  t278 = Cos(var1[4]);
  t3696 = Sin(var1[3]);
  t9120 = Sin(var1[4]);
  t9220 = Cos(var1[2]);
  t121 = Sin(var1[2]);
  t7633 = -1.*t278*t3696;
  t9215 = -1.*t9063*t9120;
  t9218 = t7633 + t9215;
  t9219 = -1.*t121*t9218;
  t9221 = t9063*t278;
  t9222 = -1.*t3696*t9120;
  t9224 = t9221 + t9222;
  t9225 = -1.*t9220*t9224;
  t9226 = t9219 + t9225;
  t9265 = -1.*t278;
  t9266 = 1. + t9265;
  t9280 = 0.4*t9266;
  t9285 = 0.64*t278;
  t9289 = t9280 + t9285;
  t11100 = Cos(var1[5]);
  t11092 = Cos(var1[6]);
  t11095 = Sin(var1[5]);
  t11104 = Sin(var1[6]);
  t11098 = -1.*t11092*t11095;
  t11108 = -1.*t11100*t11104;
  t11109 = t11098 + t11108;
  t11111 = -1.*t121*t11109;
  t11112 = t11100*t11092;
  t11116 = -1.*t11095*t11104;
  t11120 = t11112 + t11116;
  t11132 = -1.*t9220*t11120;
  t11134 = t11111 + t11132;
  t11147 = -1.*t11092;
  t11149 = 1. + t11147;
  t11150 = 0.4*t11149;
  t11160 = 0.64*t11092;
  t11161 = t11150 + t11160;
  t11282 = t9220*t9063;
  t11283 = -1.*t121*t3696;
  t11293 = t11282 + t11283;
  t11231 = -1.*t9063*t121;
  t11272 = -1.*t9220*t3696;
  t11275 = t11231 + t11272;
  t9230 = -1.*t9220*t9063;
  t9233 = t121*t3696;
  t9234 = t9230 + t9233;
  t11372 = t9063*t121;
  t11400 = t9220*t3696;
  t11418 = t11372 + t11400;
  t11055 = -1.*t121*t9224;
  t11010 = t278*t3696;
  t11016 = t9063*t9120;
  t11038 = t11010 + t11016;
  t11054 = -1.*t9220*t11038;
  t11058 = t11054 + t11055;
  t11531 = t9220*t9224;
  t11546 = t121*t9224;
  t11604 = t9220*t11100;
  t11609 = -1.*t121*t11095;
  t11612 = t11604 + t11609;
  t11579 = -1.*t11100*t121;
  t11586 = -1.*t9220*t11095;
  t11587 = t11579 + t11586;
  t11140 = -1.*t9220*t11100;
  t11142 = t121*t11095;
  t11143 = t11140 + t11142;
  t11616 = t11100*t121;
  t11619 = t9220*t11095;
  t11622 = t11616 + t11619;
  t11208 = -1.*t121*t11120;
  t11184 = t11092*t11095;
  t11192 = t11100*t11104;
  t11193 = t11184 + t11192;
  t11195 = -1.*t9220*t11193;
  t11223 = t11195 + t11208;
  t11646 = t9220*t11120;
  t11681 = t121*t11120;
  t11541 = t121*t9218;
  t11542 = t11541 + t11531;
  t11519 = -1.*t121*t11038;
  t11538 = t11519 + t11531;
  t11513 = t9220*t9218;
  t11514 = t11513 + t11055;
  t11575 = t9220*t11038;
  t11576 = t11575 + t11546;
  t11676 = t121*t11109;
  t11677 = t11676 + t11646;
  t11645 = -1.*t121*t11193;
  t11647 = t11645 + t11646;
  t11636 = t9220*t11109;
  t11640 = t11636 + t11208;
  t11727 = t9220*t11193;
  t11731 = t11727 + t11681;
  t12156 = t9289*t3696;
  t12158 = 0.24*t9063*t9120;
  t12159 = t12156 + t12158;
  t12164 = t9063*t9289;
  t12165 = -0.24*t3696*t9120;
  t12170 = t12164 + t12165;
  t12520 = t11161*t11095;
  t12521 = 0.24*t11100*t11104;
  t12553 = t12520 + t12521;
  t12601 = t11100*t11161;
  t12623 = -0.24*t11095*t11104;
  t12628 = t12601 + t12623;
  t9261 = 0.748*t9234;
  t9580 = t9289*t9120;
  t10891 = -0.24*t278*t9120;
  t10949 = t9580 + t10891;
  t9290 = t9289*t278;
  t9292 = Power(t9120,2);
  t9293 = 0.24*t9292;
  t9297 = t9290 + t9293;
  t13020 = -1.*t9063*t278;
  t13021 = t3696*t9120;
  t13037 = t13020 + t13021;
  t13038 = t9220*t13037;
  t13067 = t9219 + t13038;
  t11329 = 20.4*t11275*t11293;
  t11471 = 6.8*t11418*t11293;
  t11498 = 20.4*t11275*t9234;
  t11512 = 6.8*t11418*t9234;
  t11545 = -1.*t9220*t9218;
  t11764 = Power(t11275,2);
  t11765 = 13.6*t11764;
  t11766 = 13.6*t11275*t11418;
  t11767 = Power(t11293,2);
  t11771 = 13.6*t11767;
  t11803 = 13.6*t11293*t9234;
  t13214 = t121*t13037;
  t13238 = t11513 + t13214;
  t12114 = Power(t9063,2);
  t12120 = 0.11*t12114;
  t12121 = Power(t3696,2);
  t12126 = 0.11*t12121;
  t12132 = t12120 + t12126;
  t12139 = 6.8*t9234*t12132;
  t12162 = -1.*t12159*t9224;
  t12222 = -1.*t9218*t12170;
  t12225 = t12162 + t12222;
  t12356 = t12159*t11038;
  t12385 = t9224*t12170;
  t12388 = t12356 + t12385;
  t13516 = -1.*t9289*t3696;
  t13528 = -0.24*t9063*t9120;
  t13547 = t13516 + t13528;
  t13081 = -0.384*var2[4]*t13067;
  t13082 = 3.2*t10949*t11514;
  t13084 = 3.2*t9297*t13067;
  t13089 = 6.4*t11538*t11514;
  t13094 = 3.2*t11542*t11058;
  t13096 = 3.2*t9226*t11576;
  t13103 = 6.4*t11514*t13067;
  t13110 = -1.*t121*t13037;
  t13133 = t11545 + t13110;
  t13141 = 3.2*t11542*t13133;
  t13266 = 3.2*t9226*t13238;
  t13304 = 6.4*t11542*t11538;
  t13336 = 6.4*t11514*t11576;
  t13342 = 6.4*t11542*t13067;
  t13365 = 6.4*t11514*t13238;
  t13511 = 3.2*t11514*t12225;
  t13580 = t12159*t9224;
  t13608 = t9218*t12170;
  t13698 = 3.2*t12388*t13067;
  t14616 = -0.24*t278*t3696;
  t14621 = t14616 + t13528;
  t14428 = -1.*t9218*t12159;
  t14630 = 0.24*t9063*t278;
  t14631 = t14630 + t12165;
  t14443 = -1.*t12170*t13037;
  t11146 = 0.748*t11143;
  t11173 = t11161*t11104;
  t11175 = -0.24*t11092*t11104;
  t11178 = t11173 + t11175;
  t11163 = t11161*t11092;
  t11165 = Power(t11104,2);
  t11166 = 0.24*t11165;
  t11169 = t11163 + t11166;
  t14670 = -1.*t11100*t11092;
  t14671 = t11095*t11104;
  t14672 = t14670 + t14671;
  t14673 = t9220*t14672;
  t14674 = t11111 + t14673;
  t11614 = 20.4*t11587*t11612;
  t11625 = 6.8*t11622*t11612;
  t11626 = 20.4*t11587*t11143;
  t11628 = 6.8*t11622*t11143;
  t11680 = -1.*t9220*t11109;
  t11827 = Power(t11587,2);
  t11848 = 13.6*t11827;
  t11858 = 13.6*t11587*t11622;
  t11869 = Power(t11612,2);
  t11895 = 13.6*t11869;
  t11934 = 13.6*t11612*t11143;
  t14694 = t121*t14672;
  t14695 = t11636 + t14694;
  t12471 = Power(t11100,2);
  t12474 = 0.11*t12471;
  t12477 = Power(t11095,2);
  t12503 = 0.11*t12477;
  t12505 = t12474 + t12503;
  t12507 = 6.8*t11143*t12505;
  t12556 = -1.*t12553*t11120;
  t12793 = -1.*t11109*t12628;
  t12903 = t12556 + t12793;
  t12995 = t12553*t11193;
  t12998 = t11120*t12628;
  t12999 = t12995 + t12998;
  t14729 = -1.*t11161*t11095;
  t14730 = -0.24*t11100*t11104;
  t14731 = t14729 + t14730;
  t14675 = -0.384*var2[6]*t14674;
  t14676 = 3.2*t11178*t11640;
  t14677 = 3.2*t11169*t14674;
  t14680 = 6.4*t11647*t11640;
  t14682 = 3.2*t11677*t11223;
  t14684 = 3.2*t11134*t11731;
  t14685 = 6.4*t11640*t14674;
  t14690 = -1.*t121*t14672;
  t14691 = t11680 + t14690;
  t14693 = 3.2*t11677*t14691;
  t14696 = 3.2*t11134*t14695;
  t14700 = 6.4*t11677*t11647;
  t14702 = 6.4*t11640*t11731;
  t14703 = 6.4*t11677*t14674;
  t14704 = 6.4*t11640*t14695;
  t14728 = 3.2*t11640*t12903;
  t14733 = t12553*t11120;
  t14734 = t11109*t12628;
  t14738 = 3.2*t12999*t14674;
  t14807 = -0.24*t11092*t11095;
  t14808 = t14807 + t14730;
  t14740 = -1.*t11109*t12553;
  t14812 = 0.24*t11100*t11092;
  t14813 = t14812 + t12623;
  t14742 = -1.*t12628*t14672;
  t11815 = Power(t11538,2);
  t11821 = Power(t11514,2);
  t11969 = Power(t11647,2);
  t11979 = Power(t11640,2);
  t14828 = 13.6*t11275*t11293;
  t14829 = 13.6*t11418*t11293;
  t14830 = 6.4*t11542*t11514;
  t14831 = 6.4*t11538*t11576;
  t14832 = 13.6*t11587*t11612;
  t14837 = 13.6*t11622*t11612;
  t14841 = 6.4*t11677*t11640;
  t14845 = 6.4*t11647*t11731;
  t14846 = t14828 + t14829 + t14830 + t14831 + t14832 + t14837 + t14841 + t14845;
  t14848 = 6.8*t11764;
  t14849 = 6.8*t11275*t11418;
  t14850 = 6.8*t11767;
  t14851 = 6.8*t11293*t9234;
  t14852 = 3.2*t9226*t11542;
  t14853 = 3.2*t11815;
  t14854 = 3.2*t11821;
  t14860 = 3.2*t11058*t11576;
  t14861 = 6.8*t11827;
  t14862 = 6.8*t11587*t11622;
  t14863 = 6.8*t11869;
  t14864 = 6.8*t11612*t11143;
  t14870 = 3.2*t11134*t11677;
  t14875 = 3.2*t11969;
  t14876 = 3.2*t11979;
  t14877 = 3.2*t11223*t11731;
  t14881 = t14848 + t14849 + t14850 + t14851 + t14852 + t14853 + t14854 + t14860 + t14861 + t14862 + t14863 + t14864 + t14870 + t14875 + t14876 + t14877;
  t14893 = 0.748*t11275;
  t14894 = 3.2*t10949*t11538;
  t14897 = 3.2*t9297*t11514;
  t14898 = t14893 + t14894 + t14897;
  t14904 = 0.748*t11587;
  t14905 = 3.2*t11178*t11647;
  t14906 = 3.2*t11169*t11640;
  t14907 = t14904 + t14905 + t14906;
  t11558 = t11545 + t11546;
  t11571 = t121*t11038;
  t11573 = t11571 + t9225;
  t11696 = t11680 + t11681;
  t11722 = t121*t11193;
  t11723 = t11722 + t11132;
  t11518 = 9.6*t9226*t11514;
  t11539 = 9.6*t11538*t11058;
  t11560 = 3.2*t11542*t11558;
  t11578 = 3.2*t11573*t11576;
  t11641 = 9.6*t11134*t11640;
  t11649 = 9.6*t11647*t11223;
  t11717 = 3.2*t11677*t11696;
  t11750 = 3.2*t11723*t11731;
  t11753 = t11329 + t11471 + t11498 + t11512 + t11518 + t11539 + t11560 + t11578 + t11614 + t11625 + t11626 + t11628 + t11641 + t11649 + t11717 + t11750;
  t14936 = 0.748*t11418;
  t14953 = Power(t9234,2);
  t14954 = 13.6*t14953;
  t13274 = t11329 + t11471 + t11498 + t11512 + t13089 + t13094 + t13096 + t13103 + t13141 + t13266;
  t14973 = 6.8*t11418*t12132;
  t13548 = t13547*t9224;
  t13634 = t11038*t12170;
  t13636 = t13548 + t13580 + t13608 + t13634;
  t13707 = -1.*t9218*t13547;
  t14442 = -1.*t9224*t12170;
  t14444 = t13707 + t14428 + t14442 + t14443;
  t14983 = -0.384*var2[4]*t13133;
  t14984 = 3.2*t10949*t9226;
  t14593 = -1.*t9289*t9120;
  t14597 = 0.24*t278*t9120;
  t14602 = t14593 + t14597;
  t14550 = Power(t278,2);
  t14590 = -0.24*t14550;
  t14591 = t9290 + t14590;
  t14985 = 3.2*t9297*t13133;
  t14988 = 6.4*t9226*t11538;
  t14989 = 6.4*t11514*t11058;
  t14990 = 6.4*t9226*t13067;
  t14991 = 6.4*t11514*t13133;
  t14611 = t13089 + t13094 + t13096 + t13103 + t13141 + t13266;
  t14995 = 3.2*t9226*t12225;
  t14625 = t14621*t9224;
  t14632 = t11038*t14631;
  t14633 = t14625 + t13580 + t13608 + t14632;
  t14997 = 3.2*t12388*t13133;
  t14662 = -1.*t9218*t14621;
  t14663 = -1.*t9224*t14631;
  t14664 = t14662 + t14428 + t14663 + t14443;
  t14947 = 0.748*t11622;
  t14961 = Power(t11143,2);
  t14962 = 13.6*t14961;
  t14698 = t11614 + t11625 + t11626 + t11628 + t14680 + t14682 + t14684 + t14685 + t14693 + t14696;
  t14976 = 6.8*t11622*t12505;
  t14732 = t14731*t11120;
  t14735 = t11193*t12628;
  t14736 = t14732 + t14733 + t14734 + t14735;
  t14739 = -1.*t11109*t14731;
  t14741 = -1.*t11120*t12628;
  t14743 = t14739 + t14740 + t14741 + t14742;
  t15016 = -0.384*var2[6]*t14691;
  t15017 = 3.2*t11178*t11134;
  t14777 = -1.*t11161*t11104;
  t14778 = 0.24*t11092*t11104;
  t14779 = t14777 + t14778;
  t14770 = Power(t11092,2);
  t14774 = -0.24*t14770;
  t14775 = t11163 + t14774;
  t15018 = 3.2*t11169*t14691;
  t15021 = 6.4*t11134*t11647;
  t15022 = 6.4*t11640*t11223;
  t15023 = 6.4*t11134*t14674;
  t15024 = 6.4*t11640*t14691;
  t14791 = t14680 + t14682 + t14684 + t14685 + t14693 + t14696;
  t15028 = 3.2*t11134*t12903;
  t14809 = t14808*t11120;
  t14817 = t11193*t14813;
  t14818 = t14809 + t14733 + t14734 + t14817;
  t15030 = 3.2*t12999*t14691;
  t14820 = -1.*t11109*t14808;
  t14821 = -1.*t11120*t14813;
  t14822 = t14820 + t14740 + t14821 + t14742;
  t14891 = -0.5*var2[2]*t14881;
  t9229 = -0.384*var2[4]*t9226;
  t9310 = 3.2*t9297*t9226;
  t11060 = 3.2*t10949*t11058;
  t11061 = t9261 + t9310 + t11060;
  t11069 = -0.5*var2[3]*t11061;
  t11139 = -0.384*var2[6]*t11134;
  t11172 = 3.2*t11169*t11134;
  t11226 = 3.2*t11178*t11223;
  t11229 = t11146 + t11172 + t11226;
  t11230 = -0.5*var2[5]*t11229;
  t15049 = 13.6*t11275*t9234;
  t15050 = 6.4*t9226*t11514;
  t15051 = 6.4*t11538*t11058;
  t15052 = 13.6*t11587*t11143;
  t15053 = 6.4*t11134*t11640;
  t15054 = 6.4*t11647*t11223;
  t15055 = t14828 + t15049 + t15050 + t15051 + t14832 + t15052 + t15053 + t15054;
  t12098 = -2.88*t9220;
  t12313 = 3.2*t11058*t12225;
  t12404 = 3.2*t9226*t12388;
  t12916 = 3.2*t11223*t12903;
  t13003 = 3.2*t11134*t12999;
  t13007 = t12098 + t12139 + t12313 + t12404 + t12507 + t12916 + t13003;
  t14972 = 2.88*t121;
  t14974 = 3.2*t11573*t12225;
  t14975 = 3.2*t11558*t12388;
  t14977 = 3.2*t11723*t12903;
  t14978 = 3.2*t11696*t12999;
  t14979 = t14972 + t14973 + t14974 + t14975 + t14976 + t14977 + t14978;
  t13655 = 3.2*t11514*t13636;
  t14451 = 3.2*t11538*t14444;
  t14512 = t12139 + t13511 + t13655 + t13698 + t14451;
  t14996 = 3.2*t9226*t13636;
  t14998 = 3.2*t11058*t14444;
  t14999 = t14973 + t14995 + t14996 + t14997 + t14998;
  t14661 = 3.2*t11514*t14633;
  t14665 = 3.2*t11538*t14664;
  t14666 = t13511 + t14661 + t13698 + t14665;
  t15010 = 3.2*t9226*t14633;
  t15011 = 3.2*t11058*t14664;
  t15012 = t14995 + t15010 + t14997 + t15011;
  t14737 = 3.2*t11640*t14736;
  t14744 = 3.2*t11647*t14743;
  t14745 = t12507 + t14728 + t14737 + t14738 + t14744;
  t15029 = 3.2*t11134*t14736;
  t15031 = 3.2*t11223*t14743;
  t15032 = t14976 + t15028 + t15029 + t15030 + t15031;
  t14819 = 3.2*t11640*t14818;
  t14823 = 3.2*t11647*t14822;
  t14824 = t14728 + t14819 + t14738 + t14823;
  t15043 = 3.2*t11134*t14818;
  t15044 = 3.2*t11223*t14822;
  t15045 = t15028 + t15043 + t15030 + t15044;
  t14911 = -2.88*t121;
  t14912 = 6.8*t11275*t12132;
  t14913 = 3.2*t11538*t12225;
  t14914 = 3.2*t11514*t12388;
  t14915 = 6.8*t11587*t12505;
  t14916 = 3.2*t11647*t12903;
  t14917 = 3.2*t11640*t12999;
  t14922 = t14911 + t14912 + t14913 + t14914 + t14915 + t14916 + t14917;
  t13008 = -0.5*var2[2]*t13007;
  t14937 = 3.2*t10949*t11573;
  t14938 = 3.2*t9297*t11558;
  t14939 = t14936 + t14937 + t14938;
  t13085 = t9261 + t13082 + t13084;
  t14986 = t14936 + t14984 + t14985;
  t14592 = 3.2*t14591*t11538;
  t14603 = 3.2*t14602*t11514;
  t14608 = t14592 + t13082 + t14603 + t13084;
  t15003 = 3.2*t14602*t9226;
  t15004 = 3.2*t14591*t11058;
  t15005 = t14984 + t15003 + t15004 + t14985;
  t14931 = -0.5*var2[2]*t14898;
  t15061 = -0.5*var2[2]*t11061;
  t15108 = -0.384*var2[0]*t13067;
  t15109 = -0.384*var2[1]*t13133;
  t15110 = t15108 + t15109;
  t15111 = var2[2]*t15110;
  t14932 = -0.384*var2[2]*t11514;
  t15062 = -0.384*var2[2]*t9226;
  t14948 = 3.2*t11178*t11723;
  t14949 = 3.2*t11169*t11696;
  t14951 = t14947 + t14948 + t14949;
  t14678 = t11146 + t14676 + t14677;
  t15019 = t14947 + t15017 + t15018;
  t14776 = 3.2*t14775*t11647;
  t14780 = 3.2*t14779*t11640;
  t14785 = t14776 + t14676 + t14780 + t14677;
  t15036 = 3.2*t14779*t11134;
  t15037 = 3.2*t14775*t11223;
  t15038 = t15017 + t15036 + t15037 + t15018;
  t14933 = -0.5*var2[2]*t14907;
  t15063 = -0.5*var2[2]*t11229;
  t15134 = -0.384*var2[0]*t14674;
  t15135 = -0.384*var2[1]*t14691;
  t15136 = t15134 + t15135;
  t15137 = var2[2]*t15136;
  t14934 = -0.384*var2[2]*t11640;
  t15064 = -0.384*var2[2]*t11134;
  p_output1[0]=(t11069 + t11139 + t11230 + t13008 + t9229 - 0.5*(6.4*t11058*t11576 + 6.4*t11134*t11677 + 6.4*t11223*t11731 + t11765 + t11766 + t11771 + t11803 + 6.4*t11815 + 6.4*t11821 + t11848 + t11858 + t11895 + t11934 + 6.4*t11969 + 6.4*t11979 + 6.4*t11542*t9226)*var2[0] - 0.5*t11753*var2[1])*var2[2];
  p_output1[1]=var2[2]*(t13081 - 0.5*(t11765 + t11766 + t11771 + t11803 + t13304 + t13336 + t13342 + t13365)*var2[0] - 0.5*t13274*var2[1] - 0.5*t14512*var2[2] - 0.5*t13085*var2[3]);
  p_output1[2]=var2[2]*(t13081 - 0.5*(t13304 + t13336 + t13342 + t13365)*var2[0] - 0.5*t14611*var2[1] - 0.5*t14666*var2[2] - 0.5*t14608*var2[3]);
  p_output1[3]=var2[2]*(t14675 - 0.5*(t11848 + t11858 + t11895 + t11934 + t14700 + t14702 + t14703 + t14704)*var2[0] - 0.5*t14698*var2[1] - 0.5*t14745*var2[2] - 0.5*t14678*var2[5]);
  p_output1[4]=var2[2]*(t14675 - 0.5*(t14700 + t14702 + t14703 + t14704)*var2[0] - 0.5*t14791*var2[1] - 0.5*t14824*var2[2] - 0.5*t14785*var2[5]);
  p_output1[5]=-0.5*t14846*var2[2];
  p_output1[6]=t14891;
  p_output1[7]=-0.5*t14846*var2[0] - 0.5*t14881*var2[1] - 1.*t14922*var2[2] - 0.5*t14898*var2[3] - 0.384*t11514*var2[4] - 0.5*t14907*var2[5] - 0.384*t11640*var2[6];
  p_output1[8]=t14931;
  p_output1[9]=t14932;
  p_output1[10]=t14933;
  p_output1[11]=t14934;
  p_output1[12]=var2[2]*(-0.5*t11753*var2[0] - 0.5*(6.4*Power(t11058,2) + 6.4*Power(t11134,2) + 6.4*Power(t11223,2) + 6.4*t11514*t11558 + 6.4*t11538*t11573 + 6.4*t11640*t11696 + 6.4*t11647*t11723 + t11765 + t11766 + t11803 + t11848 + t11858 + t11934 + t14954 + t14962 + 6.4*Power(t9226,2))*var2[1] - 0.5*t14979*var2[2] - 0.5*t14939*var2[3] - 0.384*t11558*var2[4] - 0.5*t14951*var2[5] - 0.384*t11696*var2[6]);
  p_output1[13]=var2[2]*(t14983 - 0.5*t13274*var2[0] - 0.5*(t11765 + t11766 + t11803 + t14954 + t14988 + t14989 + t14990 + t14991)*var2[1] - 0.5*t14999*var2[2] - 0.5*t14986*var2[3]);
  p_output1[14]=var2[2]*(t14983 - 0.5*t14611*var2[0] - 0.5*(t14988 + t14989 + t14990 + t14991)*var2[1] - 0.5*t15012*var2[2] - 0.5*t15005*var2[3]);
  p_output1[15]=var2[2]*(t15016 - 0.5*t14698*var2[0] - 0.5*(t11848 + t11858 + t11934 + t14962 + t15021 + t15022 + t15023 + t15024)*var2[1] - 0.5*t15032*var2[2] - 0.5*t15019*var2[5]);
  p_output1[16]=var2[2]*(t15016 - 0.5*t14791*var2[0] - 0.5*(t15021 + t15022 + t15023 + t15024)*var2[1] - 0.5*t15045*var2[2] - 0.5*t15038*var2[5]);
  p_output1[17]=t14891;
  p_output1[18]=-0.5*t15055*var2[2];
  p_output1[19]=t11069 + t11139 + t11230 + t9229 - 0.5*t14881*var2[0] - 0.5*t15055*var2[1] - 1.*t13007*var2[2];
  p_output1[20]=t15061;
  p_output1[21]=t15062;
  p_output1[22]=t15063;
  p_output1[23]=t15064;
  p_output1[24]=(-0.5*t13007*var2[0] - 0.5*t14979*var2[1])*var2[2];
  p_output1[25]=(-0.5*t14512*var2[0] - 0.5*t14999*var2[1])*var2[2];
  p_output1[26]=(-0.5*t14666*var2[0] - 0.5*t15012*var2[1])*var2[2];
  p_output1[27]=(-0.5*t14745*var2[0] - 0.5*t15032*var2[1])*var2[2];
  p_output1[28]=(-0.5*t14824*var2[0] - 0.5*t15045*var2[1])*var2[2];
  p_output1[29]=-0.5*t14922*var2[2];
  p_output1[30]=t13008;
  p_output1[31]=-0.5*t14922*var2[0] - 0.5*t13007*var2[1];
  p_output1[32]=(-0.5*t11061*var2[0] - 0.5*t14939*var2[1])*var2[2];
  p_output1[33]=(-0.5*t13085*var2[0] - 0.5*t14986*var2[1])*var2[2];
  p_output1[34]=(-0.5*t14608*var2[0] - 0.5*t15005*var2[1])*var2[2];
  p_output1[35]=t14931;
  p_output1[36]=t15061;
  p_output1[37]=-0.5*t14898*var2[0] - 0.5*t11061*var2[1];
  p_output1[38]=(-0.384*t9226*var2[0] - 0.384*t11558*var2[1])*var2[2];
  p_output1[39]=t15111;
  p_output1[40]=t15111;
  p_output1[41]=t14932;
  p_output1[42]=t15062;
  p_output1[43]=-0.384*t11514*var2[0] - 0.384*t9226*var2[1];
  p_output1[44]=(-0.5*t11229*var2[0] - 0.5*t14951*var2[1])*var2[2];
  p_output1[45]=(-0.5*t14678*var2[0] - 0.5*t15019*var2[1])*var2[2];
  p_output1[46]=(-0.5*t14785*var2[0] - 0.5*t15038*var2[1])*var2[2];
  p_output1[47]=t14933;
  p_output1[48]=t15063;
  p_output1[49]=-0.5*t14907*var2[0] - 0.5*t11229*var2[1];
  p_output1[50]=(-0.384*t11134*var2[0] - 0.384*t11696*var2[1])*var2[2];
  p_output1[51]=t15137;
  p_output1[52]=t15137;
  p_output1[53]=t14934;
  p_output1[54]=t15064;
  p_output1[55]=-0.384*t11640*var2[0] - 0.384*t11134*var2[1];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 56, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce2_vec3_five_link_walker.hh"

namespace RightStance
{

void J_Ce2_vec3_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
