/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:32:23 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t11617;
  double t11141;
  double t11174;
  double t10255;
  double t17009;
  double t10209;
  double t12744;
  double t12750;
  double t12895;
  double t12896;
  double t16904;
  double t17215;
  double t17221;
  double t17222;
  double t17239;
  double t17276;
  double t17277;
  double t17280;
  double t17281;
  double t17282;
  double t17231;
  double t16910;
  double t17010;
  double t17011;
  double t17017;
  double t17024;
  double t17205;
  double t17210;
  double t10258;
  double t11533;
  double t11574;
  double t11607;
  double t17284;
  double t17214;
  double t17289;
  double t17290;
  double t17291;
  double t17295;
  double t17234;
  double t17302;
  double t17313;
  double t17314;
  double t17315;
  double t17310;
  double t17311;
  double t17312;
  double t17316;
  double t17317;
  double t17318;
  double t17321;
  double t17336;
  double t17337;
  double t17338;
  double t17329;
  double t17330;
  double t17331;
  double t17283;
  double t17285;
  double t17322;
  double t17323;
  double t17324;
  double t17332;
  double t17333;
  double t17334;
  double t17238;
  double t17286;
  double t17287;
  double t17348;
  double t17349;
  double t17350;
  double t17351;
  double t17352;
  double t17353;
  double t17354;
  double t17319;
  double t17320;
  double t17325;
  double t17326;
  double t17327;
  double t17328;
  double t17299;
  double t17377;
  double t17378;
  double t17379;
  double t17373;
  double t17374;
  double t17375;
  double t17387;
  double t17388;
  double t17389;
  double t17382;
  double t17383;
  double t17384;
  double t17360;
  double t17361;
  double t17362;
  double t17363;
  double t17366;
  double t17367;
  double t17368;
  double t17369;
  double t17370;
  double t17381;
  double t17421;
  double t17422;
  double t17390;
  double t17394;
  double t17425;
  double t17426;
  double t17428;
  double t17429;
  double t17398;
  double t17409;
  double t17410;
  double t17415;
  double t17416;
  double t17417;
  double t17418;
  double t17419;
  double t17435;
  double t17436;
  double t17437;
  double t17438;
  double t17439;
  double t17453;
  double t17454;
  double t17455;
  double t17458;
  double t17459;
  double t17460;
  double t17335;
  double t17339;
  double t17340;
  double t17341;
  double t17342;
  double t17343;
  double t17344;
  double t17345;
  double t17346;
  double t17347;
  double t17405;
  double t17406;
  double t17407;
  double t17408;
  double t17411;
  double t17412;
  double t17413;
  double t17414;
  double t17420;
  double t17423;
  double t17424;
  double t17427;
  double t17430;
  double t17431;
  double t17432;
  double t17433;
  double t17434;
  double t17440;
  double t17441;
  double t17442;
  double t17443;
  double t17444;
  double t17445;
  double t17446;
  double t17447;
  double t17448;
  double t17449;
  double t17450;
  double t17451;
  double t17452;
  double t17466;
  double t17467;
  double t17468;
  double t17303;
  double t17486;
  double t17491;
  double t17492;
  double t17494;
  double t17495;
  double t17497;
  double t17498;
  double t17499;
  double t17505;
  double t17506;
  double t17507;
  double t17517;
  double t17518;
  double t17519;
  double t17522;
  double t17523;
  double t17524;
  double t17525;
  double t17526;
  t11617 = Cos(var1[6]);
  t11141 = Sin(var1[2]);
  t11174 = Sin(var1[5]);
  t10255 = Cos(var1[5]);
  t17009 = Sin(var1[6]);
  t10209 = Cos(var1[2]);
  t12744 = -1.*t11617;
  t12750 = 1. + t12744;
  t12895 = 0.4*t12750;
  t12896 = 0.64*t11617;
  t16904 = t12895 + t12896;
  t17215 = t10255*t11617;
  t17221 = -1.*t11174*t17009;
  t17222 = t17215 + t17221;
  t17239 = t16904*t17009;
  t17276 = -0.24*t11617*t17009;
  t17277 = t17239 + t17276;
  t17280 = t11617*t11174;
  t17281 = t10255*t17009;
  t17282 = t17280 + t17281;
  t17231 = -1.*t10209*t17222;
  t16910 = t16904*t11617;
  t17010 = Power(t17009,2);
  t17011 = 0.24*t17010;
  t17017 = t16910 + t17011;
  t17024 = -1.*t11617*t11174;
  t17205 = -1.*t10255*t17009;
  t17210 = t17024 + t17205;
  t10258 = -1.*t10209*t10255;
  t11533 = t11141*t11174;
  t11574 = t10258 + t11533;
  t11607 = -0.748*t11574;
  t17284 = -1.*t11141*t17222;
  t17214 = -1.*t11141*t17210;
  t17289 = t10255*t11141;
  t17290 = t10209*t11174;
  t17291 = t17289 + t17290;
  t17295 = -0.748*t17291;
  t17234 = t17214 + t17231;
  t17302 = -1.*t10209*t17210;
  t17313 = -1.*t10255*t11617;
  t17314 = t11174*t17009;
  t17315 = t17313 + t17314;
  t17310 = t10209*t17210;
  t17311 = t17310 + t17284;
  t17312 = -3.2*t17277*t17311;
  t17316 = t10209*t17315;
  t17317 = t17214 + t17316;
  t17318 = -3.2*t17017*t17317;
  t17321 = -3.2*t17277*t17234;
  t17336 = -1.*t16904*t17009;
  t17337 = 0.24*t11617*t17009;
  t17338 = t17336 + t17337;
  t17329 = Power(t11617,2);
  t17330 = -0.24*t17329;
  t17331 = t16910 + t17330;
  t17283 = -1.*t10209*t17282;
  t17285 = t17283 + t17284;
  t17322 = -1.*t11141*t17315;
  t17323 = t17302 + t17322;
  t17324 = -3.2*t17017*t17323;
  t17332 = -1.*t11141*t17282;
  t17333 = t10209*t17222;
  t17334 = t17332 + t17333;
  t17238 = -3.2*t17017*t17234;
  t17286 = -3.2*t17277*t17285;
  t17287 = t11607 + t17238 + t17286;
  t17348 = -1.*t10255*t11141;
  t17349 = -1.*t10209*t11174;
  t17350 = t17348 + t17349;
  t17351 = -0.748*t17350;
  t17352 = -3.2*t17277*t17334;
  t17353 = -3.2*t17017*t17311;
  t17354 = t17351 + t17352 + t17353;
  t17319 = t11607 + t17312 + t17318;
  t17320 = -0.5*var2[0]*t17319;
  t17325 = t17295 + t17321 + t17324;
  t17326 = -0.5*var2[1]*t17325;
  t17327 = t17320 + t17326;
  t17328 = var2[5]*t17327;
  t17299 = t11141*t17282;
  t17377 = t10255*t16904;
  t17378 = -0.24*t11174*t17009;
  t17379 = t17377 + t17378;
  t17373 = -1.*t16904*t11174;
  t17374 = -0.24*t10255*t17009;
  t17375 = t17373 + t17374;
  t17387 = t16904*t11174;
  t17388 = 0.24*t10255*t17009;
  t17389 = t17387 + t17388;
  t17382 = -1.*t10255*t16904;
  t17383 = 0.24*t11174*t17009;
  t17384 = t17382 + t17383;
  t17360 = -3.2*t17277*t17317;
  t17361 = t10209*t17282;
  t17362 = t17361 + t17322;
  t17363 = -3.2*t17017*t17362;
  t17366 = t17299 + t17316;
  t17367 = -3.2*t17017*t17366;
  t17368 = t11141*t17315;
  t17369 = t17310 + t17368;
  t17370 = -3.2*t17277*t17369;
  t17381 = -1.*t17282*t17379;
  t17421 = -0.24*t11617*t11174;
  t17422 = t17421 + t17374;
  t17390 = -1.*t17389*t17315;
  t17394 = t17210*t17389;
  t17425 = 0.24*t10255*t11617;
  t17426 = t17425 + t17378;
  t17428 = -0.24*t10255*t11617;
  t17429 = t17428 + t17383;
  t17398 = t17379*t17315;
  t17409 = t11141*t17210;
  t17410 = t17409 + t17333;
  t17415 = t17375*t17222;
  t17416 = t17389*t17222;
  t17417 = t17210*t17379;
  t17418 = t17282*t17379;
  t17419 = t17415 + t17416 + t17417 + t17418;
  t17435 = -1.*t17210*t17375;
  t17436 = -1.*t17210*t17389;
  t17437 = -1.*t17222*t17379;
  t17438 = -1.*t17379*t17315;
  t17439 = t17435 + t17436 + t17437 + t17438;
  t17453 = -3.2*t17277*t17410;
  t17454 = -3.2*t17017*t17369;
  t17455 = t17351 + t17453 + t17454;
  t17458 = -3.2*t17017*t17419;
  t17459 = -3.2*t17277*t17439;
  t17460 = t17458 + t17459;
  t17335 = -3.2*t17331*t17334;
  t17339 = -3.2*t17338*t17311;
  t17340 = t17335 + t17312 + t17339 + t17318;
  t17341 = -0.5*var2[0]*t17340;
  t17342 = -3.2*t17338*t17234;
  t17343 = -3.2*t17331*t17285;
  t17344 = t17321 + t17342 + t17343 + t17324;
  t17345 = -0.5*var2[1]*t17344;
  t17346 = t17341 + t17345;
  t17347 = var2[5]*t17346;
  t17405 = -3.2*t17331*t17311;
  t17406 = -3.2*t17338*t17317;
  t17407 = t17405 + t17360 + t17406 + t17363;
  t17408 = -0.5*var2[1]*t17407;
  t17411 = -3.2*t17331*t17410;
  t17412 = -3.2*t17338*t17369;
  t17413 = t17411 + t17367 + t17370 + t17412;
  t17414 = -0.5*var2[0]*t17413;
  t17420 = -3.2*t17338*t17419;
  t17423 = -1.*t17422*t17222;
  t17424 = -1.*t17210*t17379;
  t17427 = -1.*t17210*t17426;
  t17430 = -1.*t17210*t17429;
  t17431 = -1.*t17375*t17315;
  t17432 = -1.*t17422*t17315;
  t17433 = t17423 + t17424 + t17381 + t17427 + t17430 + t17431 + t17432 + t17390;
  t17434 = -3.2*t17277*t17433;
  t17440 = -3.2*t17331*t17439;
  t17441 = t17210*t17375;
  t17442 = t17210*t17422;
  t17443 = t17422*t17282;
  t17444 = t17222*t17379;
  t17445 = t17222*t17426;
  t17446 = t17222*t17429;
  t17447 = t17441 + t17442 + t17394 + t17443 + t17444 + t17445 + t17446 + t17398;
  t17448 = -3.2*t17017*t17447;
  t17449 = t17420 + t17434 + t17440 + t17448;
  t17450 = -0.5*var2[2]*t17449;
  t17451 = t17408 + t17414 + t17450;
  t17452 = var2[5]*t17451;
  t17466 = -1.*t16904*t11617;
  t17467 = 0.24*t17329;
  t17468 = t17466 + t17467;
  t17303 = t11141*t17222;
  t17486 = t17361 + t17303;
  t17491 = -1.*t17389*t17222;
  t17492 = t17491 + t17424;
  t17494 = t17389*t17282;
  t17495 = t17494 + t17444;
  t17497 = t17422*t17222;
  t17498 = t17282*t17426;
  t17499 = t17497 + t17416 + t17417 + t17498;
  t17505 = -1.*t17210*t17422;
  t17506 = -1.*t17222*t17426;
  t17507 = t17505 + t17436 + t17506 + t17438;
  t17517 = -3.2*t17338*t17410;
  t17518 = -3.2*t17331*t17486;
  t17519 = t17453 + t17517 + t17518 + t17454;
  t17522 = -3.2*t17331*t17492;
  t17523 = -3.2*t17338*t17495;
  t17524 = -3.2*t17017*t17499;
  t17525 = -3.2*t17277*t17507;
  t17526 = t17522 + t17523 + t17524 + t17525;
  p_output1[0]=(-0.5*t17287*var2[0] - 0.5*(t17295 - 3.2*t17277*(t17231 + t17299) - 3.2*t17017*(t17302 + t17303))*var2[1])*var2[5];
  p_output1[1]=t17328;
  p_output1[2]=t17347;
  p_output1[3]=-0.5*t17354*var2[5];
  p_output1[4]=-0.5*t17287*var2[5];
  p_output1[5]=-0.5*t17354*var2[0] - 0.5*t17287*var2[1];
  p_output1[6]=t17328;
  p_output1[7]=(-0.5*(t11607 + t17367 + t17370)*var2[0] - 0.5*(t17295 + t17360 + t17363)*var2[1] - 0.5*(-3.2*t17277*(-1.*t17222*t17375 - 2.*t17315*t17375 - 2.*t17210*t17379 + t17381 - 1.*t17210*t17384 + t17390) - 3.2*t17017*(2.*t17210*t17375 + t17282*t17375 + 2.*t17222*t17379 + t17222*t17384 + t17394 + t17398))*var2[2])*var2[5];
  p_output1[8]=t17452;
  p_output1[9]=-0.5*t17455*var2[5];
  p_output1[10]=-0.5*t17319*var2[5];
  p_output1[11]=-0.5*t17460*var2[5];
  p_output1[12]=-0.5*t17455*var2[0] - 0.5*t17319*var2[1] - 0.5*t17460*var2[2];
  p_output1[13]=t17347;
  p_output1[14]=t17452;
  p_output1[15]=var2[5]*(-0.5*(t17367 - 6.4*t17338*t17369 + t17370 - 6.4*t17331*t17410 - 3.2*t17410*t17468 - 3.2*t17338*t17486)*var2[0] - 0.5*(-6.4*t17311*t17331 - 6.4*t17317*t17338 - 3.2*t17334*t17338 + t17360 + t17363 - 3.2*t17311*t17468)*var2[1] - 0.5*(-3.2*t17277*(t17381 + t17390 - 2.*t17315*t17422 + t17423 - 2.*t17210*t17426 + t17430) - 3.2*t17017*(t17394 + t17398 + 2.*t17210*t17422 + 2.*t17222*t17426 + t17443 + t17446) - 3.2*t17338*t17492 - 3.2*t17468*t17495 - 6.4*t17338*t17499 - 6.4*t17331*t17507)*var2[2] - 0.5*(-6.4*Power(t17331,2) - 6.4*t17277*t17338 - 6.4*Power(t17338,2) - 6.4*t17017*t17468)*var2[5] + 0.384*t17468*var2[6]);
  p_output1[16]=-0.5*t17519*var2[5];
  p_output1[17]=-0.5*t17340*var2[5];
  p_output1[18]=-0.5*t17526*var2[5];
  p_output1[19]=-0.5*t17519*var2[0] - 0.5*t17340*var2[1] - 0.5*t17526*var2[2] - 1.*(-6.4*t17277*t17331 - 6.4*t17017*t17338)*var2[5] + 0.384*t17338*var2[6];
  p_output1[20]=0.384*t17338*var2[5];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 21, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce3_vec6_five_link_walker.hh"

namespace RightStance
{

void J_Ce3_vec6_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
