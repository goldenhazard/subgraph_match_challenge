/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:44 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t10177;
  double t3490;
  double t3511;
  double t10195;
  double t10229;
  double t268;
  double t3737;
  double t10223;
  double t10227;
  double t10343;
  double t10344;
  double t10345;
  double t10415;
  double t10416;
  double t10228;
  double t10230;
  double t10310;
  double t10311;
  double t10331;
  double t10332;
  double t10337;
  double t10339;
  double t10340;
  double t10536;
  double t10537;
  double t10538;
  double t10446;
  double t10462;
  double t10463;
  double t10465;
  double t10467;
  double t10468;
  double t10599;
  double t10602;
  double t10603;
  double t10623;
  double t10624;
  double t10626;
  double t10638;
  double t10640;
  double t10641;
  double t10883;
  double t10885;
  double t11017;
  double t11018;
  double t11019;
  double t11021;
  double t11022;
  double t11023;
  double t11027;
  double t11030;
  double t11034;
  double t10888;
  double t10926;
  double t10945;
  double t10666;
  double t10667;
  double t10697;
  double t10440;
  double t10444;
  double t10445;
  double t10475;
  double t10481;
  double t10484;
  double t10485;
  double t10598;
  double t10730;
  double t10879;
  double t10657;
  double t10658;
  double t10660;
  double t10663;
  double t10664;
  double t10699;
  double t10882;
  double t10886;
  double t10946;
  double t10947;
  double t10948;
  double t10950;
  double t11011;
  double t11012;
  double t11013;
  double t11014;
  double t11020;
  double t11024;
  double t11025;
  double t11035;
  double t11036;
  double t11037;
  double t11040;
  double t11041;
  double t11043;
  double t11044;
  double t11045;
  double t11048;
  double t11049;
  double t11050;
  double t11051;
  double t11052;
  double t11080;
  double t11081;
  double t11083;
  double t11084;
  double t11085;
  double t11086;
  double t11015;
  double t11026;
  double t11042;
  double t11047;
  double t11053;
  double t11056;
  double t11064;
  double t11065;
  double t11066;
  double t11067;
  double t10341;
  double t10470;
  double t10487;
  double t10488;
  double t11096;
  double t11097;
  double t11099;
  t10177 = Cos(var1[3]);
  t3490 = Cos(var1[4]);
  t3511 = Sin(var1[3]);
  t10195 = Sin(var1[4]);
  t10229 = Sin(var1[2]);
  t268 = Cos(var1[2]);
  t3737 = -1.*t3490*t3511;
  t10223 = -1.*t10177*t10195;
  t10227 = t3737 + t10223;
  t10343 = -1.*t3490;
  t10344 = 1. + t10343;
  t10345 = 0.4*t10344;
  t10415 = 0.64*t3490;
  t10416 = t10345 + t10415;
  t10228 = t268*t10227;
  t10230 = -1.*t10177*t3490;
  t10310 = t3511*t10195;
  t10311 = t10230 + t10310;
  t10331 = t10229*t10311;
  t10332 = t10228 + t10331;
  t10337 = -1.*t10177*t10229;
  t10339 = -1.*t268*t3511;
  t10340 = t10337 + t10339;
  t10536 = t268*t10177;
  t10537 = -1.*t10229*t3511;
  t10538 = t10536 + t10537;
  t10446 = t10229*t10227;
  t10462 = t10177*t3490;
  t10463 = -1.*t3511*t10195;
  t10465 = t10462 + t10463;
  t10467 = t268*t10465;
  t10468 = t10446 + t10467;
  t10599 = t10177*t10229;
  t10602 = t268*t3511;
  t10603 = t10599 + t10602;
  t10623 = t3490*t3511;
  t10624 = t10177*t10195;
  t10626 = t10623 + t10624;
  t10638 = t268*t10626;
  t10640 = t10229*t10465;
  t10641 = t10638 + t10640;
  t10883 = -1.*t10229*t10465;
  t10885 = t10228 + t10883;
  t11017 = t10416*t3511;
  t11018 = 0.24*t10177*t10195;
  t11019 = t11017 + t11018;
  t11021 = t10177*t10416;
  t11022 = -0.24*t3511*t10195;
  t11023 = t11021 + t11022;
  t11027 = -1.*t10416*t3511;
  t11030 = -0.24*t10177*t10195;
  t11034 = t11027 + t11030;
  t10888 = -1.*t10229*t10227;
  t10926 = t268*t10311;
  t10945 = t10888 + t10926;
  t10666 = -1.*t268*t10177;
  t10667 = t10229*t3511;
  t10697 = t10666 + t10667;
  t10440 = t10416*t10195;
  t10444 = -0.24*t3490*t10195;
  t10445 = t10440 + t10444;
  t10475 = t10416*t3490;
  t10481 = Power(t10195,2);
  t10484 = 0.24*t10481;
  t10485 = t10475 + t10484;
  t10598 = 13.6*t10340*t10538;
  t10730 = -1.*t10229*t10626;
  t10879 = t10730 + t10467;
  t10657 = Power(t10340,2);
  t10658 = 6.8*t10657;
  t10660 = 6.8*t10340*t10603;
  t10663 = Power(t10538,2);
  t10664 = 6.8*t10663;
  t10699 = 6.8*t10538*t10697;
  t10882 = 3.2*t10468*t10879;
  t10886 = 3.2*t10885*t10641;
  t10946 = 3.2*t10468*t10945;
  t10947 = 3.2*t10885*t10332;
  t10948 = t10658 + t10660 + t10664 + t10699 + t10882 + t10886 + t10946 + t10947;
  t10950 = Power(t10177,2);
  t11011 = 0.11*t10950;
  t11012 = Power(t3511,2);
  t11013 = 0.11*t11012;
  t11014 = t11011 + t11013;
  t11020 = -1.*t11019*t10465;
  t11024 = -1.*t10227*t11023;
  t11025 = t11020 + t11024;
  t11035 = t11034*t10465;
  t11036 = t11019*t10465;
  t11037 = t10227*t11023;
  t11040 = t10626*t11023;
  t11041 = t11035 + t11036 + t11037 + t11040;
  t11043 = t11019*t10626;
  t11044 = t10465*t11023;
  t11045 = t11043 + t11044;
  t11048 = -1.*t10227*t11034;
  t11049 = -1.*t10227*t11019;
  t11050 = -1.*t10465*t11023;
  t11051 = -1.*t11023*t10311;
  t11052 = t11048 + t11049 + t11050 + t11051;
  t11080 = 6.8*t10697*t11014;
  t11081 = 3.2*t10885*t11025;
  t11083 = 3.2*t10885*t11041;
  t11084 = 3.2*t11045*t10945;
  t11085 = 3.2*t10879*t11052;
  t11086 = t11080 + t11081 + t11083 + t11084 + t11085;
  t11015 = 6.8*t10340*t11014;
  t11026 = 3.2*t10468*t11025;
  t11042 = 3.2*t10468*t11041;
  t11047 = 3.2*t11045*t10332;
  t11053 = 3.2*t10641*t11052;
  t11056 = t11015 + t11026 + t11042 + t11047 + t11053;
  t11064 = 0.748*t10697;
  t11065 = 3.2*t10445*t10885;
  t11066 = 3.2*t10485*t10945;
  t11067 = t11064 + t11065 + t11066;
  t10341 = 0.748*t10340;
  t10470 = 3.2*t10445*t10468;
  t10487 = 3.2*t10485*t10332;
  t10488 = t10341 + t10470 + t10487;
  t11096 = 3.2*t10485*t11041;
  t11097 = 3.2*t10445*t11052;
  t11099 = t11096 + t11097;
  p_output1[0]=var2[3]*(-0.5*(6.4*t10332*t10468 + t10598 + 13.6*t10538*t10603 + 6.4*t10468*t10641)*var2[0] - 0.5*t10948*var2[1] - 0.5*t11056*var2[2] - 0.5*t10488*var2[3] - 0.384*t10332*var2[4]);
  p_output1[1]=var2[3]*(-0.5*t10948*var2[0] - 0.5*(t10598 + 13.6*t10340*t10697 + 6.4*t10879*t10885 + 6.4*t10885*t10945)*var2[1] - 0.5*t11086*var2[2] - 0.5*t11067*var2[3] - 0.384*t10945*var2[4]);
  p_output1[2]=var2[3]*(-0.5*t11056*var2[0] - 0.5*t11086*var2[1] - 0.5*(6.4*t11041*t11045 + 6.4*t11025*t11052)*var2[2] - 0.5*t11099*var2[3] - 0.384*t11041*var2[4]);
  p_output1[3]=(-0.5*t10488*var2[0] - 0.5*t11067*var2[1] - 0.5*t11099*var2[2])*var2[3];
  p_output1[4]=(-0.384*t10332*var2[0] - 0.384*t10945*var2[1] - 0.384*t11041*var2[2])*var2[3];
  p_output1[5]=0;
  p_output1[6]=0;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce2_vec4_five_link_walker.hh"

namespace RightStance
{

void Ce2_vec4_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
