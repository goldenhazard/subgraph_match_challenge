/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:28 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t3940;
  double t1804;
  double t3607;
  double t4042;
  double t1744;
  double t7973;
  double t7974;
  double t8049;
  double t8056;
  double t8113;
  double t3915;
  double t4054;
  double t7688;
  double t8201;
  double t8215;
  double t8222;
  double t7932;
  double t8188;
  double t8315;
  double t8316;
  double t8442;
  double t8614;
  double t8617;
  double t8654;
  double t9576;
  double t9640;
  double t9642;
  double t9754;
  double t9764;
  double t9767;
  double t8236;
  double t8237;
  double t8238;
  double t8496;
  double t8516;
  double t8517;
  double t8539;
  double t8604;
  double t8656;
  double t8657;
  double t8658;
  double t8659;
  double t8660;
  double t8697;
  double t9649;
  double t9735;
  double t9740;
  double t9741;
  double t9744;
  double t9750;
  double t9807;
  double t9812;
  double t9817;
  double t9818;
  double t9955;
  double t11511;
  double t13411;
  double t13416;
  double t13417;
  double t13421;
  double t13424;
  double t13549;
  double t13556;
  double t13558;
  double t13573;
  double t13582;
  double t13578;
  double t13583;
  double t13584;
  double t13586;
  double t13587;
  double t13588;
  double t13593;
  double t13644;
  double t13645;
  double t13646;
  double t13673;
  double t13591;
  double t13595;
  double t13663;
  double t13666;
  double t13671;
  double t13675;
  double t13685;
  double t13686;
  double t13687;
  double t13585;
  double t13693;
  double t13694;
  double t13695;
  double t13455;
  double t13456;
  double t13458;
  double t13459;
  double t13460;
  double t13461;
  double t13560;
  double t13565;
  double t13567;
  double t13569;
  double t13570;
  double t13571;
  double t13691;
  double t13692;
  double t13701;
  double t13709;
  double t13710;
  double t13711;
  double t13714;
  double t13715;
  double t13722;
  double t13723;
  double t13726;
  double t13727;
  double t13278;
  double t13312;
  double t13407;
  double t13408;
  double t13589;
  double t13590;
  double t13678;
  double t13682;
  double t13732;
  double t13737;
  double t13750;
  double t13751;
  double t13764;
  double t13765;
  double t13766;
  double t13768;
  double t13769;
  double t13773;
  double t13774;
  double t13775;
  double t13777;
  double t13778;
  double t13779;
  double t13783;
  double t13784;
  double t13785;
  double t13776;
  double t13780;
  double t13781;
  double t13782;
  double t13787;
  double t13788;
  double t13792;
  double t13793;
  double t13794;
  double t13795;
  double t13804;
  double t13805;
  double t13797;
  double t13807;
  double t13808;
  double t13799;
  double t13758;
  double t13759;
  double t13760;
  double t13761;
  double t13762;
  double t13763;
  double t13827;
  double t13828;
  double t13829;
  double t13830;
  double t13831;
  double t13832;
  double t13833;
  double t13834;
  double t13836;
  double t13837;
  double t13838;
  double t13821;
  double t13822;
  double t13823;
  double t13824;
  double t13825;
  double t13826;
  double t13835;
  double t13839;
  double t13840;
  double t13842;
  double t13843;
  double t13844;
  double t13849;
  double t13850;
  double t13851;
  double t13848;
  double t13853;
  double t13854;
  double t13858;
  double t13867;
  double t13868;
  double t13860;
  double t13870;
  double t13871;
  double t13862;
  double t13883;
  double t13889;
  double t13890;
  double t13891;
  double t13884;
  double t13885;
  double t13886;
  double t13887;
  double t13895;
  double t13896;
  double t13916;
  double t13922;
  double t13923;
  double t13924;
  double t13917;
  double t13918;
  double t13919;
  double t13920;
  double t13928;
  double t13929;
  t3940 = Cos(var1[3]);
  t1804 = Cos(var1[4]);
  t3607 = Sin(var1[3]);
  t4042 = Sin(var1[4]);
  t1744 = Sin(var1[2]);
  t7973 = Cos(var1[2]);
  t7974 = t3940*t1804;
  t8049 = -1.*t3607*t4042;
  t8056 = t7974 + t8049;
  t8113 = t7973*t8056;
  t3915 = -1.*t1804*t3607;
  t4054 = -1.*t3940*t4042;
  t7688 = t3915 + t4054;
  t8201 = t1804*t3607;
  t8215 = t3940*t4042;
  t8222 = t8201 + t8215;
  t7932 = t1744*t7688;
  t8188 = t7932 + t8113;
  t8315 = t7973*t7688;
  t8316 = -1.*t1744*t8056;
  t8442 = t8315 + t8316;
  t8614 = -1.*t3940*t1804;
  t8617 = t3607*t4042;
  t8654 = t8614 + t8617;
  t9576 = -1.*t3940*t1744;
  t9640 = -1.*t7973*t3607;
  t9642 = t9576 + t9640;
  t9754 = t7973*t3940;
  t9764 = -1.*t1744*t3607;
  t9767 = t9754 + t9764;
  t8236 = -1.*t1744*t8222;
  t8237 = t8236 + t8113;
  t8238 = 3.2*t8188*t8237;
  t8496 = t7973*t8222;
  t8516 = t1744*t8056;
  t8517 = t8496 + t8516;
  t8539 = 3.2*t8442*t8517;
  t8604 = -1.*t1744*t7688;
  t8656 = t7973*t8654;
  t8657 = t8604 + t8656;
  t8658 = 3.2*t8188*t8657;
  t8659 = t1744*t8654;
  t8660 = t8315 + t8659;
  t8697 = 3.2*t8442*t8660;
  t9649 = Power(t9642,2);
  t9735 = 6.8*t9649;
  t9740 = t3940*t1744;
  t9741 = t7973*t3607;
  t9744 = t9740 + t9741;
  t9750 = 6.8*t9642*t9744;
  t9807 = Power(t9767,2);
  t9812 = 6.8*t9807;
  t9817 = -1.*t7973*t3940;
  t9818 = t1744*t3607;
  t9955 = t9817 + t9818;
  t11511 = 6.8*t9767*t9955;
  t13411 = Cos(var1[5]);
  t13416 = -1.*t13411*t1744;
  t13417 = Sin(var1[5]);
  t13421 = -1.*t7973*t13417;
  t13424 = t13416 + t13421;
  t13549 = t7973*t13411;
  t13556 = -1.*t1744*t13417;
  t13558 = t13549 + t13556;
  t13573 = Cos(var1[6]);
  t13582 = Sin(var1[6]);
  t13578 = -1.*t13573*t13417;
  t13583 = -1.*t13411*t13582;
  t13584 = t13578 + t13583;
  t13586 = t13411*t13573;
  t13587 = -1.*t13417*t13582;
  t13588 = t13586 + t13587;
  t13593 = t7973*t13588;
  t13644 = t13573*t13417;
  t13645 = t13411*t13582;
  t13646 = t13644 + t13645;
  t13673 = -1.*t1744*t13588;
  t13591 = t1744*t13584;
  t13595 = t13591 + t13593;
  t13663 = -1.*t1744*t13646;
  t13666 = t13663 + t13593;
  t13671 = t7973*t13584;
  t13675 = t13671 + t13673;
  t13685 = t7973*t13646;
  t13686 = t1744*t13588;
  t13687 = t13685 + t13686;
  t13585 = -1.*t1744*t13584;
  t13693 = -1.*t13411*t13573;
  t13694 = t13417*t13582;
  t13695 = t13693 + t13694;
  t13455 = Power(t13424,2);
  t13456 = 6.8*t13455;
  t13458 = t13411*t1744;
  t13459 = t7973*t13417;
  t13460 = t13458 + t13459;
  t13461 = 6.8*t13424*t13460;
  t13560 = Power(t13558,2);
  t13565 = 6.8*t13560;
  t13567 = -1.*t7973*t13411;
  t13569 = t1744*t13417;
  t13570 = t13567 + t13569;
  t13571 = 6.8*t13558*t13570;
  t13691 = 3.2*t13595*t13666;
  t13692 = 3.2*t13675*t13687;
  t13701 = t7973*t13695;
  t13709 = t13585 + t13701;
  t13710 = 3.2*t13595*t13709;
  t13711 = t1744*t13695;
  t13714 = t13671 + t13711;
  t13715 = 3.2*t13675*t13714;
  t13722 = 6.4*t8237*t8442;
  t13723 = 6.4*t8442*t8657;
  t13726 = 13.6*t9642*t9767;
  t13727 = 13.6*t9642*t9955;
  t13278 = -1.*t7973*t8056;
  t13312 = t8604 + t13278;
  t13407 = -1.*t7973*t8222;
  t13408 = t13407 + t8316;
  t13589 = -1.*t7973*t13588;
  t13590 = t13585 + t13589;
  t13678 = -1.*t7973*t13646;
  t13682 = t13678 + t13673;
  t13732 = 13.6*t13424*t13558;
  t13737 = 13.6*t13424*t13570;
  t13750 = 6.4*t13666*t13675;
  t13751 = 6.4*t13675*t13709;
  t13764 = -1.*t1804;
  t13765 = 1. + t13764;
  t13766 = 0.4*t13765;
  t13768 = 0.64*t1804;
  t13769 = t13766 + t13768;
  t13773 = t13769*t3607;
  t13774 = 0.24*t3940*t4042;
  t13775 = t13773 + t13774;
  t13777 = t3940*t13769;
  t13778 = -0.24*t3607*t4042;
  t13779 = t13777 + t13778;
  t13783 = -1.*t13769*t3607;
  t13784 = -0.24*t3940*t4042;
  t13785 = t13783 + t13784;
  t13776 = -1.*t13775*t8056;
  t13780 = -1.*t7688*t13779;
  t13781 = t13776 + t13780;
  t13782 = 3.2*t8442*t13781;
  t13787 = t13775*t8056;
  t13788 = t7688*t13779;
  t13792 = t13775*t8222;
  t13793 = t8056*t13779;
  t13794 = t13792 + t13793;
  t13795 = 3.2*t13794*t8657;
  t13804 = -0.24*t1804*t3607;
  t13805 = t13804 + t13784;
  t13797 = -1.*t7688*t13775;
  t13807 = 0.24*t3940*t1804;
  t13808 = t13807 + t13778;
  t13799 = -1.*t13779*t8654;
  t13758 = Power(t3940,2);
  t13759 = 0.11*t13758;
  t13760 = Power(t3607,2);
  t13761 = 0.11*t13760;
  t13762 = t13759 + t13761;
  t13763 = 6.8*t9955*t13762;
  t13827 = -1.*t13573;
  t13828 = 1. + t13827;
  t13829 = 0.4*t13828;
  t13830 = 0.64*t13573;
  t13831 = t13829 + t13830;
  t13832 = t13831*t13417;
  t13833 = 0.24*t13411*t13582;
  t13834 = t13832 + t13833;
  t13836 = t13411*t13831;
  t13837 = -0.24*t13417*t13582;
  t13838 = t13836 + t13837;
  t13821 = Power(t13411,2);
  t13822 = 0.11*t13821;
  t13823 = Power(t13417,2);
  t13824 = 0.11*t13823;
  t13825 = t13822 + t13824;
  t13826 = 6.8*t13570*t13825;
  t13835 = -1.*t13834*t13588;
  t13839 = -1.*t13584*t13838;
  t13840 = t13835 + t13839;
  t13842 = t13834*t13646;
  t13843 = t13588*t13838;
  t13844 = t13842 + t13843;
  t13849 = -1.*t13831*t13417;
  t13850 = -0.24*t13411*t13582;
  t13851 = t13849 + t13850;
  t13848 = 3.2*t13675*t13840;
  t13853 = t13834*t13588;
  t13854 = t13584*t13838;
  t13858 = 3.2*t13844*t13709;
  t13867 = -0.24*t13573*t13417;
  t13868 = t13867 + t13850;
  t13860 = -1.*t13584*t13834;
  t13870 = 0.24*t13411*t13573;
  t13871 = t13870 + t13837;
  t13862 = -1.*t13838*t13695;
  t13883 = 0.748*t9955;
  t13889 = t13769*t4042;
  t13890 = -0.24*t1804*t4042;
  t13891 = t13889 + t13890;
  t13884 = t13769*t1804;
  t13885 = Power(t4042,2);
  t13886 = 0.24*t13885;
  t13887 = t13884 + t13886;
  t13895 = 3.2*t13891*t8442;
  t13896 = 3.2*t13887*t8657;
  t13916 = 0.748*t13570;
  t13922 = t13831*t13582;
  t13923 = -0.24*t13573*t13582;
  t13924 = t13922 + t13923;
  t13917 = t13831*t13573;
  t13918 = Power(t13582,2);
  t13919 = 0.24*t13918;
  t13920 = t13917 + t13919;
  t13928 = 3.2*t13924*t13675;
  t13929 = 3.2*t13920*t13709;
  p_output1[0]=var2[1]*(-0.5*(t11511 + t13456 + t13461 + t13565 + t13571 + 3.2*t13590*t13595 + 3.2*Power(t13666,2) + 3.2*Power(t13675,2) + 3.2*t13682*t13687 + 3.2*t13312*t8188 + 3.2*Power(t8237,2) + 3.2*Power(t8442,2) + 3.2*t13408*t8517 + t9735 + t9750 + t9812)*var2[2] - 0.5*(t11511 + t8238 + t8539 + t8658 + t8697 + t9735 + t9750 + t9812)*var2[3] - 0.5*(t8238 + t8539 + t8658 + t8697)*var2[4] - 0.5*(t13456 + t13461 + t13565 + t13571 + t13691 + t13692 + t13710 + t13715)*var2[5] - 0.5*(t13691 + t13692 + t13710 + t13715)*var2[6]);
  p_output1[1]=var2[1]*(-0.5*(6.4*t13590*t13675 + 6.4*t13666*t13682 + t13726 + t13727 + t13732 + t13737 + 6.4*t13408*t8237 + 6.4*t13312*t8442)*var2[2] - 0.5*(t13722 + t13723 + t13726 + t13727)*var2[3] - 0.5*(t13722 + t13723)*var2[4] - 0.5*(t13732 + t13737 + t13750 + t13751)*var2[5] - 0.5*(t13750 + t13751)*var2[6]);
  p_output1[2]=var2[1]*(-0.5*(t13763 + 3.2*t13408*t13781 + 3.2*t13312*t13794 + t13826 + 3.2*t13682*t13840 + 3.2*t13590*t13844 - 2.88*t7973)*var2[2] - 0.5*(t13763 + t13782 + t13795 + 3.2*(t13797 + t13799 - 1.*t13785*t7688 - 1.*t13779*t8056)*t8237 + 3.2*(t13787 + t13788 + t13785*t8056 + t13779*t8222)*t8442)*var2[3] - 0.5*(t13782 + t13795 + 3.2*(t13797 + t13799 - 1.*t13805*t7688 - 1.*t13808*t8056)*t8237 + 3.2*(t13787 + t13788 + t13805*t8056 + t13808*t8222)*t8442)*var2[4] - 0.5*(t13826 + t13848 + 3.2*t13675*(t13646*t13838 + t13588*t13851 + t13853 + t13854) + t13858 + 3.2*t13666*(-1.*t13588*t13838 - 1.*t13584*t13851 + t13860 + t13862))*var2[5] - 0.5*(t13848 + t13858 + 3.2*t13666*(t13860 + t13862 - 1.*t13584*t13868 - 1.*t13588*t13871) + 3.2*t13675*(t13853 + t13854 + t13588*t13868 + t13646*t13871))*var2[6]);
  p_output1[3]=var2[1]*(-0.5*(t13883 + 3.2*t13312*t13887 + 3.2*t13408*t13891)*var2[2] - 0.5*(t13883 + t13895 + t13896)*var2[3] - 0.5*(t13895 + t13896 + 3.2*(t13884 - 0.24*Power(t1804,2))*t8237 + 3.2*(-1.*t13769*t4042 + 0.24*t1804*t4042)*t8442)*var2[4]);
  p_output1[4]=var2[1]*(-0.384*t13312*var2[2] - 0.384*t8657*var2[3] - 0.384*t8657*var2[4]);
  p_output1[5]=var2[1]*(-0.5*(t13916 + 3.2*t13590*t13920 + 3.2*t13682*t13924)*var2[2] - 0.5*(t13916 + t13928 + t13929)*var2[5] - 0.5*(3.2*t13675*(0.24*t13573*t13582 - 1.*t13582*t13831) + 3.2*t13666*(-0.24*Power(t13573,2) + t13917) + t13928 + t13929)*var2[6]);
  p_output1[6]=var2[1]*(-0.384*t13590*var2[2] - 0.384*t13709*var2[5] - 0.384*t13709*var2[6]);
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce1_vec2_five_link_walker.hh"

namespace RightStance
{

void Ce1_vec2_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
