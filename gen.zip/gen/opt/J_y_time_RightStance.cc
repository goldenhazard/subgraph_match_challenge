/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:33:07 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2,const double *var3)
{
  double t1734;
  double t8045;
  double t17840;
  double t17847;
  double t17851;
  double t17855;
  double t17858;
  double t17865;
  double t17902;
  double t17903;
  double t17906;
  double t17907;
  double t17908;
  double t17911;
  double t17912;
  double t17915;
  double t17920;
  double t17866;
  double t17868;
  double t17904;
  double t17905;
  double t17909;
  double t17910;
  double t17913;
  double t17914;
  double t17921;
  double t17922;
  double t17942;
  double t17952;
  double t17957;
  double t17958;
  double t17974;
  double t17975;
  double t17976;
  double t17977;
  double t17978;
  double t17979;
  double t17980;
  double t17981;
  double t17982;
  double t17983;
  double t17984;
  double t17936;
  double t17937;
  double t17938;
  double t17939;
  double t17940;
  double t17941;
  double t17943;
  double t18023;
  double t18024;
  double t18025;
  double t18026;
  double t18027;
  double t18028;
  double t18029;
  double t18030;
  double t18031;
  double t18032;
  double t18033;
  double t18072;
  double t18073;
  double t18074;
  double t18075;
  double t18076;
  double t18077;
  double t18078;
  double t18079;
  double t18080;
  double t18081;
  double t18082;
  t1734 = -1.*var3[1];
  t8045 = var3[0] + t1734;
  t17840 = 1/t8045;
  t17847 = 0.5*var1[4];
  t17851 = t1734 + var1[2] + var1[3] + t17847;
  t17855 = -1.*t17840*t17851;
  t17858 = 1. + t17855;
  t17865 = Power(t17858,4);
  t17902 = Power(t8045,-2);
  t17903 = Power(t17858,3);
  t17906 = Power(t8045,-3);
  t17907 = Power(t17858,2);
  t17908 = Power(t17851,2);
  t17911 = Power(t8045,-4);
  t17912 = Power(t17851,3);
  t17915 = Power(t8045,-5);
  t17920 = Power(t17851,4);
  t17866 = 5.*var2[0]*t17840*t17865;
  t17868 = -5.*var2[4]*t17840*t17865;
  t17904 = 20.*var2[4]*t17902*t17903*t17851;
  t17905 = -20.*var2[8]*t17902*t17903*t17851;
  t17909 = 30.*var2[8]*t17906*t17907*t17908;
  t17910 = -30.*var2[12]*t17906*t17907*t17908;
  t17913 = 20.*var2[12]*t17911*t17858*t17912;
  t17914 = -20.*var2[16]*t17911*t17858*t17912;
  t17921 = 5.*var2[16]*t17915*t17920;
  t17922 = -5.*var2[20]*t17915*t17920;
  t17942 = Power(t17851,5);
  t17952 = Power(t8045,-6);
  t17957 = -1.*t17902*t17851;
  t17958 = t17840 + t17957;
  t17974 = 5.*var2[1]*t17840*t17865;
  t17975 = -5.*var2[5]*t17840*t17865;
  t17976 = 20.*var2[5]*t17902*t17903*t17851;
  t17977 = -20.*var2[9]*t17902*t17903*t17851;
  t17978 = 30.*var2[9]*t17906*t17907*t17908;
  t17979 = -30.*var2[13]*t17906*t17907*t17908;
  t17980 = 20.*var2[13]*t17911*t17858*t17912;
  t17981 = -20.*var2[17]*t17911*t17858*t17912;
  t17982 = 5.*var2[17]*t17915*t17920;
  t17983 = -5.*var2[21]*t17915*t17920;
  t17984 = t17974 + t17975 + t17976 + t17977 + t17978 + t17979 + t17980 + t17981 + t17982 + t17983;
  t17936 = Power(t17858,5);
  t17937 = -1.*t17936;
  t17938 = -5.*t17840*t17865*t17851;
  t17939 = -10.*t17902*t17903*t17908;
  t17940 = -10.*t17906*t17907*t17912;
  t17941 = -5.*t17911*t17858*t17920;
  t17943 = -1.*t17915*t17942;
  t18023 = 5.*var2[2]*t17840*t17865;
  t18024 = -5.*var2[6]*t17840*t17865;
  t18025 = 20.*var2[6]*t17902*t17903*t17851;
  t18026 = -20.*var2[10]*t17902*t17903*t17851;
  t18027 = 30.*var2[10]*t17906*t17907*t17908;
  t18028 = -30.*var2[14]*t17906*t17907*t17908;
  t18029 = 20.*var2[14]*t17911*t17858*t17912;
  t18030 = -20.*var2[18]*t17911*t17858*t17912;
  t18031 = 5.*var2[18]*t17915*t17920;
  t18032 = -5.*var2[22]*t17915*t17920;
  t18033 = t18023 + t18024 + t18025 + t18026 + t18027 + t18028 + t18029 + t18030 + t18031 + t18032;
  t18072 = 5.*var2[3]*t17840*t17865;
  t18073 = -5.*var2[7]*t17840*t17865;
  t18074 = 20.*var2[7]*t17902*t17903*t17851;
  t18075 = -20.*var2[11]*t17902*t17903*t17851;
  t18076 = 30.*var2[11]*t17906*t17907*t17908;
  t18077 = -30.*var2[15]*t17906*t17907*t17908;
  t18078 = 20.*var2[15]*t17911*t17858*t17912;
  t18079 = -20.*var2[19]*t17911*t17858*t17912;
  t18080 = 5.*var2[19]*t17915*t17920;
  t18081 = -5.*var2[23]*t17915*t17920;
  t18082 = t18072 + t18073 + t18074 + t18075 + t18076 + t18077 + t18078 + t18079 + t18080 + t18081;
  p_output1[0]=t17866 + t17868 + t17904 + t17905 + t17909 + t17910 + t17913 + t17914 + t17921 + t17922;
  p_output1[1]=1. + t17866 + t17868 + t17904 + t17905 + t17909 + t17910 + t17913 + t17914 + t17921 + t17922;
  p_output1[2]=2.5*t17840*t17865*var2[0] - 2.5*t17840*t17865*var2[4] + 10.*t17851*t17902*t17903*var2[4] - 10.*t17851*t17902*t17903*var2[8] + 15.*t17906*t17907*t17908*var2[8] - 15.*t17906*t17907*t17908*var2[12] + 10.*t17858*t17911*t17912*var2[12] - 10.*t17858*t17911*t17912*var2[16] + 2.5*t17915*t17920*var2[16] - 2.5*t17915*t17920*var2[20];
  p_output1[3]=t17937;
  p_output1[4]=t17938;
  p_output1[5]=t17939;
  p_output1[6]=t17940;
  p_output1[7]=t17941;
  p_output1[8]=t17943;
  p_output1[9]=-5.*t17851*t17865*t17902*var2[0] + 5.*t17851*t17865*t17902*var2[4] - 20.*t17903*t17906*t17908*var2[4] + 20.*t17903*t17906*t17908*var2[8] - 30.*t17907*t17911*t17912*var2[8] + 30.*t17907*t17911*t17912*var2[12] - 20.*t17858*t17915*t17920*var2[12] + 20.*t17858*t17915*t17920*var2[16] - 5.*t17942*t17952*var2[16] + 5.*t17942*t17952*var2[20];
  p_output1[10]=-5.*t17865*t17958*var2[0] + 5.*t17840*t17865*var2[4] - 5.*t17851*t17865*t17902*var2[4] - 20.*t17840*t17851*t17903*t17958*var2[4] + 20.*t17851*t17902*t17903*var2[8] - 20.*t17903*t17906*t17908*var2[8] - 30.*t17902*t17907*t17908*t17958*var2[8] + 30.*t17906*t17907*t17908*var2[12] - 30.*t17907*t17911*t17912*var2[12] - 20.*t17858*t17906*t17912*t17958*var2[12] + 20.*t17858*t17911*t17912*var2[16] - 20.*t17858*t17915*t17920*var2[16] - 5.*t17911*t17920*t17958*var2[16] + 5.*t17915*t17920*var2[20] - 5.*t17942*t17952*var2[20];
  p_output1[11]=t17984;
  p_output1[12]=t17984;
  p_output1[13]=1. + 2.5*t17840*t17865*var2[1] - 2.5*t17840*t17865*var2[5] + 10.*t17851*t17902*t17903*var2[5] - 10.*t17851*t17902*t17903*var2[9] + 15.*t17906*t17907*t17908*var2[9] - 15.*t17906*t17907*t17908*var2[13] + 10.*t17858*t17911*t17912*var2[13] - 10.*t17858*t17911*t17912*var2[17] + 2.5*t17915*t17920*var2[17] - 2.5*t17915*t17920*var2[21];
  p_output1[14]=t17937;
  p_output1[15]=t17938;
  p_output1[16]=t17939;
  p_output1[17]=t17940;
  p_output1[18]=t17941;
  p_output1[19]=t17943;
  p_output1[20]=-5.*t17851*t17865*t17902*var2[1] + 5.*t17851*t17865*t17902*var2[5] - 20.*t17903*t17906*t17908*var2[5] + 20.*t17903*t17906*t17908*var2[9] - 30.*t17907*t17911*t17912*var2[9] + 30.*t17907*t17911*t17912*var2[13] - 20.*t17858*t17915*t17920*var2[13] + 20.*t17858*t17915*t17920*var2[17] - 5.*t17942*t17952*var2[17] + 5.*t17942*t17952*var2[21];
  p_output1[21]=-5.*t17865*t17958*var2[1] + 5.*t17840*t17865*var2[5] - 5.*t17851*t17865*t17902*var2[5] - 20.*t17840*t17851*t17903*t17958*var2[5] + 20.*t17851*t17902*t17903*var2[9] - 20.*t17903*t17906*t17908*var2[9] - 30.*t17902*t17907*t17908*t17958*var2[9] + 30.*t17906*t17907*t17908*var2[13] - 30.*t17907*t17911*t17912*var2[13] - 20.*t17858*t17906*t17912*t17958*var2[13] + 20.*t17858*t17911*t17912*var2[17] - 20.*t17858*t17915*t17920*var2[17] - 5.*t17911*t17920*t17958*var2[17] + 5.*t17915*t17920*var2[21] - 5.*t17942*t17952*var2[21];
  p_output1[22]=t18033;
  p_output1[23]=t18033;
  p_output1[24]=2.5*t17840*t17865*var2[2] - 2.5*t17840*t17865*var2[6] + 10.*t17851*t17902*t17903*var2[6] - 10.*t17851*t17902*t17903*var2[10] + 15.*t17906*t17907*t17908*var2[10] - 15.*t17906*t17907*t17908*var2[14] + 10.*t17858*t17911*t17912*var2[14] - 10.*t17858*t17911*t17912*var2[18] + 2.5*t17915*t17920*var2[18] - 2.5*t17915*t17920*var2[22];
  p_output1[25]=1.;
  p_output1[26]=t17937;
  p_output1[27]=t17938;
  p_output1[28]=t17939;
  p_output1[29]=t17940;
  p_output1[30]=t17941;
  p_output1[31]=t17943;
  p_output1[32]=-5.*t17851*t17865*t17902*var2[2] + 5.*t17851*t17865*t17902*var2[6] - 20.*t17903*t17906*t17908*var2[6] + 20.*t17903*t17906*t17908*var2[10] - 30.*t17907*t17911*t17912*var2[10] + 30.*t17907*t17911*t17912*var2[14] - 20.*t17858*t17915*t17920*var2[14] + 20.*t17858*t17915*t17920*var2[18] - 5.*t17942*t17952*var2[18] + 5.*t17942*t17952*var2[22];
  p_output1[33]=-5.*t17865*t17958*var2[2] + 5.*t17840*t17865*var2[6] - 5.*t17851*t17865*t17902*var2[6] - 20.*t17840*t17851*t17903*t17958*var2[6] + 20.*t17851*t17902*t17903*var2[10] - 20.*t17903*t17906*t17908*var2[10] - 30.*t17902*t17907*t17908*t17958*var2[10] + 30.*t17906*t17907*t17908*var2[14] - 30.*t17907*t17911*t17912*var2[14] - 20.*t17858*t17906*t17912*t17958*var2[14] + 20.*t17858*t17911*t17912*var2[18] - 20.*t17858*t17915*t17920*var2[18] - 5.*t17911*t17920*t17958*var2[18] + 5.*t17915*t17920*var2[22] - 5.*t17942*t17952*var2[22];
  p_output1[34]=t18082;
  p_output1[35]=t18082;
  p_output1[36]=2.5*t17840*t17865*var2[3] - 2.5*t17840*t17865*var2[7] + 10.*t17851*t17902*t17903*var2[7] - 10.*t17851*t17902*t17903*var2[11] + 15.*t17906*t17907*t17908*var2[11] - 15.*t17906*t17907*t17908*var2[15] + 10.*t17858*t17911*t17912*var2[15] - 10.*t17858*t17911*t17912*var2[19] + 2.5*t17915*t17920*var2[19] - 2.5*t17915*t17920*var2[23];
  p_output1[37]=1.;
  p_output1[38]=t17937;
  p_output1[39]=t17938;
  p_output1[40]=t17939;
  p_output1[41]=t17940;
  p_output1[42]=t17941;
  p_output1[43]=t17943;
  p_output1[44]=-5.*t17851*t17865*t17902*var2[3] + 5.*t17851*t17865*t17902*var2[7] - 20.*t17903*t17906*t17908*var2[7] + 20.*t17903*t17906*t17908*var2[11] - 30.*t17907*t17911*t17912*var2[11] + 30.*t17907*t17911*t17912*var2[15] - 20.*t17858*t17915*t17920*var2[15] + 20.*t17858*t17915*t17920*var2[19] - 5.*t17942*t17952*var2[19] + 5.*t17942*t17952*var2[23];
  p_output1[45]=-5.*t17865*t17958*var2[3] + 5.*t17840*t17865*var2[7] - 5.*t17851*t17865*t17902*var2[7] - 20.*t17840*t17851*t17903*t17958*var2[7] + 20.*t17851*t17902*t17903*var2[11] - 20.*t17903*t17906*t17908*var2[11] - 30.*t17902*t17907*t17908*t17958*var2[11] + 30.*t17906*t17907*t17908*var2[15] - 30.*t17907*t17911*t17912*var2[15] - 20.*t17858*t17906*t17912*t17958*var2[15] + 20.*t17858*t17911*t17912*var2[19] - 20.*t17858*t17915*t17920*var2[19] - 5.*t17911*t17920*t17958*var2[19] + 5.*t17915*t17920*var2[23] - 5.*t17942*t17952*var2[23];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2,*var3;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 3)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Three input(s) required (var1,var2,var3).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 24 && ncols == 1) && 
      !(mrows == 1 && ncols == 24))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }
  mrows = mxGetM(prhs[2]);
  ncols = mxGetN(prhs[2]);
  if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) ||
    ( !(mrows == 2 && ncols == 1) && 
      !(mrows == 1 && ncols == 2))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var3 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
  var3 = mxGetPr(prhs[2]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 46, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2,var3);


}

#else // MATLAB_MEX_FILE

#include "J_y_time_RightStance.hh"

namespace RightStance
{

void J_y_time_RightStance_raw(double *p_output1, const double *var1,const double *var2,const double *var3)
{
  // Call Subroutines
  output1(p_output1, var1, var2, var3);

}

}

#endif // MATLAB_MEX_FILE
