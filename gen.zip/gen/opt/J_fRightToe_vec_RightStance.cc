/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:32:38 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t10203;
  double t10309;
  double t10202;
  double t10451;
  double t10032;
  double t10226;
  double t11133;
  double t17357;
  double t17380;
  double t17393;
  double t17395;
  double t17457;
  double t10068;
  double t10078;
  double t17481;
  double t17493;
  double t17496;
  double t17372;
  double t17461;
  double t17464;
  double t17465;
  double t17469;
  double t17470;
  double t17479;
  double t17480;
  double t17500;
  double t17503;
  double t17504;
  double t17508;
  double t17509;
  double t17510;
  double t17511;
  double t17512;
  double t17515;
  double t17532;
  double t17533;
  double t17534;
  double t17516;
  double t17520;
  double t17521;
  double t17527;
  double t17528;
  double t17529;
  double t17530;
  double t17531;
  double t17535;
  double t17536;
  double t17537;
  double t17538;
  double t17539;
  double t17540;
  double t17541;
  double t17542;
  double t17543;
  double t17544;
  double t17545;
  double t17546;
  double t17547;
  double t17548;
  t10203 = Cos(var1[3]);
  t10309 = Sin(var1[2]);
  t10202 = Cos(var1[2]);
  t10451 = Sin(var1[3]);
  t10032 = Cos(var1[4]);
  t10226 = -1.*t10202*t10203;
  t11133 = t10309*t10451;
  t17357 = t10226 + t11133;
  t17380 = t10203*t10309;
  t17393 = t10202*t10451;
  t17395 = t17380 + t17393;
  t17457 = Sin(var1[4]);
  t10068 = -1.*t10032;
  t10078 = 1. + t10068;
  t17481 = -1.*t10203*t10309;
  t17493 = -1.*t10202*t10451;
  t17496 = t17481 + t17493;
  t17372 = 0.4*t10078*t17357;
  t17461 = -0.4*t17395*t17457;
  t17464 = t10032*t17357;
  t17465 = t17395*t17457;
  t17469 = t17464 + t17465;
  t17470 = 0.8*t17469;
  t17479 = t17372 + t17461 + t17470;
  t17480 = var2[2]*t17479;
  t17500 = 0.4*t10078*t17496;
  t17503 = -0.4*t17357*t17457;
  t17504 = t10032*t17496;
  t17508 = t17357*t17457;
  t17509 = t17504 + t17508;
  t17510 = 0.8*t17509;
  t17511 = t17500 + t17503 + t17510;
  t17512 = var2[0]*t17511;
  t17515 = t17480 + t17512;
  t17532 = t10202*t10203;
  t17533 = -1.*t10309*t10451;
  t17534 = t17532 + t17533;
  t17516 = -0.4*t10032*t17357;
  t17520 = 0.4*t17496*t17457;
  t17521 = -1.*t17496*t17457;
  t17527 = t17464 + t17521;
  t17528 = 0.8*t17527;
  t17529 = t17516 + t17520 + t17528;
  t17530 = var2[2]*t17529;
  t17531 = -0.4*t10032*t17496;
  t17535 = 0.4*t17534*t17457;
  t17536 = -1.*t17534*t17457;
  t17537 = t17504 + t17536;
  t17538 = 0.8*t17537;
  t17539 = t17531 + t17535 + t17538;
  t17540 = var2[0]*t17539;
  t17541 = t17530 + t17540;
  t17542 = 0.4*t10078*t17534;
  t17543 = -0.4*t17496*t17457;
  t17544 = t10032*t17534;
  t17545 = t17496*t17457;
  t17546 = t17544 + t17545;
  t17547 = 0.8*t17546;
  t17548 = t17542 + t17543 + t17547;
  p_output1[0]=1.;
  p_output1[1]=1.;
  p_output1[2]=t17515;
  p_output1[3]=t17515;
  p_output1[4]=t17541;
  p_output1[5]=t17548;
  p_output1[6]=t17511;
  p_output1[7]=t17515;
  p_output1[8]=t17515;
  p_output1[9]=t17541;
  p_output1[10]=t17548;
  p_output1[11]=t17511;
  p_output1[12]=t17541;
  p_output1[13]=t17541;
  p_output1[14]=(0.4*t10032*t17395 + t17535 + 0.8*(-1.*t10032*t17395 + t17536))*var2[0] + (t17520 + 0.4*t10032*t17534 + 0.8*(t17521 - 1.*t10032*t17534))*var2[2];
  p_output1[15]=0.4*t17395*t17457 - 0.4*t10032*t17534 + 0.8*(-1.*t17395*t17457 + t17544);
  p_output1[16]=t17539;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 3 && ncols == 1) && 
      !(mrows == 1 && ncols == 3))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 17, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_fRightToe_vec_RightStance.hh"

namespace RightStance
{

void J_fRightToe_vec_RightStance_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
