/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:50 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t3698;
  double t1006;
  double t1681;
  double t3979;
  double t8119;
  double t1005;
  double t1806;
  double t7710;
  double t8044;
  double t10073;
  double t10074;
  double t10095;
  double t10115;
  double t10529;
  double t8050;
  double t8120;
  double t8402;
  double t9397;
  double t9634;
  double t9636;
  double t11059;
  double t11131;
  double t11159;
  double t10904;
  double t10906;
  double t10907;
  double t9800;
  double t9805;
  double t10053;
  double t11168;
  double t11176;
  double t11194;
  double t10819;
  double t10859;
  double t10860;
  double t10817;
  double t10861;
  double t10874;
  double t11740;
  double t11643;
  double t11673;
  double t11685;
  double t11800;
  double t11808;
  double t11824;
  double t11864;
  double t11725;
  double t11763;
  double t11923;
  double t11931;
  double t11957;
  double t12094;
  double t12157;
  double t13116;
  double t13117;
  double t13120;
  double t13186;
  double t13212;
  double t13295;
  double t13328;
  double t13346;
  double t13366;
  double t10061;
  double t10876;
  double t10890;
  double t10892;
  double t10895;
  double t14727;
  double t14752;
  double t10714;
  double t10786;
  double t10814;
  double t11162;
  double t11409;
  double t11466;
  double t11548;
  double t12030;
  double t12288;
  double t12295;
  double t12330;
  double t12408;
  double t12430;
  double t12450;
  double t12956;
  double t13012;
  double t13018;
  double t13039;
  double t13054;
  double t13088;
  double t13735;
  double t14519;
  double t14520;
  double t13139;
  double t13302;
  double t13326;
  double t13437;
  double t13438;
  double t13462;
  double t13478;
  double t13489;
  double t14609;
  double t14612;
  double t14613;
  double t14614;
  double t14667;
  double t14963;
  double t14964;
  double t14965;
  double t14756;
  double t14764;
  double t14790;
  double t14806;
  double t14825;
  double t14826;
  double t14827;
  double t14847;
  double t14892;
  double t14902;
  double t14909;
  double t14910;
  double t14926;
  double t14930;
  double t14935;
  double t14945;
  double t14955;
  double t14956;
  double t15042;
  double t15046;
  double t14960;
  double t15048;
  double t15056;
  double t14968;
  double t14981;
  double t15066;
  double t15067;
  double t14993;
  double t15089;
  double t15090;
  double t15091;
  double t15092;
  double t15093;
  double t15095;
  double t15096;
  double t15097;
  double t15098;
  double t15099;
  double t15100;
  double t15101;
  double t15102;
  double t15103;
  double t15105;
  double t15106;
  double t15107;
  double t15112;
  double t15113;
  double t15114;
  double t12028;
  double t12065;
  double t11812;
  double t11817;
  double t11789;
  double t11822;
  double t11972;
  double t11989;
  double t12091;
  double t12168;
  double t12195;
  double t15128;
  double t15133;
  double t15138;
  double t14903;
  double t15146;
  double t14958;
  double t14959;
  double t14966;
  double t14967;
  double t14969;
  double t14980;
  double t14982;
  double t14987;
  double t14992;
  double t14994;
  double t15155;
  double t15008;
  double t15009;
  double t15013;
  double t15156;
  double t15015;
  double t15020;
  double t15025;
  double t15157;
  double t15160;
  double t15161;
  double t15162;
  double t15163;
  double t15164;
  double t15165;
  double t15034;
  double t15169;
  double t15047;
  double t15057;
  double t15058;
  double t15171;
  double t15060;
  double t15065;
  double t15068;
  double t15069;
  double t15070;
  double t15071;
  double t15074;
  double t15075;
  double t15076;
  double t15078;
  double t15079;
  double t15080;
  double t15081;
  double t15082;
  double t15083;
  double t15104;
  double t13327;
  double t13617;
  double t14521;
  double t14668;
  double t14669;
  double t9794;
  double t10875;
  double t10898;
  double t10901;
  double t15196;
  double t15197;
  double t14679;
  double t15147;
  double t15148;
  double t15149;
  double t15150;
  double t15151;
  double t14957;
  double t14970;
  double t14971;
  double t15000;
  double t15001;
  double t15170;
  double t15172;
  double t15173;
  double t15174;
  double t15175;
  double t15041;
  double t15059;
  double t15072;
  double t15073;
  double t15077;
  double t15084;
  double t15085;
  double t15186;
  double t15187;
  double t15188;
  double t15189;
  double t15190;
  double t15191;
  double t15192;
  double t15115;
  double t15199;
  double t15243;
  double t15244;
  double t15245;
  double t15129;
  double t15130;
  double t15131;
  double t15158;
  double t14792;
  double t15210;
  double t15211;
  double t15212;
  double t15179;
  double t15180;
  double t15181;
  double t15014;
  double t15026;
  double t15027;
  double t15227;
  double t15228;
  double t15229;
  double t15230;
  double t15231;
  double t15117;
  double t15118;
  double t15119;
  double t15120;
  double t10903;
  double t15248;
  double t15249;
  double t15250;
  double t15281;
  double t15282;
  double t15126;
  double t15204;
  double t15256;
  t3698 = Cos(var1[3]);
  t1006 = Cos(var1[4]);
  t1681 = Sin(var1[3]);
  t3979 = Sin(var1[4]);
  t8119 = Cos(var1[2]);
  t1005 = Sin(var1[2]);
  t1806 = -1.*t1006*t1681;
  t7710 = -1.*t3698*t3979;
  t8044 = t1806 + t7710;
  t10073 = -1.*t1006;
  t10074 = 1. + t10073;
  t10095 = 0.4*t10074;
  t10115 = 0.64*t1006;
  t10529 = t10095 + t10115;
  t8050 = -1.*t1005*t8044;
  t8120 = -1.*t3698*t1006;
  t8402 = t1681*t3979;
  t9397 = t8120 + t8402;
  t9634 = t8119*t9397;
  t9636 = t8050 + t9634;
  t11059 = t8119*t3698;
  t11131 = -1.*t1005*t1681;
  t11159 = t11059 + t11131;
  t10904 = -1.*t3698*t1005;
  t10906 = -1.*t8119*t1681;
  t10907 = t10904 + t10906;
  t9800 = -1.*t8119*t3698;
  t9805 = t1005*t1681;
  t10053 = t9800 + t9805;
  t11168 = t3698*t1005;
  t11176 = t8119*t1681;
  t11194 = t11168 + t11176;
  t10819 = t3698*t1006;
  t10859 = -1.*t1681*t3979;
  t10860 = t10819 + t10859;
  t10817 = t8119*t8044;
  t10861 = -1.*t1005*t10860;
  t10874 = t10817 + t10861;
  t11740 = t8119*t10860;
  t11643 = t1006*t1681;
  t11673 = t3698*t3979;
  t11685 = t11643 + t11673;
  t11800 = t1005*t8044;
  t11808 = t11800 + t11740;
  t11824 = -1.*t8119*t10860;
  t11864 = t8050 + t11824;
  t11725 = -1.*t1005*t11685;
  t11763 = t11725 + t11740;
  t11923 = t8119*t11685;
  t11931 = t1005*t10860;
  t11957 = t11923 + t11931;
  t12094 = t1005*t9397;
  t12157 = t10817 + t12094;
  t13116 = t10529*t1681;
  t13117 = 0.24*t3698*t3979;
  t13120 = t13116 + t13117;
  t13186 = t3698*t10529;
  t13212 = -0.24*t1681*t3979;
  t13295 = t13186 + t13212;
  t13328 = -1.*t10529*t1681;
  t13346 = -0.24*t3698*t3979;
  t13366 = t13328 + t13346;
  t10061 = 0.748*t10053;
  t10876 = t10529*t1006;
  t10890 = Power(t3979,2);
  t10892 = 0.24*t10890;
  t10895 = t10876 + t10892;
  t14727 = t1005*t11685;
  t14752 = t14727 + t9634;
  t10714 = t10529*t3979;
  t10786 = -0.24*t1006*t3979;
  t10814 = t10714 + t10786;
  t11162 = 20.4*t10907*t11159;
  t11409 = 6.8*t11194*t11159;
  t11466 = 20.4*t10907*t10053;
  t11548 = 6.8*t11194*t10053;
  t12030 = -1.*t1005*t9397;
  t12288 = Power(t10907,2);
  t12295 = 13.6*t12288;
  t12330 = 13.6*t10907*t11194;
  t12408 = Power(t11159,2);
  t12430 = 13.6*t12408;
  t12450 = 13.6*t11159*t10053;
  t12956 = Power(t3698,2);
  t13012 = 0.11*t12956;
  t13018 = Power(t1681,2);
  t13039 = 0.11*t13018;
  t13054 = t13012 + t13039;
  t13088 = 6.8*t10053*t13054;
  t13735 = t13120*t11685;
  t14519 = t10860*t13295;
  t14520 = t13735 + t14519;
  t13139 = -1.*t13120*t10860;
  t13302 = -1.*t8044*t13295;
  t13326 = t13139 + t13302;
  t13437 = t13366*t10860;
  t13438 = t13120*t10860;
  t13462 = t8044*t13295;
  t13478 = t11685*t13295;
  t13489 = t13437 + t13438 + t13462 + t13478;
  t14609 = -1.*t8044*t13366;
  t14612 = -1.*t8044*t13120;
  t14613 = -1.*t10860*t13295;
  t14614 = -1.*t13295*t9397;
  t14667 = t14609 + t14612 + t14613 + t14614;
  t14963 = -1.*t3698*t10529;
  t14964 = 0.24*t1681*t3979;
  t14965 = t14963 + t14964;
  t14756 = -0.384*var2[4]*t14752;
  t14764 = 3.2*t10895*t14752;
  t14790 = 3.2*t10814*t12157;
  t14806 = 6.4*t11808*t10874;
  t14825 = 3.2*t11957*t9636;
  t14826 = 3.2*t10874*t14752;
  t14827 = t11923 + t12030;
  t14847 = 3.2*t11808*t14827;
  t14892 = 3.2*t11763*t12157;
  t14902 = 6.4*t9636*t12157;
  t14909 = Power(t11808,2);
  t14910 = 6.4*t14909;
  t14926 = 6.4*t11808*t14752;
  t14930 = 6.4*t11957*t12157;
  t14935 = Power(t12157,2);
  t14945 = 6.4*t14935;
  t14955 = 3.2*t14520*t14752;
  t14956 = 3.2*t13326*t12157;
  t15042 = -0.24*t1006*t1681;
  t15046 = t15042 + t13346;
  t14960 = -1.*t11685*t13295;
  t15048 = 0.24*t3698*t1006;
  t15056 = t15048 + t13212;
  t14968 = -1.*t13120*t9397;
  t14981 = t8044*t13120;
  t15066 = -0.24*t3698*t1006;
  t15067 = t15066 + t14964;
  t14993 = t13295*t9397;
  t15089 = 13.6*t10907*t11159;
  t15090 = 13.6*t11194*t11159;
  t15091 = 6.4*t11808*t11957;
  t15092 = 6.4*t11808*t12157;
  t15093 = t15089 + t15090 + t15091 + t15092;
  t15095 = 6.8*t12288;
  t15096 = 6.8*t10907*t11194;
  t15097 = 6.8*t12408;
  t15098 = 6.8*t11159*t10053;
  t15099 = 3.2*t11808*t11763;
  t15100 = 3.2*t10874*t11957;
  t15101 = 3.2*t11808*t9636;
  t15102 = 3.2*t10874*t12157;
  t15103 = t15095 + t15096 + t15097 + t15098 + t15099 + t15100 + t15101 + t15102;
  t15105 = 6.8*t10907*t13054;
  t15106 = 3.2*t11808*t13326;
  t15107 = 3.2*t11808*t13489;
  t15112 = 3.2*t14520*t12157;
  t15113 = 3.2*t11957*t14667;
  t15114 = t15105 + t15106 + t15107 + t15112 + t15113;
  t12028 = -1.*t8119*t8044;
  t12065 = t12028 + t12030;
  t11812 = -1.*t8119*t11685;
  t11817 = t11812 + t10861;
  t11789 = 6.4*t11763*t10874;
  t11822 = 3.2*t11808*t11817;
  t11972 = 3.2*t11864*t11957;
  t11989 = 6.4*t10874*t9636;
  t12091 = 3.2*t11808*t12065;
  t12168 = 3.2*t11864*t12157;
  t12195 = t11162 + t11409 + t11466 + t11548 + t11789 + t11822 + t11972 + t11989 + t12091 + t12168;
  t15128 = 0.748*t11194;
  t15133 = Power(t10053,2);
  t15138 = 13.6*t15133;
  t14903 = t11162 + t11409 + t11466 + t11548 + t14806 + t14825 + t14826 + t14847 + t14892 + t14902;
  t15146 = 6.8*t11194*t13054;
  t14958 = -1.*t13366*t10860;
  t14959 = -2.*t8044*t13295;
  t14966 = -1.*t8044*t14965;
  t14967 = -2.*t13366*t9397;
  t14969 = t14958 + t14959 + t14960 + t14966 + t14967 + t14968;
  t14980 = 2.*t8044*t13366;
  t14982 = t13366*t11685;
  t14987 = 2.*t10860*t13295;
  t14992 = t10860*t14965;
  t14994 = t14980 + t14981 + t14982 + t14987 + t14992 + t14993;
  t15155 = -0.384*var2[4]*t14827;
  t15008 = Power(t1006,2);
  t15009 = -0.24*t15008;
  t15013 = t10876 + t15009;
  t15156 = 3.2*t10814*t9636;
  t15015 = -1.*t10529*t3979;
  t15020 = 0.24*t1006*t3979;
  t15025 = t15015 + t15020;
  t15157 = 3.2*t10895*t14827;
  t15160 = Power(t10874,2);
  t15161 = 6.4*t15160;
  t15162 = 6.4*t11763*t9636;
  t15163 = Power(t9636,2);
  t15164 = 6.4*t15163;
  t15165 = 6.4*t10874*t14827;
  t15034 = t14806 + t14825 + t14826 + t14847 + t14892 + t14902;
  t15169 = 3.2*t13326*t9636;
  t15047 = t15046*t10860;
  t15057 = t11685*t15056;
  t15058 = t15047 + t13438 + t13462 + t15057;
  t15171 = 3.2*t14520*t14827;
  t15060 = -1.*t15046*t10860;
  t15065 = -1.*t8044*t15056;
  t15068 = -1.*t8044*t15067;
  t15069 = -1.*t13366*t9397;
  t15070 = -1.*t15046*t9397;
  t15071 = t15060 + t13302 + t14960 + t15065 + t15068 + t15069 + t15070 + t14968;
  t15074 = -1.*t8044*t15046;
  t15075 = -1.*t10860*t15056;
  t15076 = t15074 + t14612 + t15075 + t14614;
  t15078 = t8044*t13366;
  t15079 = t8044*t15046;
  t15080 = t15046*t11685;
  t15081 = t10860*t15056;
  t15082 = t10860*t15067;
  t15083 = t15078 + t15079 + t14981 + t15080 + t14519 + t15081 + t15082 + t14993;
  t15104 = -0.5*var2[3]*t15103;
  t13327 = 3.2*t10874*t13326;
  t13617 = 3.2*t10874*t13489;
  t14521 = 3.2*t14520*t9636;
  t14668 = 3.2*t11763*t14667;
  t14669 = t13088 + t13327 + t13617 + t14521 + t14668;
  t9794 = -0.384*var2[4]*t9636;
  t10875 = 3.2*t10814*t10874;
  t10898 = 3.2*t10895*t9636;
  t10901 = t10061 + t10875 + t10898;
  t15196 = 13.6*t10907*t10053;
  t15197 = t15089 + t15196 + t11789 + t11989;
  t14679 = -0.5*var2[2]*t14669;
  t15147 = 3.2*t11864*t13326;
  t15148 = 3.2*t11864*t13489;
  t15149 = 3.2*t14520*t12065;
  t15150 = 3.2*t11817*t14667;
  t15151 = t15146 + t15147 + t15148 + t15149 + t15150;
  t14957 = 6.4*t13489*t12157;
  t14970 = 3.2*t11957*t14969;
  t14971 = 6.4*t11808*t14667;
  t15000 = 3.2*t11808*t14994;
  t15001 = t13088 + t14955 + t14956 + t14957 + t14970 + t14971 + t15000;
  t15170 = 6.4*t13489*t9636;
  t15172 = 3.2*t11763*t14969;
  t15173 = 6.4*t10874*t14667;
  t15174 = 3.2*t10874*t14994;
  t15175 = t15146 + t15169 + t15170 + t15171 + t15172 + t15173 + t15174;
  t15041 = 3.2*t13489*t12157;
  t15059 = 3.2*t15058*t12157;
  t15072 = 3.2*t11957*t15071;
  t15073 = 3.2*t11808*t14667;
  t15077 = 3.2*t11808*t15076;
  t15084 = 3.2*t11808*t15083;
  t15085 = t14955 + t14956 + t15041 + t15059 + t15072 + t15073 + t15077 + t15084;
  t15186 = 3.2*t13489*t9636;
  t15187 = 3.2*t15058*t9636;
  t15188 = 3.2*t11763*t15071;
  t15189 = 3.2*t10874*t14667;
  t15190 = 3.2*t10874*t15076;
  t15191 = 3.2*t10874*t15083;
  t15192 = t15169 + t15186 + t15187 + t15171 + t15188 + t15189 + t15190 + t15191;
  t15115 = -0.5*var2[3]*t15114;
  t15199 = -0.5*var2[3]*t14669;
  t15243 = 6.4*t13489*t14520;
  t15244 = 6.4*t13326*t14667;
  t15245 = t15243 + t15244;
  t15129 = 3.2*t10814*t11864;
  t15130 = 3.2*t10895*t12065;
  t15131 = t15128 + t15129 + t15130;
  t15158 = t15128 + t15156 + t15157;
  t14792 = t10061 + t14764 + t14790;
  t15210 = 3.2*t10814*t14969;
  t15211 = 3.2*t10895*t14994;
  t15212 = t15210 + t15211;
  t15179 = 3.2*t15013*t10874;
  t15180 = 3.2*t15025*t9636;
  t15181 = t15179 + t15156 + t15180 + t15157;
  t15014 = 3.2*t15013*t11808;
  t15026 = 3.2*t15025*t12157;
  t15027 = t15014 + t14764 + t14790 + t15026;
  t15227 = 3.2*t15025*t13489;
  t15228 = 3.2*t10814*t15071;
  t15229 = 3.2*t15013*t14667;
  t15230 = 3.2*t10895*t15083;
  t15231 = t15227 + t15228 + t15229 + t15230;
  t15117 = 0.748*t10907;
  t15118 = 3.2*t10814*t11808;
  t15119 = 3.2*t10895*t12157;
  t15120 = t15117 + t15118 + t15119;
  t10903 = -0.5*var2[3]*t10901;
  t15248 = 3.2*t10895*t13489;
  t15249 = 3.2*t10814*t14667;
  t15250 = t15248 + t15249;
  t15281 = -0.384*var2[0]*t14752;
  t15282 = -0.384*var2[1]*t14827;
  t15126 = -0.384*var2[3]*t12157;
  t15204 = -0.384*var2[3]*t9636;
  t15256 = -0.384*var2[3]*t13489;
  p_output1[0]=(t10903 + t14679 + t9794 - 0.5*(6.4*t11763*t11808 + 6.4*t10874*t11957 + 6.4*t10874*t12157 + t12295 + t12330 + t12430 + t12450 + 6.4*t11808*t9636)*var2[0] - 0.5*t12195*var2[1])*var2[3];
  p_output1[1]=var2[3]*(t14756 - 0.5*(t12295 + t12330 + t12430 + t12450 + t14910 + t14926 + t14930 + t14945)*var2[0] - 0.5*t14903*var2[1] - 0.5*t15001*var2[2] - 0.5*t14792*var2[3]);
  p_output1[2]=var2[3]*(t14756 - 0.5*(t14910 + t14926 + t14930 + t14945)*var2[0] - 0.5*t15034*var2[1] - 0.5*t15085*var2[2] - 0.5*t15027*var2[3]);
  p_output1[3]=-0.5*t15093*var2[3];
  p_output1[4]=t15104;
  p_output1[5]=t15115;
  p_output1[6]=-0.5*t15093*var2[0] - 0.5*t15103*var2[1] - 0.5*t15114*var2[2] - 1.*t15120*var2[3] - 0.384*t12157*var2[4];
  p_output1[7]=t15126;
  p_output1[8]=var2[3]*(-0.5*t12195*var2[0] - 0.5*(6.4*t10874*t11817 + 6.4*t11763*t11864 + 6.4*t10874*t12065 + t12295 + t12330 + t12450 + t15138 + 6.4*t11864*t9636)*var2[1] - 0.5*t15151*var2[2] - 0.5*t15131*var2[3] - 0.384*t12065*var2[4]);
  p_output1[9]=var2[3]*(t15155 - 0.5*t14903*var2[0] - 0.5*(t12295 + t12330 + t12450 + t15138 + t15161 + t15162 + t15164 + t15165)*var2[1] - 0.5*t15175*var2[2] - 0.5*t15158*var2[3]);
  p_output1[10]=var2[3]*(t15155 - 0.5*t15034*var2[0] - 0.5*(t15161 + t15162 + t15164 + t15165)*var2[1] - 0.5*t15192*var2[2] - 0.5*t15181*var2[3]);
  p_output1[11]=t15104;
  p_output1[12]=-0.5*t15197*var2[3];
  p_output1[13]=t15199;
  p_output1[14]=t14679 + t9794 - 0.5*t15103*var2[0] - 0.5*t15197*var2[1] - 1.*t10901*var2[3];
  p_output1[15]=t15204;
  p_output1[16]=(-0.5*t14669*var2[0] - 0.5*t15151*var2[1])*var2[3];
  p_output1[17]=var2[3]*(-0.5*t15001*var2[0] - 0.5*t15175*var2[1] - 0.5*(6.4*Power(t13489,2) + 6.4*Power(t14667,2) + 6.4*t13326*t14969 + 6.4*t14520*t14994)*var2[2] - 0.5*t15212*var2[3] - 0.384*t14994*var2[4]);
  p_output1[18]=var2[3]*(-0.5*t15085*var2[0] - 0.5*t15192*var2[1] - 0.5*(6.4*t13489*t15058 + 6.4*t13326*t15071 + 6.4*t14667*t15076 + 6.4*t14520*t15083)*var2[2] - 0.5*t15231*var2[3] - 0.384*t15083*var2[4]);
  p_output1[19]=t15115;
  p_output1[20]=t15199;
  p_output1[21]=-0.5*t15245*var2[3];
  p_output1[22]=-0.5*t15114*var2[0] - 0.5*t14669*var2[1] - 0.5*t15245*var2[2] - 1.*t15250*var2[3] - 0.384*t13489*var2[4];
  p_output1[23]=t15256;
  p_output1[24]=(-0.5*t10901*var2[0] - 0.5*t15131*var2[1])*var2[3];
  p_output1[25]=(-0.5*t14792*var2[0] - 0.5*t15158*var2[1] - 0.5*t15212*var2[2])*var2[3];
  p_output1[26]=(-0.5*t15027*var2[0] - 0.5*t15181*var2[1] - 0.5*t15231*var2[2])*var2[3];
  p_output1[27]=-0.5*t15120*var2[3];
  p_output1[28]=t10903;
  p_output1[29]=-0.5*t15250*var2[3];
  p_output1[30]=-0.5*t15120*var2[0] - 0.5*t10901*var2[1] - 0.5*t15250*var2[2];
  p_output1[31]=(-0.384*t9636*var2[0] - 0.384*t12065*var2[1])*var2[3];
  p_output1[32]=(t15281 + t15282 - 0.384*t14994*var2[2])*var2[3];
  p_output1[33]=(t15281 + t15282 - 0.384*t15083*var2[2])*var2[3];
  p_output1[34]=t15126;
  p_output1[35]=t15204;
  p_output1[36]=t15256;
  p_output1[37]=-0.384*t12157*var2[0] - 0.384*t9636*var2[1] - 0.384*t13489*var2[2];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 38, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce2_vec4_five_link_walker.hh"

namespace RightStance
{

void J_Ce2_vec4_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
