/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:58 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t8661;
  double t8105;
  double t8344;
  double t8670;
  double t9535;
  double t1018;
  double t8541;
  double t8672;
  double t8685;
  double t11244;
  double t11260;
  double t11345;
  double t11413;
  double t11668;
  double t9526;
  double t9641;
  double t10056;
  double t10210;
  double t10700;
  double t10737;
  double t13627;
  double t13662;
  double t13712;
  double t12852;
  double t13101;
  double t13527;
  double t11105;
  double t11106;
  double t11136;
  double t15094;
  double t15116;
  double t15121;
  double t12146;
  double t12155;
  double t12461;
  double t12118;
  double t12546;
  double t12653;
  double t15288;
  double t15125;
  double t15207;
  double t15208;
  double t15299;
  double t15311;
  double t15336;
  double t15337;
  double t15220;
  double t15289;
  double t15338;
  double t15339;
  double t15340;
  double t15352;
  double t15353;
  double t15417;
  double t15418;
  double t15424;
  double t15426;
  double t15427;
  double t15428;
  double t15432;
  double t15433;
  double t15434;
  double t11171;
  double t12761;
  double t12764;
  double t12767;
  double t12770;
  double t15471;
  double t15472;
  double t11830;
  double t11899;
  double t12015;
  double t13713;
  double t15122;
  double t15123;
  double t15124;
  double t15349;
  double t15362;
  double t15363;
  double t15370;
  double t15389;
  double t15390;
  double t15391;
  double t15411;
  double t15412;
  double t15413;
  double t15414;
  double t15415;
  double t15416;
  double t15448;
  double t15449;
  double t15450;
  double t15425;
  double t15429;
  double t15430;
  double t15435;
  double t15443;
  double t15444;
  double t15445;
  double t15446;
  double t15452;
  double t15453;
  double t15454;
  double t15455;
  double t15459;
  double t15504;
  double t15505;
  double t15506;
  double t15473;
  double t15474;
  double t15475;
  double t15478;
  double t15479;
  double t15480;
  double t15481;
  double t15482;
  double t15483;
  double t15484;
  double t15487;
  double t15488;
  double t15489;
  double t15490;
  double t15491;
  double t15492;
  double t15498;
  double t15499;
  double t15542;
  double t15543;
  double t15503;
  double t15545;
  double t15546;
  double t15511;
  double t15516;
  double t15552;
  double t15553;
  double t15520;
  double t15575;
  double t15576;
  double t15577;
  double t15578;
  double t15579;
  double t15581;
  double t15582;
  double t15583;
  double t15584;
  double t15585;
  double t15586;
  double t15587;
  double t15588;
  double t15589;
  double t15591;
  double t15592;
  double t15593;
  double t15594;
  double t15595;
  double t15596;
  double t15348;
  double t15350;
  double t15312;
  double t15313;
  double t15290;
  double t15317;
  double t15341;
  double t15342;
  double t15351;
  double t15354;
  double t15355;
  double t15610;
  double t15615;
  double t15616;
  double t15485;
  double t15624;
  double t15501;
  double t15502;
  double t15507;
  double t15508;
  double t15512;
  double t15515;
  double t15517;
  double t15518;
  double t15519;
  double t15521;
  double t15633;
  double t15527;
  double t15528;
  double t15529;
  double t15634;
  double t15531;
  double t15532;
  double t15533;
  double t15635;
  double t15638;
  double t15639;
  double t15640;
  double t15641;
  double t15642;
  double t15643;
  double t15537;
  double t15647;
  double t15544;
  double t15547;
  double t15548;
  double t15649;
  double t15550;
  double t15551;
  double t15554;
  double t15555;
  double t15556;
  double t15557;
  double t15560;
  double t15561;
  double t15562;
  double t15564;
  double t15565;
  double t15566;
  double t15567;
  double t15568;
  double t15569;
  double t15590;
  double t15431;
  double t15447;
  double t15451;
  double t15466;
  double t15467;
  double t10771;
  double t12683;
  double t12808;
  double t12838;
  double t15674;
  double t15675;
  double t15468;
  double t15625;
  double t15626;
  double t15627;
  double t15628;
  double t15629;
  double t15500;
  double t15513;
  double t15514;
  double t15522;
  double t15523;
  double t15648;
  double t15650;
  double t15651;
  double t15652;
  double t15653;
  double t15541;
  double t15549;
  double t15558;
  double t15559;
  double t15563;
  double t15570;
  double t15571;
  double t15664;
  double t15665;
  double t15666;
  double t15667;
  double t15668;
  double t15669;
  double t15670;
  double t15597;
  double t15677;
  double t15721;
  double t15722;
  double t15723;
  double t15611;
  double t15612;
  double t15613;
  double t15636;
  double t15476;
  double t15688;
  double t15689;
  double t15690;
  double t15657;
  double t15658;
  double t15659;
  double t15530;
  double t15534;
  double t15535;
  double t15705;
  double t15706;
  double t15707;
  double t15708;
  double t15709;
  double t15599;
  double t15600;
  double t15601;
  double t15602;
  double t12851;
  double t15726;
  double t15727;
  double t15728;
  double t15759;
  double t15760;
  double t15608;
  double t15682;
  double t15734;
  t8661 = Cos(var1[5]);
  t8105 = Cos(var1[6]);
  t8344 = Sin(var1[5]);
  t8670 = Sin(var1[6]);
  t9535 = Cos(var1[2]);
  t1018 = Sin(var1[2]);
  t8541 = -1.*t8105*t8344;
  t8672 = -1.*t8661*t8670;
  t8685 = t8541 + t8672;
  t11244 = -1.*t8105;
  t11260 = 1. + t11244;
  t11345 = 0.4*t11260;
  t11413 = 0.64*t8105;
  t11668 = t11345 + t11413;
  t9526 = -1.*t1018*t8685;
  t9641 = -1.*t8661*t8105;
  t10056 = t8344*t8670;
  t10210 = t9641 + t10056;
  t10700 = t9535*t10210;
  t10737 = t9526 + t10700;
  t13627 = t9535*t8661;
  t13662 = -1.*t1018*t8344;
  t13712 = t13627 + t13662;
  t12852 = -1.*t8661*t1018;
  t13101 = -1.*t9535*t8344;
  t13527 = t12852 + t13101;
  t11105 = -1.*t9535*t8661;
  t11106 = t1018*t8344;
  t11136 = t11105 + t11106;
  t15094 = t8661*t1018;
  t15116 = t9535*t8344;
  t15121 = t15094 + t15116;
  t12146 = t8661*t8105;
  t12155 = -1.*t8344*t8670;
  t12461 = t12146 + t12155;
  t12118 = t9535*t8685;
  t12546 = -1.*t1018*t12461;
  t12653 = t12118 + t12546;
  t15288 = t9535*t12461;
  t15125 = t8105*t8344;
  t15207 = t8661*t8670;
  t15208 = t15125 + t15207;
  t15299 = t1018*t8685;
  t15311 = t15299 + t15288;
  t15336 = -1.*t9535*t12461;
  t15337 = t9526 + t15336;
  t15220 = -1.*t1018*t15208;
  t15289 = t15220 + t15288;
  t15338 = t9535*t15208;
  t15339 = t1018*t12461;
  t15340 = t15338 + t15339;
  t15352 = t1018*t10210;
  t15353 = t12118 + t15352;
  t15417 = t11668*t8344;
  t15418 = 0.24*t8661*t8670;
  t15424 = t15417 + t15418;
  t15426 = t8661*t11668;
  t15427 = -0.24*t8344*t8670;
  t15428 = t15426 + t15427;
  t15432 = -1.*t11668*t8344;
  t15433 = -0.24*t8661*t8670;
  t15434 = t15432 + t15433;
  t11171 = 0.748*t11136;
  t12761 = t11668*t8105;
  t12764 = Power(t8670,2);
  t12767 = 0.24*t12764;
  t12770 = t12761 + t12767;
  t15471 = t1018*t15208;
  t15472 = t15471 + t10700;
  t11830 = t11668*t8670;
  t11899 = -0.24*t8105*t8670;
  t12015 = t11830 + t11899;
  t13713 = 20.4*t13527*t13712;
  t15122 = 6.8*t15121*t13712;
  t15123 = 20.4*t13527*t11136;
  t15124 = 6.8*t15121*t11136;
  t15349 = -1.*t1018*t10210;
  t15362 = Power(t13527,2);
  t15363 = 13.6*t15362;
  t15370 = 13.6*t13527*t15121;
  t15389 = Power(t13712,2);
  t15390 = 13.6*t15389;
  t15391 = 13.6*t13712*t11136;
  t15411 = Power(t8661,2);
  t15412 = 0.11*t15411;
  t15413 = Power(t8344,2);
  t15414 = 0.11*t15413;
  t15415 = t15412 + t15414;
  t15416 = 6.8*t11136*t15415;
  t15448 = t15424*t15208;
  t15449 = t12461*t15428;
  t15450 = t15448 + t15449;
  t15425 = -1.*t15424*t12461;
  t15429 = -1.*t8685*t15428;
  t15430 = t15425 + t15429;
  t15435 = t15434*t12461;
  t15443 = t15424*t12461;
  t15444 = t8685*t15428;
  t15445 = t15208*t15428;
  t15446 = t15435 + t15443 + t15444 + t15445;
  t15452 = -1.*t8685*t15434;
  t15453 = -1.*t8685*t15424;
  t15454 = -1.*t12461*t15428;
  t15455 = -1.*t15428*t10210;
  t15459 = t15452 + t15453 + t15454 + t15455;
  t15504 = -1.*t8661*t11668;
  t15505 = 0.24*t8344*t8670;
  t15506 = t15504 + t15505;
  t15473 = -0.384*var2[6]*t15472;
  t15474 = 3.2*t12770*t15472;
  t15475 = 3.2*t12015*t15353;
  t15478 = 6.4*t15311*t12653;
  t15479 = 3.2*t15340*t10737;
  t15480 = 3.2*t12653*t15472;
  t15481 = t15338 + t15349;
  t15482 = 3.2*t15311*t15481;
  t15483 = 3.2*t15289*t15353;
  t15484 = 6.4*t10737*t15353;
  t15487 = Power(t15311,2);
  t15488 = 6.4*t15487;
  t15489 = 6.4*t15311*t15472;
  t15490 = 6.4*t15340*t15353;
  t15491 = Power(t15353,2);
  t15492 = 6.4*t15491;
  t15498 = 3.2*t15450*t15472;
  t15499 = 3.2*t15430*t15353;
  t15542 = -0.24*t8105*t8344;
  t15543 = t15542 + t15433;
  t15503 = -1.*t15208*t15428;
  t15545 = 0.24*t8661*t8105;
  t15546 = t15545 + t15427;
  t15511 = -1.*t15424*t10210;
  t15516 = t8685*t15424;
  t15552 = -0.24*t8661*t8105;
  t15553 = t15552 + t15505;
  t15520 = t15428*t10210;
  t15575 = 13.6*t13527*t13712;
  t15576 = 13.6*t15121*t13712;
  t15577 = 6.4*t15311*t15340;
  t15578 = 6.4*t15311*t15353;
  t15579 = t15575 + t15576 + t15577 + t15578;
  t15581 = 6.8*t15362;
  t15582 = 6.8*t13527*t15121;
  t15583 = 6.8*t15389;
  t15584 = 6.8*t13712*t11136;
  t15585 = 3.2*t15311*t15289;
  t15586 = 3.2*t12653*t15340;
  t15587 = 3.2*t15311*t10737;
  t15588 = 3.2*t12653*t15353;
  t15589 = t15581 + t15582 + t15583 + t15584 + t15585 + t15586 + t15587 + t15588;
  t15591 = 6.8*t13527*t15415;
  t15592 = 3.2*t15311*t15430;
  t15593 = 3.2*t15311*t15446;
  t15594 = 3.2*t15450*t15353;
  t15595 = 3.2*t15340*t15459;
  t15596 = t15591 + t15592 + t15593 + t15594 + t15595;
  t15348 = -1.*t9535*t8685;
  t15350 = t15348 + t15349;
  t15312 = -1.*t9535*t15208;
  t15313 = t15312 + t12546;
  t15290 = 6.4*t15289*t12653;
  t15317 = 3.2*t15311*t15313;
  t15341 = 3.2*t15337*t15340;
  t15342 = 6.4*t12653*t10737;
  t15351 = 3.2*t15311*t15350;
  t15354 = 3.2*t15337*t15353;
  t15355 = t13713 + t15122 + t15123 + t15124 + t15290 + t15317 + t15341 + t15342 + t15351 + t15354;
  t15610 = 0.748*t15121;
  t15615 = Power(t11136,2);
  t15616 = 13.6*t15615;
  t15485 = t13713 + t15122 + t15123 + t15124 + t15478 + t15479 + t15480 + t15482 + t15483 + t15484;
  t15624 = 6.8*t15121*t15415;
  t15501 = -1.*t15434*t12461;
  t15502 = -2.*t8685*t15428;
  t15507 = -1.*t8685*t15506;
  t15508 = -2.*t15434*t10210;
  t15512 = t15501 + t15502 + t15503 + t15507 + t15508 + t15511;
  t15515 = 2.*t8685*t15434;
  t15517 = t15434*t15208;
  t15518 = 2.*t12461*t15428;
  t15519 = t12461*t15506;
  t15521 = t15515 + t15516 + t15517 + t15518 + t15519 + t15520;
  t15633 = -0.384*var2[6]*t15481;
  t15527 = Power(t8105,2);
  t15528 = -0.24*t15527;
  t15529 = t12761 + t15528;
  t15634 = 3.2*t12015*t10737;
  t15531 = -1.*t11668*t8670;
  t15532 = 0.24*t8105*t8670;
  t15533 = t15531 + t15532;
  t15635 = 3.2*t12770*t15481;
  t15638 = Power(t12653,2);
  t15639 = 6.4*t15638;
  t15640 = 6.4*t15289*t10737;
  t15641 = Power(t10737,2);
  t15642 = 6.4*t15641;
  t15643 = 6.4*t12653*t15481;
  t15537 = t15478 + t15479 + t15480 + t15482 + t15483 + t15484;
  t15647 = 3.2*t15430*t10737;
  t15544 = t15543*t12461;
  t15547 = t15208*t15546;
  t15548 = t15544 + t15443 + t15444 + t15547;
  t15649 = 3.2*t15450*t15481;
  t15550 = -1.*t15543*t12461;
  t15551 = -1.*t8685*t15546;
  t15554 = -1.*t8685*t15553;
  t15555 = -1.*t15434*t10210;
  t15556 = -1.*t15543*t10210;
  t15557 = t15550 + t15429 + t15503 + t15551 + t15554 + t15555 + t15556 + t15511;
  t15560 = -1.*t8685*t15543;
  t15561 = -1.*t12461*t15546;
  t15562 = t15560 + t15453 + t15561 + t15455;
  t15564 = t8685*t15434;
  t15565 = t8685*t15543;
  t15566 = t15543*t15208;
  t15567 = t12461*t15546;
  t15568 = t12461*t15553;
  t15569 = t15564 + t15565 + t15516 + t15566 + t15449 + t15567 + t15568 + t15520;
  t15590 = -0.5*var2[5]*t15589;
  t15431 = 3.2*t12653*t15430;
  t15447 = 3.2*t12653*t15446;
  t15451 = 3.2*t15450*t10737;
  t15466 = 3.2*t15289*t15459;
  t15467 = t15416 + t15431 + t15447 + t15451 + t15466;
  t10771 = -0.384*var2[6]*t10737;
  t12683 = 3.2*t12015*t12653;
  t12808 = 3.2*t12770*t10737;
  t12838 = t11171 + t12683 + t12808;
  t15674 = 13.6*t13527*t11136;
  t15675 = t15575 + t15674 + t15290 + t15342;
  t15468 = -0.5*var2[2]*t15467;
  t15625 = 3.2*t15337*t15430;
  t15626 = 3.2*t15337*t15446;
  t15627 = 3.2*t15450*t15350;
  t15628 = 3.2*t15313*t15459;
  t15629 = t15624 + t15625 + t15626 + t15627 + t15628;
  t15500 = 6.4*t15446*t15353;
  t15513 = 3.2*t15340*t15512;
  t15514 = 6.4*t15311*t15459;
  t15522 = 3.2*t15311*t15521;
  t15523 = t15416 + t15498 + t15499 + t15500 + t15513 + t15514 + t15522;
  t15648 = 6.4*t15446*t10737;
  t15650 = 3.2*t15289*t15512;
  t15651 = 6.4*t12653*t15459;
  t15652 = 3.2*t12653*t15521;
  t15653 = t15624 + t15647 + t15648 + t15649 + t15650 + t15651 + t15652;
  t15541 = 3.2*t15446*t15353;
  t15549 = 3.2*t15548*t15353;
  t15558 = 3.2*t15340*t15557;
  t15559 = 3.2*t15311*t15459;
  t15563 = 3.2*t15311*t15562;
  t15570 = 3.2*t15311*t15569;
  t15571 = t15498 + t15499 + t15541 + t15549 + t15558 + t15559 + t15563 + t15570;
  t15664 = 3.2*t15446*t10737;
  t15665 = 3.2*t15548*t10737;
  t15666 = 3.2*t15289*t15557;
  t15667 = 3.2*t12653*t15459;
  t15668 = 3.2*t12653*t15562;
  t15669 = 3.2*t12653*t15569;
  t15670 = t15647 + t15664 + t15665 + t15649 + t15666 + t15667 + t15668 + t15669;
  t15597 = -0.5*var2[5]*t15596;
  t15677 = -0.5*var2[5]*t15467;
  t15721 = 6.4*t15446*t15450;
  t15722 = 6.4*t15430*t15459;
  t15723 = t15721 + t15722;
  t15611 = 3.2*t12015*t15337;
  t15612 = 3.2*t12770*t15350;
  t15613 = t15610 + t15611 + t15612;
  t15636 = t15610 + t15634 + t15635;
  t15476 = t11171 + t15474 + t15475;
  t15688 = 3.2*t12015*t15512;
  t15689 = 3.2*t12770*t15521;
  t15690 = t15688 + t15689;
  t15657 = 3.2*t15529*t12653;
  t15658 = 3.2*t15533*t10737;
  t15659 = t15657 + t15634 + t15658 + t15635;
  t15530 = 3.2*t15529*t15311;
  t15534 = 3.2*t15533*t15353;
  t15535 = t15530 + t15474 + t15475 + t15534;
  t15705 = 3.2*t15533*t15446;
  t15706 = 3.2*t12015*t15557;
  t15707 = 3.2*t15529*t15459;
  t15708 = 3.2*t12770*t15569;
  t15709 = t15705 + t15706 + t15707 + t15708;
  t15599 = 0.748*t13527;
  t15600 = 3.2*t12015*t15311;
  t15601 = 3.2*t12770*t15353;
  t15602 = t15599 + t15600 + t15601;
  t12851 = -0.5*var2[5]*t12838;
  t15726 = 3.2*t12770*t15446;
  t15727 = 3.2*t12015*t15459;
  t15728 = t15726 + t15727;
  t15759 = -0.384*var2[0]*t15472;
  t15760 = -0.384*var2[1]*t15481;
  t15608 = -0.384*var2[5]*t15353;
  t15682 = -0.384*var2[5]*t10737;
  t15734 = -0.384*var2[5]*t15446;
  p_output1[0]=(t10771 + t12851 + t15468 - 0.5*(6.4*t10737*t15311 + 6.4*t15289*t15311 + 6.4*t12653*t15340 + 6.4*t12653*t15353 + t15363 + t15370 + t15390 + t15391)*var2[0] - 0.5*t15355*var2[1])*var2[5];
  p_output1[1]=var2[5]*(t15473 - 0.5*(t15363 + t15370 + t15390 + t15391 + t15488 + t15489 + t15490 + t15492)*var2[0] - 0.5*t15485*var2[1] - 0.5*t15523*var2[2] - 0.5*t15476*var2[5]);
  p_output1[2]=var2[5]*(t15473 - 0.5*(t15488 + t15489 + t15490 + t15492)*var2[0] - 0.5*t15537*var2[1] - 0.5*t15571*var2[2] - 0.5*t15535*var2[5]);
  p_output1[3]=-0.5*t15579*var2[5];
  p_output1[4]=t15590;
  p_output1[5]=t15597;
  p_output1[6]=-0.5*t15579*var2[0] - 0.5*t15589*var2[1] - 0.5*t15596*var2[2] - 1.*t15602*var2[5] - 0.384*t15353*var2[6];
  p_output1[7]=t15608;
  p_output1[8]=var2[5]*(-0.5*t15355*var2[0] - 0.5*(6.4*t12653*t15313 + 6.4*t10737*t15337 + 6.4*t15289*t15337 + 6.4*t12653*t15350 + t15363 + t15370 + t15391 + t15616)*var2[1] - 0.5*t15629*var2[2] - 0.5*t15613*var2[5] - 0.384*t15350*var2[6]);
  p_output1[9]=var2[5]*(t15633 - 0.5*t15485*var2[0] - 0.5*(t15363 + t15370 + t15391 + t15616 + t15639 + t15640 + t15642 + t15643)*var2[1] - 0.5*t15653*var2[2] - 0.5*t15636*var2[5]);
  p_output1[10]=var2[5]*(t15633 - 0.5*t15537*var2[0] - 0.5*(t15639 + t15640 + t15642 + t15643)*var2[1] - 0.5*t15670*var2[2] - 0.5*t15659*var2[5]);
  p_output1[11]=t15590;
  p_output1[12]=-0.5*t15675*var2[5];
  p_output1[13]=t15677;
  p_output1[14]=t10771 + t15468 - 0.5*t15589*var2[0] - 0.5*t15675*var2[1] - 1.*t12838*var2[5];
  p_output1[15]=t15682;
  p_output1[16]=(-0.5*t15467*var2[0] - 0.5*t15629*var2[1])*var2[5];
  p_output1[17]=var2[5]*(-0.5*t15523*var2[0] - 0.5*t15653*var2[1] - 0.5*(6.4*Power(t15446,2) + 6.4*Power(t15459,2) + 6.4*t15430*t15512 + 6.4*t15450*t15521)*var2[2] - 0.5*t15690*var2[5] - 0.384*t15521*var2[6]);
  p_output1[18]=var2[5]*(-0.5*t15571*var2[0] - 0.5*t15670*var2[1] - 0.5*(6.4*t15446*t15548 + 6.4*t15430*t15557 + 6.4*t15459*t15562 + 6.4*t15450*t15569)*var2[2] - 0.5*t15709*var2[5] - 0.384*t15569*var2[6]);
  p_output1[19]=t15597;
  p_output1[20]=t15677;
  p_output1[21]=-0.5*t15723*var2[5];
  p_output1[22]=-0.5*t15596*var2[0] - 0.5*t15467*var2[1] - 0.5*t15723*var2[2] - 1.*t15728*var2[5] - 0.384*t15446*var2[6];
  p_output1[23]=t15734;
  p_output1[24]=(-0.5*t12838*var2[0] - 0.5*t15613*var2[1])*var2[5];
  p_output1[25]=(-0.5*t15476*var2[0] - 0.5*t15636*var2[1] - 0.5*t15690*var2[2])*var2[5];
  p_output1[26]=(-0.5*t15535*var2[0] - 0.5*t15659*var2[1] - 0.5*t15709*var2[2])*var2[5];
  p_output1[27]=-0.5*t15602*var2[5];
  p_output1[28]=t12851;
  p_output1[29]=-0.5*t15728*var2[5];
  p_output1[30]=-0.5*t15602*var2[0] - 0.5*t12838*var2[1] - 0.5*t15728*var2[2];
  p_output1[31]=(-0.384*t10737*var2[0] - 0.384*t15350*var2[1])*var2[5];
  p_output1[32]=(t15759 + t15760 - 0.384*t15521*var2[2])*var2[5];
  p_output1[33]=(t15759 + t15760 - 0.384*t15569*var2[2])*var2[5];
  p_output1[34]=t15608;
  p_output1[35]=t15682;
  p_output1[36]=t15734;
  p_output1[37]=-0.384*t15353*var2[0] - 0.384*t10737*var2[1] - 0.384*t15446*var2[2];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 38, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce2_vec6_five_link_walker.hh"

namespace RightStance
{

void J_Ce2_vec6_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
