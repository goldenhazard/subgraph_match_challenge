/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:55 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t265;
  double t306;
  double t323;
  double t322;
  double t414;
  double t416;
  double t431;
  double t432;
  double t436;
  double t450;
  double t451;
  double t452;
  double t456;
  double t457;
  double t495;
  double t499;
  double t500;
  double t458;
  double t459;
  double t475;
  double t415;
  double t428;
  double t429;
  double t501;
  double t502;
  double t503;
  double t545;
  double t549;
  double t559;
  double t561;
  double t565;
  double t566;
  double t567;
  double t572;
  double t575;
  double t576;
  double t577;
  double t578;
  double t583;
  double t584;
  double t585;
  double t579;
  double t580;
  double t581;
  double t560;
  double t562;
  double t563;
  double t594;
  double t595;
  double t598;
  double t378;
  double t379;
  double t380;
  double t392;
  double t397;
  double t479;
  double t512;
  double t513;
  double t448;
  double t534;
  double t541;
  double t542;
  double t552;
  double t553;
  double t554;
  double t555;
  double t556;
  double t582;
  double t599;
  double t606;
  double t568;
  double t618;
  double t620;
  double t622;
  double t669;
  double t671;
  double t672;
  double t673;
  double t674;
  double t677;
  double t678;
  double t679;
  double t321;
  double t354;
  double t368;
  double t410;
  double t639;
  double t640;
  double t518;
  double t695;
  double t696;
  double t697;
  double t634;
  double t635;
  double t636;
  double t690;
  double t691;
  double t694;
  double t698;
  double t700;
  double t630;
  double t631;
  double t632;
  double t633;
  double t714;
  double t715;
  double t681;
  double t682;
  double t683;
  double t684;
  double t742;
  double t743;
  double t744;
  double t746;
  double t749;
  double t750;
  double t751;
  double t686;
  double t687;
  double t688;
  double t704;
  double t706;
  double t707;
  double t708;
  double t764;
  double t767;
  double t773;
  double t716;
  double t722;
  double t723;
  double t724;
  double t725;
  double t728;
  double t729;
  double t794;
  double t796;
  double t797;
  double t801;
  double t802;
  double t803;
  double t804;
  double t805;
  double t547;
  double t550;
  double t551;
  double t558;
  double t657;
  double t660;
  double t613;
  double t824;
  double t825;
  double t828;
  double t649;
  double t652;
  double t655;
  double t817;
  double t822;
  double t823;
  double t829;
  double t830;
  double t644;
  double t645;
  double t646;
  double t647;
  double t846;
  double t847;
  double t807;
  double t808;
  double t809;
  double t812;
  double t902;
  double t904;
  double t907;
  double t908;
  double t909;
  double t911;
  double t912;
  double t814;
  double t815;
  double t816;
  double t835;
  double t840;
  double t841;
  double t842;
  double t933;
  double t934;
  double t935;
  double t848;
  double t852;
  double t853;
  double t854;
  double t855;
  double t856;
  double t861;
  t265 = Cos(var1[2]);
  t306 = Cos(var1[3]);
  t323 = Sin(var1[3]);
  t322 = Sin(var1[2]);
  t414 = Cos(var1[4]);
  t416 = Sin(var1[4]);
  t431 = t306*t414;
  t432 = -1.*t323*t416;
  t436 = t431 + t432;
  t450 = -1.*t414;
  t451 = 1. + t450;
  t452 = 0.4*t451;
  t456 = 0.64*t414;
  t457 = t452 + t456;
  t495 = -1.*t414*t323;
  t499 = -1.*t306*t416;
  t500 = t495 + t499;
  t458 = t457*t323;
  t459 = 0.24*t306*t416;
  t475 = t458 + t459;
  t415 = t414*t323;
  t428 = t306*t416;
  t429 = t415 + t428;
  t501 = t306*t457;
  t502 = -0.24*t323*t416;
  t503 = t501 + t502;
  t545 = Cos(var1[5]);
  t549 = Sin(var1[5]);
  t559 = Cos(var1[6]);
  t561 = Sin(var1[6]);
  t565 = t545*t559;
  t566 = -1.*t549*t561;
  t567 = t565 + t566;
  t572 = -1.*t559;
  t575 = 1. + t572;
  t576 = 0.4*t575;
  t577 = 0.64*t559;
  t578 = t576 + t577;
  t583 = -1.*t559*t549;
  t584 = -1.*t545*t561;
  t585 = t583 + t584;
  t579 = t578*t549;
  t580 = 0.24*t545*t561;
  t581 = t579 + t580;
  t560 = t559*t549;
  t562 = t545*t561;
  t563 = t560 + t562;
  t594 = t545*t578;
  t595 = -0.24*t549*t561;
  t598 = t594 + t595;
  t378 = Power(t306,2);
  t379 = 0.11*t378;
  t380 = Power(t323,2);
  t392 = 0.11*t380;
  t397 = t379 + t392;
  t479 = -1.*t475*t436;
  t512 = -1.*t500*t503;
  t513 = t479 + t512;
  t448 = -1.*t322*t436;
  t534 = t475*t429;
  t541 = t436*t503;
  t542 = t534 + t541;
  t552 = Power(t545,2);
  t553 = 0.11*t552;
  t554 = Power(t549,2);
  t555 = 0.11*t554;
  t556 = t553 + t555;
  t582 = -1.*t581*t567;
  t599 = -1.*t585*t598;
  t606 = t582 + t599;
  t568 = -1.*t322*t567;
  t618 = t581*t563;
  t620 = t567*t598;
  t622 = t618 + t620;
  t669 = -1.*t457*t323;
  t671 = -0.24*t306*t416;
  t672 = t669 + t671;
  t673 = t672*t436;
  t674 = t475*t436;
  t677 = t500*t503;
  t678 = t429*t503;
  t679 = t673 + t674 + t677 + t678;
  t321 = -1.*t265*t306;
  t354 = t322*t323;
  t368 = t321 + t354;
  t410 = -6.8*t368*t397;
  t639 = t265*t500;
  t640 = t639 + t448;
  t518 = -1.*t322*t500;
  t695 = -1.*t306*t414;
  t696 = t323*t416;
  t697 = t695 + t696;
  t634 = -1.*t322*t429;
  t635 = t265*t436;
  t636 = t634 + t635;
  t690 = -1.*t500*t672;
  t691 = -1.*t500*t475;
  t694 = -1.*t436*t503;
  t698 = -1.*t503*t697;
  t700 = t690 + t691 + t694 + t698;
  t630 = -1.*t306*t322;
  t631 = -1.*t265*t323;
  t632 = t630 + t631;
  t633 = -6.8*t632*t397;
  t714 = t322*t500;
  t715 = t714 + t635;
  t681 = t457*t414;
  t682 = Power(t416,2);
  t683 = 0.24*t682;
  t684 = t681 + t683;
  t742 = -0.24*t414*t323;
  t743 = t742 + t671;
  t744 = t743*t436;
  t746 = 0.24*t306*t414;
  t749 = t746 + t502;
  t750 = t429*t749;
  t751 = t744 + t674 + t677 + t750;
  t686 = t457*t416;
  t687 = -0.24*t414*t416;
  t688 = t686 + t687;
  t704 = -3.2*t640*t513;
  t706 = t265*t697;
  t707 = t518 + t706;
  t708 = -3.2*t542*t707;
  t764 = -1.*t500*t743;
  t767 = -1.*t436*t749;
  t773 = t764 + t691 + t767 + t698;
  t716 = -3.2*t715*t513;
  t722 = t322*t697;
  t723 = t639 + t722;
  t724 = -3.2*t542*t723;
  t725 = t265*t429;
  t728 = t322*t436;
  t729 = t725 + t728;
  t794 = -1.*t578*t549;
  t796 = -0.24*t545*t561;
  t797 = t794 + t796;
  t801 = t797*t567;
  t802 = t581*t567;
  t803 = t585*t598;
  t804 = t563*t598;
  t805 = t801 + t802 + t803 + t804;
  t547 = -1.*t265*t545;
  t550 = t322*t549;
  t551 = t547 + t550;
  t558 = -6.8*t551*t556;
  t657 = t265*t585;
  t660 = t657 + t568;
  t613 = -1.*t322*t585;
  t824 = -1.*t545*t559;
  t825 = t549*t561;
  t828 = t824 + t825;
  t649 = -1.*t322*t563;
  t652 = t265*t567;
  t655 = t649 + t652;
  t817 = -1.*t585*t797;
  t822 = -1.*t585*t581;
  t823 = -1.*t567*t598;
  t829 = -1.*t598*t828;
  t830 = t817 + t822 + t823 + t829;
  t644 = -1.*t545*t322;
  t645 = -1.*t265*t549;
  t646 = t644 + t645;
  t647 = -6.8*t646*t556;
  t846 = t322*t585;
  t847 = t846 + t652;
  t807 = t578*t559;
  t808 = Power(t561,2);
  t809 = 0.24*t808;
  t812 = t807 + t809;
  t902 = -0.24*t559*t549;
  t904 = t902 + t796;
  t907 = t904*t567;
  t908 = 0.24*t545*t559;
  t909 = t908 + t595;
  t911 = t563*t909;
  t912 = t907 + t802 + t803 + t911;
  t814 = t578*t561;
  t815 = -0.24*t559*t561;
  t816 = t814 + t815;
  t835 = -3.2*t660*t606;
  t840 = t265*t828;
  t841 = t613 + t840;
  t842 = -3.2*t622*t841;
  t933 = -1.*t585*t904;
  t934 = -1.*t567*t909;
  t935 = t933 + t822 + t934 + t829;
  t848 = -3.2*t847*t606;
  t852 = t322*t828;
  t853 = t657 + t852;
  t854 = -3.2*t622*t853;
  t855 = t265*t563;
  t856 = t322*t567;
  t861 = t855 + t856;
  p_output1[0]=0;
  p_output1[1]=0;
  p_output1[2]=(-0.5*(2.88*t322 + t633 - 3.2*t513*t636 - 3.2*t542*t640 + t647 - 3.2*t606*t655 - 3.2*t622*t660)*var2[0] - 0.5*(2.88*t265 + t410 - 3.2*(-1.*t265*t429 + t448)*t513 - 3.2*(-1.*t265*t436 + t518)*t542 + t558 - 3.2*(-1.*t265*t563 + t568)*t606 - 3.2*(-1.*t265*t567 + t613)*t622)*var2[1])*var2[2];
  p_output1[3]=var2[2]*(-0.5*(t633 - 3.2*t679*t715 + t716 + t724 - 3.2*t700*t729)*var2[0] - 0.5*(t410 - 3.2*t640*t679 - 3.2*t636*t700 + t704 + t708)*var2[1] - 0.5*(-6.4*t542*t679 - 6.4*t513*t700)*var2[2] - 0.5*(-3.2*t679*t684 - 3.2*t688*t700)*var2[3] + 0.384*t679*var2[4]);
  p_output1[4]=var2[2]*(-0.5*(t716 + t724 - 3.2*t715*t751 - 3.2*t729*t773)*var2[0] - 0.5*(t704 + t708 - 3.2*t640*t751 - 3.2*t636*t773)*var2[1] - 0.5*(-6.4*t542*t751 - 6.4*t513*t773)*var2[2] - 0.5*(-3.2*(0.24*t414*t416 - 1.*t416*t457)*t542 - 3.2*t513*(-0.24*Power(t414,2) + t681) - 3.2*t684*t751 - 3.2*t688*t773)*var2[3] + 0.384*t751*var2[4]);
  p_output1[5]=var2[2]*(-0.5*(t647 - 3.2*t805*t847 + t848 + t854 - 3.2*t830*t861)*var2[0] - 0.5*(t558 - 3.2*t660*t805 - 3.2*t655*t830 + t835 + t842)*var2[1] - 0.5*(-6.4*t622*t805 - 6.4*t606*t830)*var2[2] - 0.5*(-3.2*t805*t812 - 3.2*t816*t830)*var2[5] + 0.384*t805*var2[6]);
  p_output1[6]=var2[2]*(-0.5*(t848 + t854 - 3.2*t847*t912 - 3.2*t861*t935)*var2[0] - 0.5*(t835 + t842 - 3.2*t660*t912 - 3.2*t655*t935)*var2[1] - 0.5*(-6.4*t622*t912 - 6.4*t606*t935)*var2[2] - 0.5*(-3.2*(0.24*t559*t561 - 1.*t561*t578)*t622 - 3.2*t606*(-0.24*Power(t559,2) + t807) - 3.2*t812*t912 - 3.2*t816*t935)*var2[5] + 0.384*t912*var2[6]);
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce3_vec3_five_link_walker.hh"

namespace RightStance
{

void Ce3_vec3_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
