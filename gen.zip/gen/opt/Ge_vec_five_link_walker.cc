/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:05 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t65;
  double t3709;
  double t10119;
  double t10120;
  double t10132;
  double t10141;
  double t10209;
  double t10235;
  double t10260;
  double t10282;
  double t10283;
  double t10284;
  double t10353;
  double t10355;
  double t10356;
  double t10357;
  double t10358;
  double t10360;
  double t10365;
  double t10366;
  double t10367;
  double t10368;
  double t10222;
  double t10239;
  double t10255;
  double t10258;
  double t10295;
  double t10296;
  double t10297;
  double t10298;
  double t10348;
  double t10351;
  double t10352;
  double t10384;
  double t10385;
  double t10386;
  double t10359;
  double t10361;
  double t10362;
  double t10364;
  double t10369;
  double t10370;
  double t10371;
  double t10373;
  double t10378;
  double t10379;
  double t10380;
  double t10395;
  double t10396;
  double t10397;
  t65 = Sin(var1[2]);
  t3709 = Cos(var1[3]);
  t10119 = -1.*t3709*t65;
  t10120 = Cos(var1[2]);
  t10132 = Sin(var1[3]);
  t10141 = -1.*t10120*t10132;
  t10209 = t10119 + t10141;
  t10235 = Cos(var1[4]);
  t10260 = -1.*t10120*t3709;
  t10282 = t65*t10132;
  t10283 = t10260 + t10282;
  t10284 = Sin(var1[4]);
  t10353 = Cos(var1[5]);
  t10355 = -1.*t10353*t65;
  t10356 = Sin(var1[5]);
  t10357 = -1.*t10120*t10356;
  t10358 = t10355 + t10357;
  t10360 = Cos(var1[6]);
  t10365 = -1.*t10120*t10353;
  t10366 = t65*t10356;
  t10367 = t10365 + t10366;
  t10368 = Sin(var1[6]);
  t10222 = -7.33788*t10209;
  t10239 = -1.*t10235;
  t10255 = 1. + t10239;
  t10258 = 0.4*t10255*t10209;
  t10295 = -0.4*t10283*t10284;
  t10296 = t10235*t10209;
  t10297 = t10283*t10284;
  t10298 = t10296 + t10297;
  t10348 = 0.64*t10298;
  t10351 = t10258 + t10295 + t10348;
  t10352 = -31.392000000000003*t10351;
  t10384 = t10120*t3709;
  t10385 = -1.*t65*t10132;
  t10386 = t10384 + t10385;
  t10359 = -7.33788*t10358;
  t10361 = -1.*t10360;
  t10362 = 1. + t10361;
  t10364 = 0.4*t10362*t10358;
  t10369 = -0.4*t10367*t10368;
  t10370 = t10360*t10358;
  t10371 = t10367*t10368;
  t10373 = t10370 + t10371;
  t10378 = 0.64*t10373;
  t10379 = t10364 + t10369 + t10378;
  t10380 = -31.392000000000003*t10379;
  t10395 = t10120*t10353;
  t10396 = -1.*t65*t10356;
  t10397 = t10395 + t10396;
  p_output1[0]=0;
  p_output1[1]=-313.92;
  p_output1[2]=t10222 + t10352 + t10359 + t10380 + 28.252799999999997*t65;
  p_output1[3]=t10222 + t10352;
  p_output1[4]=-31.392000000000003*(-0.4*t10209*t10235 + 0.4*t10284*t10386 + 0.64*(t10296 - 1.*t10284*t10386));
  p_output1[5]=t10359 + t10380;
  p_output1[6]=-31.392000000000003*(-0.4*t10358*t10360 + 0.4*t10368*t10397 + 0.64*(t10370 - 1.*t10368*t10397));
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ge_vec_five_link_walker.hh"

namespace RightStance
{

void Ge_vec_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
