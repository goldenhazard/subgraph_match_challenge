/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:32:16 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t3159;
  double t1695;
  double t1740;
  double t1639;
  double t3182;
  double t1095;
  double t3167;
  double t3168;
  double t3175;
  double t3176;
  double t3180;
  double t10653;
  double t11063;
  double t11094;
  double t11156;
  double t11177;
  double t11197;
  double t11206;
  double t11214;
  double t11221;
  double t11122;
  double t3181;
  double t3183;
  double t3184;
  double t3185;
  double t3701;
  double t8290;
  double t8510;
  double t1654;
  double t3145;
  double t3147;
  double t3157;
  double t11421;
  double t8686;
  double t11594;
  double t11632;
  double t11947;
  double t12185;
  double t11144;
  double t12655;
  double t12908;
  double t12953;
  double t13311;
  double t12899;
  double t12902;
  double t12905;
  double t13563;
  double t13566;
  double t13568;
  double t13747;
  double t16723;
  double t16733;
  double t16736;
  double t16493;
  double t16507;
  double t16702;
  double t11328;
  double t11422;
  double t15951;
  double t15966;
  double t15967;
  double t16713;
  double t16720;
  double t16721;
  double t11148;
  double t11426;
  double t11572;
  double t16763;
  double t16765;
  double t16766;
  double t16771;
  double t16772;
  double t16895;
  double t16896;
  double t13576;
  double t13581;
  double t15968;
  double t16306;
  double t16384;
  double t16436;
  double t12262;
  double t16991;
  double t16992;
  double t16993;
  double t16986;
  double t16987;
  double t16989;
  double t17001;
  double t17002;
  double t17003;
  double t16996;
  double t16997;
  double t16998;
  double t16919;
  double t16920;
  double t16921;
  double t16923;
  double t16930;
  double t16931;
  double t16932;
  double t16970;
  double t16975;
  double t16995;
  double t17083;
  double t17084;
  double t17004;
  double t17008;
  double t17090;
  double t17091;
  double t17093;
  double t17094;
  double t17013;
  double t17038;
  double t17039;
  double t17068;
  double t17069;
  double t17070;
  double t17076;
  double t17079;
  double t17100;
  double t17101;
  double t17102;
  double t17103;
  double t17104;
  double t17180;
  double t17181;
  double t17182;
  double t17185;
  double t17186;
  double t17190;
  double t16722;
  double t16737;
  double t16738;
  double t16739;
  double t16744;
  double t16745;
  double t16751;
  double t16752;
  double t16760;
  double t16761;
  double t17034;
  double t17035;
  double t17036;
  double t17037;
  double t17040;
  double t17041;
  double t17052;
  double t17063;
  double t17082;
  double t17085;
  double t17087;
  double t17092;
  double t17095;
  double t17096;
  double t17097;
  double t17098;
  double t17099;
  double t17161;
  double t17162;
  double t17163;
  double t17167;
  double t17168;
  double t17169;
  double t17170;
  double t17171;
  double t17172;
  double t17173;
  double t17174;
  double t17175;
  double t17176;
  double t17196;
  double t17197;
  double t17198;
  double t12658;
  double t17216;
  double t17229;
  double t17230;
  double t17232;
  double t17233;
  double t17235;
  double t17236;
  double t17237;
  double t17243;
  double t17244;
  double t17245;
  double t17255;
  double t17256;
  double t17257;
  double t17260;
  double t17261;
  double t17262;
  double t17263;
  double t17264;
  t3159 = Cos(var1[4]);
  t1695 = Sin(var1[2]);
  t1740 = Sin(var1[3]);
  t1639 = Cos(var1[3]);
  t3182 = Sin(var1[4]);
  t1095 = Cos(var1[2]);
  t3167 = -1.*t3159;
  t3168 = 1. + t3167;
  t3175 = 0.4*t3168;
  t3176 = 0.64*t3159;
  t3180 = t3175 + t3176;
  t10653 = t1639*t3159;
  t11063 = -1.*t1740*t3182;
  t11094 = t10653 + t11063;
  t11156 = t3180*t3182;
  t11177 = -0.24*t3159*t3182;
  t11197 = t11156 + t11177;
  t11206 = t3159*t1740;
  t11214 = t1639*t3182;
  t11221 = t11206 + t11214;
  t11122 = -1.*t1095*t11094;
  t3181 = t3180*t3159;
  t3183 = Power(t3182,2);
  t3184 = 0.24*t3183;
  t3185 = t3181 + t3184;
  t3701 = -1.*t3159*t1740;
  t8290 = -1.*t1639*t3182;
  t8510 = t3701 + t8290;
  t1654 = -1.*t1095*t1639;
  t3145 = t1695*t1740;
  t3147 = t1654 + t3145;
  t3157 = -0.748*t3147;
  t11421 = -1.*t1695*t11094;
  t8686 = -1.*t1695*t8510;
  t11594 = t1639*t1695;
  t11632 = t1095*t1740;
  t11947 = t11594 + t11632;
  t12185 = -0.748*t11947;
  t11144 = t8686 + t11122;
  t12655 = -1.*t1095*t8510;
  t12908 = -1.*t1639*t3159;
  t12953 = t1740*t3182;
  t13311 = t12908 + t12953;
  t12899 = t1095*t8510;
  t12902 = t12899 + t11421;
  t12905 = -3.2*t11197*t12902;
  t13563 = t1095*t13311;
  t13566 = t8686 + t13563;
  t13568 = -3.2*t3185*t13566;
  t13747 = -3.2*t11197*t11144;
  t16723 = -1.*t3180*t3182;
  t16733 = 0.24*t3159*t3182;
  t16736 = t16723 + t16733;
  t16493 = Power(t3159,2);
  t16507 = -0.24*t16493;
  t16702 = t3181 + t16507;
  t11328 = -1.*t1095*t11221;
  t11422 = t11328 + t11421;
  t15951 = -1.*t1695*t13311;
  t15966 = t12655 + t15951;
  t15967 = -3.2*t3185*t15966;
  t16713 = -1.*t1695*t11221;
  t16720 = t1095*t11094;
  t16721 = t16713 + t16720;
  t11148 = -3.2*t3185*t11144;
  t11426 = -3.2*t11197*t11422;
  t11572 = t3157 + t11148 + t11426;
  t16763 = -1.*t1639*t1695;
  t16765 = -1.*t1095*t1740;
  t16766 = t16763 + t16765;
  t16771 = -0.748*t16766;
  t16772 = -3.2*t11197*t16721;
  t16895 = -3.2*t3185*t12902;
  t16896 = t16771 + t16772 + t16895;
  t13576 = t3157 + t12905 + t13568;
  t13581 = -0.5*var2[0]*t13576;
  t15968 = t12185 + t13747 + t15967;
  t16306 = -0.5*var2[1]*t15968;
  t16384 = t13581 + t16306;
  t16436 = var2[3]*t16384;
  t12262 = t1695*t11221;
  t16991 = t1639*t3180;
  t16992 = -0.24*t1740*t3182;
  t16993 = t16991 + t16992;
  t16986 = -1.*t3180*t1740;
  t16987 = -0.24*t1639*t3182;
  t16989 = t16986 + t16987;
  t17001 = t3180*t1740;
  t17002 = 0.24*t1639*t3182;
  t17003 = t17001 + t17002;
  t16996 = -1.*t1639*t3180;
  t16997 = 0.24*t1740*t3182;
  t16998 = t16996 + t16997;
  t16919 = -3.2*t11197*t13566;
  t16920 = t1095*t11221;
  t16921 = t16920 + t15951;
  t16923 = -3.2*t3185*t16921;
  t16930 = t12262 + t13563;
  t16931 = -3.2*t3185*t16930;
  t16932 = t1695*t13311;
  t16970 = t12899 + t16932;
  t16975 = -3.2*t11197*t16970;
  t16995 = -1.*t11221*t16993;
  t17083 = -0.24*t3159*t1740;
  t17084 = t17083 + t16987;
  t17004 = -1.*t17003*t13311;
  t17008 = t8510*t17003;
  t17090 = 0.24*t1639*t3159;
  t17091 = t17090 + t16992;
  t17093 = -0.24*t1639*t3159;
  t17094 = t17093 + t16997;
  t17013 = t16993*t13311;
  t17038 = t1695*t8510;
  t17039 = t17038 + t16720;
  t17068 = t16989*t11094;
  t17069 = t17003*t11094;
  t17070 = t8510*t16993;
  t17076 = t11221*t16993;
  t17079 = t17068 + t17069 + t17070 + t17076;
  t17100 = -1.*t8510*t16989;
  t17101 = -1.*t8510*t17003;
  t17102 = -1.*t11094*t16993;
  t17103 = -1.*t16993*t13311;
  t17104 = t17100 + t17101 + t17102 + t17103;
  t17180 = -3.2*t11197*t17039;
  t17181 = -3.2*t3185*t16970;
  t17182 = t16771 + t17180 + t17181;
  t17185 = -3.2*t3185*t17079;
  t17186 = -3.2*t11197*t17104;
  t17190 = t17185 + t17186;
  t16722 = -3.2*t16702*t16721;
  t16737 = -3.2*t16736*t12902;
  t16738 = t16722 + t12905 + t16737 + t13568;
  t16739 = -0.5*var2[0]*t16738;
  t16744 = -3.2*t16736*t11144;
  t16745 = -3.2*t16702*t11422;
  t16751 = t13747 + t16744 + t16745 + t15967;
  t16752 = -0.5*var2[1]*t16751;
  t16760 = t16739 + t16752;
  t16761 = var2[3]*t16760;
  t17034 = -3.2*t16702*t12902;
  t17035 = -3.2*t16736*t13566;
  t17036 = t17034 + t16919 + t17035 + t16923;
  t17037 = -0.5*var2[1]*t17036;
  t17040 = -3.2*t16702*t17039;
  t17041 = -3.2*t16736*t16970;
  t17052 = t17040 + t16931 + t16975 + t17041;
  t17063 = -0.5*var2[0]*t17052;
  t17082 = -3.2*t16736*t17079;
  t17085 = -1.*t17084*t11094;
  t17087 = -1.*t8510*t16993;
  t17092 = -1.*t8510*t17091;
  t17095 = -1.*t8510*t17094;
  t17096 = -1.*t16989*t13311;
  t17097 = -1.*t17084*t13311;
  t17098 = t17085 + t17087 + t16995 + t17092 + t17095 + t17096 + t17097 + t17004;
  t17099 = -3.2*t11197*t17098;
  t17161 = -3.2*t16702*t17104;
  t17162 = t8510*t16989;
  t17163 = t8510*t17084;
  t17167 = t17084*t11221;
  t17168 = t11094*t16993;
  t17169 = t11094*t17091;
  t17170 = t11094*t17094;
  t17171 = t17162 + t17163 + t17008 + t17167 + t17168 + t17169 + t17170 + t17013;
  t17172 = -3.2*t3185*t17171;
  t17173 = t17082 + t17099 + t17161 + t17172;
  t17174 = -0.5*var2[2]*t17173;
  t17175 = t17037 + t17063 + t17174;
  t17176 = var2[3]*t17175;
  t17196 = -1.*t3180*t3159;
  t17197 = 0.24*t16493;
  t17198 = t17196 + t17197;
  t12658 = t1695*t11094;
  t17216 = t16920 + t12658;
  t17229 = -1.*t17003*t11094;
  t17230 = t17229 + t17087;
  t17232 = t17003*t11221;
  t17233 = t17232 + t17168;
  t17235 = t17084*t11094;
  t17236 = t11221*t17091;
  t17237 = t17235 + t17069 + t17070 + t17236;
  t17243 = -1.*t8510*t17084;
  t17244 = -1.*t11094*t17091;
  t17245 = t17243 + t17101 + t17244 + t17103;
  t17255 = -3.2*t16736*t17039;
  t17256 = -3.2*t16702*t17216;
  t17257 = t17180 + t17255 + t17256 + t17181;
  t17260 = -3.2*t16702*t17230;
  t17261 = -3.2*t16736*t17233;
  t17262 = -3.2*t3185*t17237;
  t17263 = -3.2*t11197*t17245;
  t17264 = t17260 + t17261 + t17262 + t17263;
  p_output1[0]=(-0.5*t11572*var2[0] - 0.5*(t12185 - 3.2*t11197*(t11122 + t12262) - 3.2*(t12655 + t12658)*t3185)*var2[1])*var2[3];
  p_output1[1]=t16436;
  p_output1[2]=t16761;
  p_output1[3]=-0.5*t16896*var2[3];
  p_output1[4]=-0.5*t11572*var2[3];
  p_output1[5]=-0.5*t16896*var2[0] - 0.5*t11572*var2[1];
  p_output1[6]=t16436;
  p_output1[7]=(-0.5*(t16931 + t16975 + t3157)*var2[0] - 0.5*(t12185 + t16919 + t16923)*var2[1] - 0.5*(-3.2*t3185*(t11221*t16989 + 2.*t11094*t16993 + t11094*t16998 + t17008 + t17013 + 2.*t16989*t8510) - 3.2*t11197*(-1.*t11094*t16989 - 2.*t13311*t16989 + t16995 + t17004 - 2.*t16993*t8510 - 1.*t16998*t8510))*var2[2])*var2[3];
  p_output1[8]=t17176;
  p_output1[9]=-0.5*t17182*var2[3];
  p_output1[10]=-0.5*t13576*var2[3];
  p_output1[11]=-0.5*t17190*var2[3];
  p_output1[12]=-0.5*t17182*var2[0] - 0.5*t13576*var2[1] - 0.5*t17190*var2[2];
  p_output1[13]=t16761;
  p_output1[14]=t17176;
  p_output1[15]=var2[3]*(-0.5*(t16931 - 6.4*t16736*t16970 + t16975 - 6.4*t16702*t17039 - 3.2*t17039*t17198 - 3.2*t16736*t17216)*var2[0] - 0.5*(-6.4*t12902*t16702 - 6.4*t13566*t16736 - 3.2*t16721*t16736 + t16919 + t16923 - 3.2*t12902*t17198)*var2[1] - 0.5*(-3.2*t16736*t17230 - 3.2*t17198*t17233 - 6.4*t16736*t17237 - 6.4*t16702*t17245 - 3.2*t3185*(t17008 + t17013 + 2.*t11094*t17091 + t17167 + t17170 + 2.*t17084*t8510) - 3.2*t11197*(t16995 + t17004 - 2.*t13311*t17084 + t17085 + t17095 - 2.*t17091*t8510))*var2[2] - 0.5*(-6.4*Power(t16702,2) - 6.4*t11197*t16736 - 6.4*Power(t16736,2) - 6.4*t17198*t3185)*var2[3] + 0.384*t17198*var2[4]);
  p_output1[16]=-0.5*t17257*var2[3];
  p_output1[17]=-0.5*t16738*var2[3];
  p_output1[18]=-0.5*t17264*var2[3];
  p_output1[19]=-0.5*t17257*var2[0] - 0.5*t16738*var2[1] - 0.5*t17264*var2[2] - 1.*(-6.4*t11197*t16702 - 6.4*t16736*t3185)*var2[3] + 0.384*t16736*var2[4];
  p_output1[20]=0.384*t16736*var2[3];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 21, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce3_vec4_five_link_walker.hh"

namespace RightStance
{

void J_Ce3_vec4_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
