/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:53 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t154;
  double t137;
  double t146;
  double t166;
  double t230;
  double t115;
  double t153;
  double t169;
  double t177;
  double t206;
  double t248;
  double t254;
  double t255;
  double t258;
  double t260;
  double t284;
  double t285;
  double t286;
  double t287;
  double t288;
  double t340;
  double t324;
  double t325;
  double t341;
  double t339;
  double t342;
  double t343;
  double t346;
  double t347;
  double t348;
  double t349;
  double t350;
  double t353;
  double t359;
  double t360;
  double t361;
  double t362;
  double t363;
  double t381;
  double t382;
  double t383;
  double t272;
  double t277;
  double t281;
  double t319;
  double t315;
  double t316;
  double t317;
  double t318;
  double t320;
  double t400;
  double t401;
  double t402;
  double t355;
  double t356;
  double t357;
  double t376;
  double t372;
  double t373;
  double t374;
  double t375;
  double t377;
  double t384;
  double t385;
  double t386;
  double t394;
  double t393;
  double t395;
  double t390;
  double t391;
  double t403;
  double t404;
  double t405;
  double t412;
  double t411;
  double t413;
  double t408;
  double t409;
  double t466;
  double t467;
  double t468;
  double t470;
  double t471;
  double t472;
  double t486;
  double t487;
  double t488;
  double t490;
  double t491;
  double t492;
  double t283;
  double t303;
  double t307;
  double t314;
  double t289;
  double t292;
  double t293;
  double t294;
  double t504;
  double t505;
  double t506;
  double t507;
  double t508;
  double t388;
  double t389;
  double t417;
  double t418;
  double t419;
  double t420;
  double t421;
  double t422;
  double t423;
  double t424;
  double t425;
  double t426;
  double t427;
  double t433;
  double t434;
  double t435;
  double t460;
  double t461;
  double t462;
  double t463;
  double t464;
  double t465;
  double t469;
  double t473;
  double t474;
  double t476;
  double t477;
  double t478;
  double t528;
  double t530;
  double t531;
  double t509;
  double t510;
  double t511;
  double t515;
  double t516;
  double t519;
  double t520;
  double t521;
  double t522;
  double t523;
  double t524;
  double t527;
  double t535;
  double t540;
  double t544;
  double t570;
  double t571;
  double t546;
  double t573;
  double t574;
  double t548;
  double t358;
  double t369;
  double t370;
  double t371;
  double t364;
  double t365;
  double t366;
  double t367;
  double t586;
  double t587;
  double t588;
  double t589;
  double t590;
  double t406;
  double t407;
  double t437;
  double t438;
  double t439;
  double t440;
  double t441;
  double t442;
  double t443;
  double t444;
  double t445;
  double t446;
  double t447;
  double t453;
  double t454;
  double t455;
  double t480;
  double t481;
  double t482;
  double t483;
  double t484;
  double t485;
  double t489;
  double t493;
  double t494;
  double t496;
  double t497;
  double t498;
  double t610;
  double t611;
  double t612;
  double t591;
  double t592;
  double t593;
  double t596;
  double t597;
  double t600;
  double t601;
  double t602;
  double t603;
  double t604;
  double t605;
  double t608;
  double t614;
  double t615;
  double t619;
  double t650;
  double t651;
  double t621;
  double t653;
  double t654;
  double t623;
  t154 = Cos(var1[3]);
  t137 = Cos(var1[4]);
  t146 = Sin(var1[3]);
  t166 = Sin(var1[4]);
  t230 = Cos(var1[2]);
  t115 = Sin(var1[2]);
  t153 = -1.*t137*t146;
  t169 = -1.*t154*t166;
  t177 = t153 + t169;
  t206 = -1.*t115*t177;
  t248 = t154*t137;
  t254 = -1.*t146*t166;
  t255 = t248 + t254;
  t258 = -1.*t230*t255;
  t260 = t206 + t258;
  t284 = -1.*t137;
  t285 = 1. + t284;
  t286 = 0.4*t285;
  t287 = 0.64*t137;
  t288 = t286 + t287;
  t340 = Cos(var1[5]);
  t324 = Cos(var1[6]);
  t325 = Sin(var1[5]);
  t341 = Sin(var1[6]);
  t339 = -1.*t324*t325;
  t342 = -1.*t340*t341;
  t343 = t339 + t342;
  t346 = -1.*t115*t343;
  t347 = t340*t324;
  t348 = -1.*t325*t341;
  t349 = t347 + t348;
  t350 = -1.*t230*t349;
  t353 = t346 + t350;
  t359 = -1.*t324;
  t360 = 1. + t359;
  t361 = 0.4*t360;
  t362 = 0.64*t324;
  t363 = t361 + t362;
  t381 = -1.*t154*t115;
  t382 = -1.*t230*t146;
  t383 = t381 + t382;
  t272 = -1.*t230*t154;
  t277 = t115*t146;
  t281 = t272 + t277;
  t319 = -1.*t115*t255;
  t315 = t137*t146;
  t316 = t154*t166;
  t317 = t315 + t316;
  t318 = -1.*t230*t317;
  t320 = t318 + t319;
  t400 = -1.*t340*t115;
  t401 = -1.*t230*t325;
  t402 = t400 + t401;
  t355 = -1.*t230*t340;
  t356 = t115*t325;
  t357 = t355 + t356;
  t376 = -1.*t115*t349;
  t372 = t324*t325;
  t373 = t340*t341;
  t374 = t372 + t373;
  t375 = -1.*t230*t374;
  t377 = t375 + t376;
  t384 = t230*t154;
  t385 = -1.*t115*t146;
  t386 = t384 + t385;
  t394 = t230*t255;
  t393 = -1.*t115*t317;
  t395 = t393 + t394;
  t390 = t230*t177;
  t391 = t390 + t319;
  t403 = t230*t340;
  t404 = -1.*t115*t325;
  t405 = t403 + t404;
  t412 = t230*t349;
  t411 = -1.*t115*t374;
  t413 = t411 + t412;
  t408 = t230*t343;
  t409 = t408 + t376;
  t466 = t288*t146;
  t467 = 0.24*t154*t166;
  t468 = t466 + t467;
  t470 = t154*t288;
  t471 = -0.24*t146*t166;
  t472 = t470 + t471;
  t486 = t363*t325;
  t487 = 0.24*t340*t341;
  t488 = t486 + t487;
  t490 = t340*t363;
  t491 = -0.24*t325*t341;
  t492 = t490 + t491;
  t283 = -0.748*t281;
  t303 = t288*t166;
  t307 = -0.24*t137*t166;
  t314 = t303 + t307;
  t289 = t288*t137;
  t292 = Power(t166,2);
  t293 = 0.24*t292;
  t294 = t289 + t293;
  t504 = -1.*t154*t137;
  t505 = t146*t166;
  t506 = t504 + t505;
  t507 = t230*t506;
  t508 = t206 + t507;
  t388 = -13.6*t383*t386;
  t389 = -13.6*t383*t281;
  t417 = Power(t383,2);
  t418 = -6.8*t417;
  t419 = t154*t115;
  t420 = t230*t146;
  t421 = t419 + t420;
  t422 = -6.8*t383*t421;
  t423 = Power(t386,2);
  t424 = -6.8*t423;
  t425 = -6.8*t386*t281;
  t426 = t115*t177;
  t427 = t426 + t394;
  t433 = t230*t317;
  t434 = t115*t255;
  t435 = t433 + t434;
  t460 = Power(t154,2);
  t461 = 0.11*t460;
  t462 = Power(t146,2);
  t463 = 0.11*t462;
  t464 = t461 + t463;
  t465 = -6.8*t281*t464;
  t469 = -1.*t468*t255;
  t473 = -1.*t177*t472;
  t474 = t469 + t473;
  t476 = t468*t317;
  t477 = t255*t472;
  t478 = t476 + t477;
  t528 = -1.*t288*t146;
  t530 = -0.24*t154*t166;
  t531 = t528 + t530;
  t509 = 0.384*var2[4]*t508;
  t510 = -3.2*t314*t391;
  t511 = -3.2*t294*t508;
  t515 = -6.4*t395*t391;
  t516 = -6.4*t391*t508;
  t519 = -3.2*t427*t395;
  t520 = -3.2*t391*t435;
  t521 = -3.2*t427*t508;
  t522 = t115*t506;
  t523 = t390 + t522;
  t524 = -3.2*t391*t523;
  t527 = -3.2*t391*t474;
  t535 = t468*t255;
  t540 = t177*t472;
  t544 = -3.2*t478*t508;
  t570 = -0.24*t137*t146;
  t571 = t570 + t530;
  t546 = -1.*t177*t468;
  t573 = 0.24*t154*t137;
  t574 = t573 + t471;
  t548 = -1.*t472*t506;
  t358 = -0.748*t357;
  t369 = t363*t341;
  t370 = -0.24*t324*t341;
  t371 = t369 + t370;
  t364 = t363*t324;
  t365 = Power(t341,2);
  t366 = 0.24*t365;
  t367 = t364 + t366;
  t586 = -1.*t340*t324;
  t587 = t325*t341;
  t588 = t586 + t587;
  t589 = t230*t588;
  t590 = t346 + t589;
  t406 = -13.6*t402*t405;
  t407 = -13.6*t402*t357;
  t437 = Power(t402,2);
  t438 = -6.8*t437;
  t439 = t340*t115;
  t440 = t230*t325;
  t441 = t439 + t440;
  t442 = -6.8*t402*t441;
  t443 = Power(t405,2);
  t444 = -6.8*t443;
  t445 = -6.8*t405*t357;
  t446 = t115*t343;
  t447 = t446 + t412;
  t453 = t230*t374;
  t454 = t115*t349;
  t455 = t453 + t454;
  t480 = Power(t340,2);
  t481 = 0.11*t480;
  t482 = Power(t325,2);
  t483 = 0.11*t482;
  t484 = t481 + t483;
  t485 = -6.8*t357*t484;
  t489 = -1.*t488*t349;
  t493 = -1.*t343*t492;
  t494 = t489 + t493;
  t496 = t488*t374;
  t497 = t349*t492;
  t498 = t496 + t497;
  t610 = -1.*t363*t325;
  t611 = -0.24*t340*t341;
  t612 = t610 + t611;
  t591 = 0.384*var2[6]*t590;
  t592 = -3.2*t371*t409;
  t593 = -3.2*t367*t590;
  t596 = -6.4*t413*t409;
  t597 = -6.4*t409*t590;
  t600 = -3.2*t447*t413;
  t601 = -3.2*t409*t455;
  t602 = -3.2*t447*t590;
  t603 = t115*t588;
  t604 = t408 + t603;
  t605 = -3.2*t409*t604;
  t608 = -3.2*t409*t494;
  t614 = t488*t349;
  t615 = t343*t492;
  t619 = -3.2*t498*t590;
  t650 = -0.24*t324*t325;
  t651 = t650 + t611;
  t621 = -1.*t343*t488;
  t653 = 0.24*t340*t324;
  t654 = t653 + t491;
  t623 = -1.*t492*t588;
  p_output1[0]=0;
  p_output1[1]=0;
  p_output1[2]=var2[1]*(-0.5*(-3.2*Power(t391,2) - 3.2*Power(t395,2) - 3.2*Power(t409,2) - 3.2*Power(t413,2) + t418 + t422 + t424 + t425 - 3.2*t260*t427 - 3.2*t320*t435 + t438 + t442 + t444 + t445 - 3.2*t353*t447 - 3.2*t377*t455)*var2[0] - 0.5*(t388 + t389 - 6.4*t260*t391 - 6.4*t320*t395 + t406 + t407 - 6.4*t353*t409 - 6.4*t377*t413)*var2[1] - 0.5*(2.88*t230 + t465 - 3.2*t320*t474 - 3.2*t260*t478 + t485 - 3.2*t377*t494 - 3.2*t353*t498)*var2[2] - 0.5*(t283 - 3.2*t260*t294 - 3.2*t314*t320)*var2[3] + 0.384*t260*var2[4] - 0.5*(t358 - 3.2*t353*t367 - 3.2*t371*t377)*var2[5] + 0.384*t353*var2[6]);
  p_output1[3]=var2[1]*(t509 - 0.5*(t418 + t422 + t424 + t425 + t519 + t520 + t521 + t524)*var2[0] - 0.5*(t388 + t389 + t515 + t516)*var2[1] - 0.5*(t465 + t527 - 3.2*t391*(t317*t472 + t255*t531 + t535 + t540) + t544 - 3.2*t395*(-1.*t255*t472 - 1.*t177*t531 + t546 + t548))*var2[2] - 0.5*(t283 + t510 + t511)*var2[3]);
  p_output1[4]=var2[1]*(t509 - 0.5*(t519 + t520 + t521 + t524)*var2[0] - 0.5*(t515 + t516)*var2[1] - 0.5*(t527 + t544 - 3.2*t395*(t546 + t548 - 1.*t177*t571 - 1.*t255*t574) - 3.2*t391*(t535 + t540 + t255*t571 + t317*t574))*var2[2] - 0.5*(-3.2*(0.24*t137*t166 - 1.*t166*t288)*t391 - 3.2*(-0.24*Power(t137,2) + t289)*t395 + t510 + t511)*var2[3]);
  p_output1[5]=var2[1]*(t591 - 0.5*(t438 + t442 + t444 + t445 + t600 + t601 + t602 + t605)*var2[0] - 0.5*(t406 + t407 + t596 + t597)*var2[1] - 0.5*(t485 + t608 - 3.2*t409*(t374*t492 + t349*t612 + t614 + t615) + t619 - 3.2*t413*(-1.*t349*t492 - 1.*t343*t612 + t621 + t623))*var2[2] - 0.5*(t358 + t592 + t593)*var2[5]);
  p_output1[6]=var2[1]*(t591 - 0.5*(t600 + t601 + t602 + t605)*var2[0] - 0.5*(t596 + t597)*var2[1] - 0.5*(t608 + t619 - 3.2*t413*(t621 + t623 - 1.*t343*t651 - 1.*t349*t654) - 3.2*t409*(t614 + t615 + t349*t651 + t374*t654))*var2[2] - 0.5*(-3.2*(0.24*t324*t341 - 1.*t341*t363)*t409 - 3.2*(-0.24*Power(t324,2) + t364)*t413 + t592 + t593)*var2[5]);
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce3_vec2_five_link_walker.hh"

namespace RightStance
{

void Ce3_vec2_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
