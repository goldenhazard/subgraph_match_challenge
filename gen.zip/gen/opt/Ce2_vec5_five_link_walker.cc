/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:46 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t7639;
  double t3453;
  double t3996;
  double t8254;
  double t8322;
  double t7335;
  double t8289;
  double t8290;
  double t1002;
  double t10655;
  double t10656;
  double t10949;
  double t11010;
  double t11058;
  double t11069;
  double t11070;
  double t11071;
  double t11072;
  double t11074;
  double t11075;
  double t11104;
  double t8321;
  double t10336;
  double t10495;
  double t10605;
  double t10607;
  double t10653;
  double t11108;
  double t11109;
  double t11110;
  double t11111;
  double t11112;
  double t11113;
  double t11132;
  double t11133;
  double t11146;
  double t11147;
  double t11148;
  double t11150;
  double t11154;
  double t11155;
  double t11160;
  double t11161;
  double t11162;
  double t11167;
  double t11168;
  double t11137;
  double t11139;
  double t11141;
  double t11105;
  double t11106;
  double t11107;
  double t11129;
  double t11130;
  double t11061;
  double t11062;
  double t11063;
  double t11089;
  double t11092;
  double t11094;
  double t11117;
  double t11118;
  double t11119;
  double t11131;
  double t11134;
  double t11142;
  double t11143;
  double t11144;
  double t11149;
  double t11156;
  double t11157;
  double t11163;
  double t11165;
  double t11166;
  double t11169;
  double t11170;
  double t11172;
  double t11173;
  double t11174;
  double t11176;
  double t11177;
  double t11178;
  double t11179;
  double t11180;
  double t11205;
  double t11206;
  double t11208;
  double t11211;
  double t11214;
  double t11159;
  double t11171;
  double t11175;
  double t11181;
  double t11183;
  double t11192;
  double t11193;
  double t11194;
  double t11195;
  double t11197;
  double t11078;
  double t11095;
  double t11116;
  double t11120;
  double t11122;
  double t11223;
  double t11224;
  double t11227;
  double t11231;
  double t11232;
  t7639 = Cos(var1[3]);
  t3453 = Cos(var1[4]);
  t3996 = Sin(var1[3]);
  t8254 = Sin(var1[4]);
  t8322 = Sin(var1[2]);
  t7335 = -1.*t3453*t3996;
  t8289 = -1.*t7639*t8254;
  t8290 = t7335 + t8289;
  t1002 = Cos(var1[2]);
  t10655 = -1.*t3453;
  t10656 = 1. + t10655;
  t10949 = 0.4*t10656;
  t11010 = 0.64*t3453;
  t11058 = t10949 + t11010;
  t11069 = t8322*t8290;
  t11070 = t7639*t3453;
  t11071 = -1.*t3996*t8254;
  t11072 = t11070 + t11071;
  t11074 = t1002*t11072;
  t11075 = t11069 + t11074;
  t11104 = t11058*t3453;
  t8321 = t1002*t8290;
  t10336 = -1.*t7639*t3453;
  t10495 = t3996*t8254;
  t10605 = t10336 + t10495;
  t10607 = t8322*t10605;
  t10653 = t8321 + t10607;
  t11108 = t3453*t3996;
  t11109 = t7639*t8254;
  t11110 = t11108 + t11109;
  t11111 = t1002*t11110;
  t11112 = t8322*t11072;
  t11113 = t11111 + t11112;
  t11132 = -1.*t8322*t11072;
  t11133 = t8321 + t11132;
  t11146 = t11058*t3996;
  t11147 = 0.24*t7639*t8254;
  t11148 = t11146 + t11147;
  t11150 = t7639*t11058;
  t11154 = -0.24*t3996*t8254;
  t11155 = t11150 + t11154;
  t11160 = -0.24*t3453*t3996;
  t11161 = -0.24*t7639*t8254;
  t11162 = t11160 + t11161;
  t11167 = 0.24*t7639*t3453;
  t11168 = t11167 + t11154;
  t11137 = -1.*t8322*t8290;
  t11139 = t1002*t10605;
  t11141 = t11137 + t11139;
  t11105 = Power(t3453,2);
  t11106 = -0.24*t11105;
  t11107 = t11104 + t11106;
  t11129 = -1.*t8322*t11110;
  t11130 = t11129 + t11074;
  t11061 = t11058*t8254;
  t11062 = -0.24*t3453*t8254;
  t11063 = t11061 + t11062;
  t11089 = -1.*t11058*t8254;
  t11092 = 0.24*t3453*t8254;
  t11094 = t11089 + t11092;
  t11117 = Power(t8254,2);
  t11118 = 0.24*t11117;
  t11119 = t11104 + t11118;
  t11131 = 3.2*t11075*t11130;
  t11134 = 3.2*t11133*t11113;
  t11142 = 3.2*t11075*t11141;
  t11143 = 3.2*t11133*t10653;
  t11144 = t11131 + t11134 + t11142 + t11143;
  t11149 = -1.*t11148*t11072;
  t11156 = -1.*t8290*t11155;
  t11157 = t11149 + t11156;
  t11163 = t11162*t11072;
  t11165 = t11148*t11072;
  t11166 = t8290*t11155;
  t11169 = t11110*t11168;
  t11170 = t11163 + t11165 + t11166 + t11169;
  t11172 = t11148*t11110;
  t11173 = t11072*t11155;
  t11174 = t11172 + t11173;
  t11176 = -1.*t8290*t11162;
  t11177 = -1.*t8290*t11148;
  t11178 = -1.*t11072*t11168;
  t11179 = -1.*t11155*t10605;
  t11180 = t11176 + t11177 + t11178 + t11179;
  t11205 = 3.2*t11133*t11157;
  t11206 = 3.2*t11133*t11170;
  t11208 = 3.2*t11174*t11141;
  t11211 = 3.2*t11130*t11180;
  t11214 = t11205 + t11206 + t11208 + t11211;
  t11159 = 3.2*t11075*t11157;
  t11171 = 3.2*t11075*t11170;
  t11175 = 3.2*t11174*t10653;
  t11181 = 3.2*t11113*t11180;
  t11183 = t11159 + t11171 + t11175 + t11181;
  t11192 = 3.2*t11107*t11130;
  t11193 = 3.2*t11063*t11133;
  t11194 = 3.2*t11094*t11133;
  t11195 = 3.2*t11119*t11141;
  t11197 = t11192 + t11193 + t11194 + t11195;
  t11078 = 3.2*t11063*t11075;
  t11095 = 3.2*t11094*t11075;
  t11116 = 3.2*t11107*t11113;
  t11120 = 3.2*t11119*t10653;
  t11122 = t11078 + t11095 + t11116 + t11120;
  t11223 = 3.2*t11107*t11157;
  t11224 = 3.2*t11094*t11174;
  t11227 = 3.2*t11119*t11170;
  t11231 = 3.2*t11063*t11180;
  t11232 = t11223 + t11224 + t11227 + t11231;
  p_output1[0]=var2[4]*(-0.5*(6.4*t10653*t11075 + 6.4*t11075*t11113)*var2[0] - 0.5*t11144*var2[1] - 0.5*t11183*var2[2] - 0.5*t11122*var2[3] - 0.384*t10653*var2[4]);
  p_output1[1]=var2[4]*(-0.5*t11144*var2[0] - 0.5*(6.4*t11130*t11133 + 6.4*t11133*t11141)*var2[1] - 0.5*t11214*var2[2] - 0.5*t11197*var2[3] - 0.384*t11141*var2[4]);
  p_output1[2]=var2[4]*(-0.5*t11183*var2[0] - 0.5*t11214*var2[1] - 0.5*(6.4*t11170*t11174 + 6.4*t11157*t11180)*var2[2] - 0.5*t11232*var2[3] - 0.384*t11170*var2[4]);
  p_output1[3]=var2[4]*(-0.5*t11122*var2[0] - 0.5*t11197*var2[1] - 0.5*t11232*var2[2] - 0.5*(6.4*t11063*t11107 + 6.4*t11094*t11119)*var2[3] - 0.384*t11094*var2[4]);
  p_output1[4]=(-0.384*t10653*var2[0] - 0.384*t11141*var2[1] - 0.384*t11170*var2[2] - 0.384*t11094*var2[3])*var2[4];
  p_output1[5]=0;
  p_output1[6]=0;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce2_vec5_five_link_walker.hh"

namespace RightStance
{

void Ce2_vec5_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
