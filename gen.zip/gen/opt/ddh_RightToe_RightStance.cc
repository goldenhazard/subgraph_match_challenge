/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:32:54 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2,const double *var3,const double *var4)
{
  double t17673;
  double t17670;
  double t17671;
  double t17674;
  double t17664;
  double t17672;
  double t17675;
  double t17683;
  double t17685;
  double t17686;
  double t17687;
  double t17688;
  double t17665;
  double t17669;
  double t17712;
  double t17713;
  double t17714;
  double t17711;
  double t17715;
  double t17716;
  double t17717;
  double t17718;
  double t17719;
  double t17720;
  double t17725;
  double t17726;
  double t17727;
  double t17728;
  double t17729;
  double t17730;
  double t17733;
  double t17734;
  double t17735;
  double t17736;
  double t17737;
  double t17738;
  double t17739;
  double t17752;
  double t17753;
  double t17754;
  double t17751;
  double t17755;
  double t17756;
  double t17757;
  double t17758;
  double t17759;
  double t17750;
  double t17760;
  double t17761;
  double t17762;
  double t17772;
  double t17774;
  double t17779;
  double t17780;
  double t17781;
  double t17782;
  double t17783;
  double t17789;
  double t17790;
  double t17791;
  double t17792;
  double t17793;
  double t17794;
  double t17788;
  double t17795;
  double t17796;
  double t17797;
  t17673 = Cos(var1[2]);
  t17670 = Cos(var1[3]);
  t17671 = Sin(var1[2]);
  t17674 = Sin(var1[3]);
  t17664 = Cos(var1[4]);
  t17672 = t17670*t17671;
  t17675 = t17673*t17674;
  t17683 = t17672 + t17675;
  t17685 = t17673*t17670;
  t17686 = -1.*t17671*t17674;
  t17687 = t17685 + t17686;
  t17688 = Sin(var1[4]);
  t17665 = -1.*t17664;
  t17669 = 1. + t17665;
  t17712 = -1.*t17670*t17671;
  t17713 = -1.*t17673*t17674;
  t17714 = t17712 + t17713;
  t17711 = 0.4*t17669*t17687;
  t17715 = -0.4*t17714*t17688;
  t17716 = t17664*t17687;
  t17717 = t17714*t17688;
  t17718 = t17716 + t17717;
  t17719 = 0.8*t17718;
  t17720 = t17711 + t17715 + t17719;
  t17725 = -0.4*t17664*t17687;
  t17726 = 0.4*t17683*t17688;
  t17727 = -1.*t17683*t17688;
  t17728 = t17716 + t17727;
  t17729 = 0.8*t17728;
  t17730 = t17725 + t17726 + t17729;
  t17733 = -0.4*t17664*t17714;
  t17734 = 0.4*t17687*t17688;
  t17735 = t17664*t17714;
  t17736 = -1.*t17687*t17688;
  t17737 = t17735 + t17736;
  t17738 = 0.8*t17737;
  t17739 = t17733 + t17734 + t17738;
  t17752 = -1.*t17673*t17670;
  t17753 = t17671*t17674;
  t17754 = t17752 + t17753;
  t17751 = 0.4*t17669*t17714;
  t17755 = -0.4*t17754*t17688;
  t17756 = t17754*t17688;
  t17757 = t17735 + t17756;
  t17758 = 0.8*t17757;
  t17759 = t17751 + t17755 + t17758;
  t17750 = var2[4]*t17739;
  t17760 = var2[2]*t17759;
  t17761 = var2[3]*t17759;
  t17762 = t17750 + t17760 + t17761;
  t17772 = 0.4*t17714*t17688;
  t17774 = -1.*t17714*t17688;
  t17779 = -0.4*t17664*t17754;
  t17780 = t17664*t17754;
  t17781 = t17780 + t17774;
  t17782 = 0.8*t17781;
  t17783 = t17779 + t17772 + t17782;
  t17789 = 0.4*t17669*t17754;
  t17790 = -0.4*t17683*t17688;
  t17791 = t17683*t17688;
  t17792 = t17780 + t17791;
  t17793 = 0.8*t17792;
  t17794 = t17789 + t17790 + t17793;
  t17788 = var2[4]*t17783;
  t17795 = var2[2]*t17794;
  t17796 = var2[3]*t17794;
  t17797 = t17788 + t17795 + t17796;
  p_output1[0]=0.4*t17669*t17683 - 0.4*t17687*t17688 + 0.8*(t17664*t17683 + t17687*t17688) + var1[0] + var2[0] + t17720*var2[2] + t17762*var2[2] + t17720*var2[3] + t17762*var2[3] + t17730*var2[4] + var2[4]*(t17739*var2[2] + t17739*var2[3] + (0.4*t17664*t17683 + t17734 + 0.8*(-1.*t17664*t17683 + t17736))*var2[4]) + var3[0] + t17720*var3[2] + t17720*var3[3] + t17730*var3[4] - 1.*var4[0];
  p_output1[1]=-1.*var4[1];
  p_output1[2]=t17711 + t17715 + t17719 + t17750 + t17760 + t17761 + var1[1] + var2[1] + t17797*var2[2] + t17797*var2[3] + var2[4]*(t17783*var2[2] + t17783*var2[3] + (0.4*t17664*t17687 + t17772 + 0.8*(-1.*t17664*t17687 + t17774))*var2[4]) + var3[1] + t17759*var3[2] + t17759*var3[3] + t17739*var3[4] - 1.*var4[2];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2,*var3,*var4;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 4)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Four input(s) required (var1,var2,var3,var4).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }
  mrows = mxGetM(prhs[2]);
  ncols = mxGetN(prhs[2]);
  if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var3 is wrong.");
    }
  mrows = mxGetM(prhs[3]);
  ncols = mxGetN(prhs[3]);
  if( !mxIsDouble(prhs[3]) || mxIsComplex(prhs[3]) ||
    ( !(mrows == 3 && ncols == 1) && 
      !(mrows == 1 && ncols == 3))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var4 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
  var3 = mxGetPr(prhs[2]);
  var4 = mxGetPr(prhs[3]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 3, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2,var3,var4);


}

#else // MATLAB_MEX_FILE

#include "ddh_RightToe_RightStance.hh"

namespace RightStance
{

void ddh_RightToe_RightStance_raw(double *p_output1, const double *var1,const double *var2,const double *var3,const double *var4)
{
  // Call Subroutines
  output1(p_output1, var1, var2, var3, var4);

}

}

#endif // MATLAB_MEX_FILE
