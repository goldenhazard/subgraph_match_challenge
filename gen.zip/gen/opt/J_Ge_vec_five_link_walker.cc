/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:32:31 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t10030;
  double t10037;
  double t10038;
  double t10039;
  double t10040;
  double t10068;
  double t10069;
  double t10083;
  double t10202;
  double t10203;
  double t10205;
  double t10206;
  double t17358;
  double t17365;
  double t17371;
  double t17372;
  double t17376;
  double t17385;
  double t17393;
  double t17395;
  double t17396;
  double t17401;
  double t10078;
  double t10084;
  double t10155;
  double t10198;
  double t10208;
  double t10226;
  double t10309;
  double t10479;
  double t10480;
  double t11133;
  double t17357;
  double t17472;
  double t17473;
  double t17474;
  double t17380;
  double t17386;
  double t17391;
  double t17392;
  double t17456;
  double t17457;
  double t17461;
  double t17462;
  double t17463;
  double t17464;
  double t17465;
  double t17483;
  double t17484;
  double t17485;
  double t17470;
  double t17471;
  double t17475;
  double t17476;
  double t17477;
  double t17478;
  double t17479;
  double t17480;
  double t17500;
  double t17501;
  double t17502;
  double t17481;
  double t17482;
  double t17487;
  double t17488;
  double t17489;
  double t17490;
  double t17493;
  double t17496;
  double t17512;
  double t17513;
  double t17514;
  t10030 = Cos(var1[2]);
  t10037 = Cos(var1[3]);
  t10038 = -1.*t10030*t10037;
  t10039 = Sin(var1[2]);
  t10040 = Sin(var1[3]);
  t10068 = t10039*t10040;
  t10069 = t10038 + t10068;
  t10083 = Cos(var1[4]);
  t10202 = t10037*t10039;
  t10203 = t10030*t10040;
  t10205 = t10202 + t10203;
  t10206 = Sin(var1[4]);
  t17358 = Cos(var1[5]);
  t17365 = -1.*t10030*t17358;
  t17371 = Sin(var1[5]);
  t17372 = t10039*t17371;
  t17376 = t17365 + t17372;
  t17385 = Cos(var1[6]);
  t17393 = t17358*t10039;
  t17395 = t10030*t17371;
  t17396 = t17393 + t17395;
  t17401 = Sin(var1[6]);
  t10078 = -7.33788*t10069;
  t10084 = -1.*t10083;
  t10155 = 1. + t10084;
  t10198 = 0.4*t10155*t10069;
  t10208 = -0.4*t10205*t10206;
  t10226 = t10083*t10069;
  t10309 = t10205*t10206;
  t10479 = t10226 + t10309;
  t10480 = 0.64*t10479;
  t11133 = t10198 + t10208 + t10480;
  t17357 = -31.392000000000003*t11133;
  t17472 = -1.*t10037*t10039;
  t17473 = -1.*t10030*t10040;
  t17474 = t17472 + t17473;
  t17380 = -7.33788*t17376;
  t17386 = -1.*t17385;
  t17391 = 1. + t17386;
  t17392 = 0.4*t17391*t17376;
  t17456 = -0.4*t17396*t17401;
  t17457 = t17385*t17376;
  t17461 = t17396*t17401;
  t17462 = t17457 + t17461;
  t17463 = 0.64*t17462;
  t17464 = t17392 + t17456 + t17463;
  t17465 = -31.392000000000003*t17464;
  t17483 = -1.*t17358*t10039;
  t17484 = -1.*t10030*t17371;
  t17485 = t17483 + t17484;
  t17470 = t10078 + t17357;
  t17471 = -0.4*t10083*t10069;
  t17475 = 0.4*t17474*t10206;
  t17476 = -1.*t17474*t10206;
  t17477 = t10226 + t17476;
  t17478 = 0.64*t17477;
  t17479 = t17471 + t17475 + t17478;
  t17480 = -31.392000000000003*t17479;
  t17500 = t10030*t10037;
  t17501 = -1.*t10039*t10040;
  t17502 = t17500 + t17501;
  t17481 = t17380 + t17465;
  t17482 = -0.4*t17385*t17376;
  t17487 = 0.4*t17485*t17401;
  t17488 = -1.*t17485*t17401;
  t17489 = t17457 + t17488;
  t17490 = 0.64*t17489;
  t17493 = t17482 + t17487 + t17490;
  t17496 = -31.392000000000003*t17493;
  t17512 = t10030*t17358;
  t17513 = -1.*t10039*t17371;
  t17514 = t17512 + t17513;
  p_output1[0]=28.252799999999997*t10030 + t10078 + t17357 + t17380 + t17465;
  p_output1[1]=t17470;
  p_output1[2]=t17480;
  p_output1[3]=t17481;
  p_output1[4]=t17496;
  p_output1[5]=t17470;
  p_output1[6]=t17470;
  p_output1[7]=t17480;
  p_output1[8]=t17480;
  p_output1[9]=t17480;
  p_output1[10]=-31.392000000000003*(t17475 + 0.4*t10083*t17502 + 0.64*(t17476 - 1.*t10083*t17502));
  p_output1[11]=t17481;
  p_output1[12]=t17481;
  p_output1[13]=t17496;
  p_output1[14]=t17496;
  p_output1[15]=t17496;
  p_output1[16]=-31.392000000000003*(t17487 + 0.4*t17385*t17514 + 0.64*(t17488 - 1.*t17385*t17514));
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 17, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ge_vec_five_link_walker.hh"

namespace RightStance
{

void J_Ge_vec_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
