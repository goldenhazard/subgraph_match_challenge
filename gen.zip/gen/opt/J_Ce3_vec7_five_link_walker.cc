/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:32:27 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t9971;
  double t1647;
  double t8537;
  double t9975;
  double t10024;
  double t9969;
  double t9983;
  double t10020;
  double t1634;
  double t10025;
  double t10026;
  double t10027;
  double t10023;
  double t10031;
  double t10041;
  double t10042;
  double t10043;
  double t10044;
  double t10045;
  double t10046;
  double t10047;
  double t10048;
  double t10062;
  double t10063;
  double t10064;
  double t10028;
  double t10029;
  double t10065;
  double t10066;
  double t10067;
  double t10100;
  double t10101;
  double t10102;
  double t10109;
  double t10110;
  double t10149;
  double t10150;
  double t10151;
  double t10152;
  double t10153;
  double t10154;
  double t10199;
  double t10200;
  double t10201;
  double t10103;
  double t10104;
  double t10105;
  double t10106;
  double t10107;
  double t10108;
  double t10156;
  double t10157;
  double t10158;
  double t10159;
  double t11157;
  double t11205;
  double t10204;
  double t10207;
  double t17307;
  double t17308;
  double t17309;
  double t17355;
  double t17356;
  double t17301;
  double t17304;
  double t11151;
  double t11580;
  double t11613;
  double t11624;
  double t11694;
  double t11697;
  double t11700;
  double t11703;
  double t12169;
  double t12694;
  double t13357;
  double t13358;
  double t17288;
  double t17300;
  double t17305;
  double t17306;
  double t17402;
  double t17403;
  double t17404;
  double t17397;
  double t17399;
  double t17400;
  double t17359;
  double t17364;
  t9971 = Cos(var1[5]);
  t1647 = Cos(var1[6]);
  t8537 = Sin(var1[5]);
  t9975 = Sin(var1[6]);
  t10024 = Cos(var1[2]);
  t9969 = -1.*t1647*t8537;
  t9983 = -1.*t9971*t9975;
  t10020 = t9969 + t9983;
  t1634 = Sin(var1[2]);
  t10025 = t9971*t1647;
  t10026 = -1.*t8537*t9975;
  t10027 = t10025 + t10026;
  t10023 = -1.*t1634*t10020;
  t10031 = -1.*t10024*t10020;
  t10041 = -1.*t9971*t1647;
  t10042 = t8537*t9975;
  t10043 = t10041 + t10042;
  t10044 = t10024*t10043;
  t10045 = t10023 + t10044;
  t10046 = 0.384*var2[0]*t10045;
  t10047 = -1.*t1634*t10043;
  t10048 = t10031 + t10047;
  t10062 = 0.384*var2[1]*t10048;
  t10063 = t10046 + t10062;
  t10064 = var2[6]*t10063;
  t10028 = -1.*t10024*t10027;
  t10029 = t10023 + t10028;
  t10065 = t10024*t10020;
  t10066 = -1.*t1634*t10027;
  t10067 = t10065 + t10066;
  t10100 = t1647*t8537;
  t10101 = t9971*t9975;
  t10102 = t10100 + t10101;
  t10109 = -1.*t1647;
  t10110 = 1. + t10109;
  t10149 = 0.4*t10110;
  t10150 = 0.64*t1647;
  t10151 = t10149 + t10150;
  t10152 = -1.*t10151*t8537;
  t10153 = -0.24*t9971*t9975;
  t10154 = t10152 + t10153;
  t10199 = t9971*t10151;
  t10200 = -0.24*t8537*t9975;
  t10201 = t10199 + t10200;
  t10103 = t1634*t10102;
  t10104 = t10103 + t10044;
  t10105 = 0.384*var2[0]*t10104;
  t10106 = t10024*t10102;
  t10107 = t10106 + t10047;
  t10108 = 0.384*var2[1]*t10107;
  t10156 = t10151*t8537;
  t10157 = 0.24*t9971*t9975;
  t10158 = t10156 + t10157;
  t10159 = t10020*t10158;
  t11157 = -0.24*t1647*t8537;
  t11205 = t11157 + t10153;
  t10204 = 0.24*t8537*t9975;
  t10207 = t10201*t10043;
  t17307 = t10154*t10027;
  t17308 = t10158*t10027;
  t17309 = t10020*t10201;
  t17355 = t10102*t10201;
  t17356 = t17307 + t17308 + t17309 + t17355;
  t17301 = t1634*t10043;
  t17304 = t10065 + t17301;
  t11151 = t10020*t10154;
  t11580 = t10020*t11205;
  t11613 = t11205*t10102;
  t11624 = t10027*t10201;
  t11694 = 0.24*t9971*t1647;
  t11697 = t11694 + t10200;
  t11700 = t10027*t11697;
  t11703 = -0.24*t9971*t1647;
  t12169 = t11703 + t10204;
  t12694 = t10027*t12169;
  t13357 = t11151 + t11580 + t10159 + t11613 + t11624 + t11700 + t12694 + t10207;
  t13358 = 0.384*var2[2]*t13357;
  t17288 = t10105 + t10108 + t13358;
  t17300 = var2[6]*t17288;
  t17305 = 0.384*var2[6]*t17304;
  t17306 = 0.384*var2[6]*t10045;
  t17402 = -1.*t10151*t9975;
  t17403 = 0.24*t1647*t9975;
  t17404 = t17402 + t17403;
  t17397 = t11205*t10027;
  t17399 = t10102*t11697;
  t17400 = t17397 + t17308 + t17309 + t17399;
  t17359 = 0.384*var2[1]*t10045;
  t17364 = 0.384*var2[0]*t17304;
  p_output1[0]=(0.384*t10029*var2[0] + 0.384*(t10031 + t10027*t1634)*var2[1])*var2[6];
  p_output1[1]=t10064;
  p_output1[2]=t10064;
  p_output1[3]=0.384*t10067*var2[6];
  p_output1[4]=0.384*t10029*var2[6];
  p_output1[5]=0.384*t10067*var2[0] + 0.384*t10029*var2[1];
  p_output1[6]=t10064;
  p_output1[7]=(t10105 + t10108 + 0.384*(2.*t10020*t10154 + t10102*t10154 + t10159 + 2.*t10027*t10201 + t10207 + t10027*(t10204 - 1.*t10151*t9971))*var2[2])*var2[6];
  p_output1[8]=t17300;
  p_output1[9]=t17305;
  p_output1[10]=t17306;
  p_output1[11]=0.384*t17356*var2[6];
  p_output1[12]=t17359 + t17364 + 0.384*t17356*var2[2];
  p_output1[13]=t10064;
  p_output1[14]=t17300;
  p_output1[15]=(t10105 + t10108 + 0.384*(t10159 + t10207 + 2.*t10020*t11205 + t11613 + 2.*t10027*t11697 + t12694)*var2[2] + 0.384*(-1.*t10151*t1647 + 0.24*Power(t1647,2))*var2[5])*var2[6];
  p_output1[16]=t17305;
  p_output1[17]=t17306;
  p_output1[18]=0.384*t17400*var2[6];
  p_output1[19]=0.384*t17404*var2[6];
  p_output1[20]=t17359 + t17364 + 0.384*t17400*var2[2] + 0.384*t17404*var2[5];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 21, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce3_vec7_five_link_walker.hh"

namespace RightStance
{

void J_Ce3_vec7_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
