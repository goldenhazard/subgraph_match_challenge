/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:32:20 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t10743;
  double t1676;
  double t1689;
  double t11186;
  double t11748;
  double t8012;
  double t11252;
  double t11543;
  double t1612;
  double t11943;
  double t12543;
  double t12649;
  double t11577;
  double t12747;
  double t16915;
  double t16916;
  double t16918;
  double t16924;
  double t16925;
  double t16976;
  double t16977;
  double t16990;
  double t16994;
  double t16999;
  double t17000;
  double t12652;
  double t12741;
  double t17005;
  double t17006;
  double t17007;
  double t17025;
  double t17026;
  double t17032;
  double t17194;
  double t17195;
  double t17199;
  double t17200;
  double t17201;
  double t17202;
  double t17203;
  double t17204;
  double t17211;
  double t17212;
  double t17213;
  double t17033;
  double t17183;
  double t17184;
  double t17191;
  double t17192;
  double t17193;
  double t17206;
  double t17207;
  double t17208;
  double t17209;
  double t17241;
  double t17242;
  double t17220;
  double t17228;
  double t17271;
  double t17272;
  double t17273;
  double t17274;
  double t17275;
  double t17267;
  double t17268;
  double t17240;
  double t17246;
  double t17247;
  double t17248;
  double t17249;
  double t17250;
  double t17251;
  double t17252;
  double t17253;
  double t17254;
  double t17258;
  double t17259;
  double t17265;
  double t17266;
  double t17269;
  double t17270;
  double t17296;
  double t17297;
  double t17298;
  double t17292;
  double t17293;
  double t17294;
  double t17278;
  double t17279;
  t10743 = Cos(var1[3]);
  t1676 = Cos(var1[4]);
  t1689 = Sin(var1[3]);
  t11186 = Sin(var1[4]);
  t11748 = Cos(var1[2]);
  t8012 = -1.*t1676*t1689;
  t11252 = -1.*t10743*t11186;
  t11543 = t8012 + t11252;
  t1612 = Sin(var1[2]);
  t11943 = t10743*t1676;
  t12543 = -1.*t1689*t11186;
  t12649 = t11943 + t12543;
  t11577 = -1.*t1612*t11543;
  t12747 = -1.*t11748*t11543;
  t16915 = -1.*t10743*t1676;
  t16916 = t1689*t11186;
  t16918 = t16915 + t16916;
  t16924 = t11748*t16918;
  t16925 = t11577 + t16924;
  t16976 = 0.384*var2[0]*t16925;
  t16977 = -1.*t1612*t16918;
  t16990 = t12747 + t16977;
  t16994 = 0.384*var2[1]*t16990;
  t16999 = t16976 + t16994;
  t17000 = var2[4]*t16999;
  t12652 = -1.*t11748*t12649;
  t12741 = t11577 + t12652;
  t17005 = t11748*t11543;
  t17006 = -1.*t1612*t12649;
  t17007 = t17005 + t17006;
  t17025 = t1676*t1689;
  t17026 = t10743*t11186;
  t17032 = t17025 + t17026;
  t17194 = -1.*t1676;
  t17195 = 1. + t17194;
  t17199 = 0.4*t17195;
  t17200 = 0.64*t1676;
  t17201 = t17199 + t17200;
  t17202 = -1.*t17201*t1689;
  t17203 = -0.24*t10743*t11186;
  t17204 = t17202 + t17203;
  t17211 = t10743*t17201;
  t17212 = -0.24*t1689*t11186;
  t17213 = t17211 + t17212;
  t17033 = t1612*t17032;
  t17183 = t17033 + t16924;
  t17184 = 0.384*var2[0]*t17183;
  t17191 = t11748*t17032;
  t17192 = t17191 + t16977;
  t17193 = 0.384*var2[1]*t17192;
  t17206 = t17201*t1689;
  t17207 = 0.24*t10743*t11186;
  t17208 = t17206 + t17207;
  t17209 = t11543*t17208;
  t17241 = -0.24*t1676*t1689;
  t17242 = t17241 + t17203;
  t17220 = 0.24*t1689*t11186;
  t17228 = t17213*t16918;
  t17271 = t17204*t12649;
  t17272 = t17208*t12649;
  t17273 = t11543*t17213;
  t17274 = t17032*t17213;
  t17275 = t17271 + t17272 + t17273 + t17274;
  t17267 = t1612*t16918;
  t17268 = t17005 + t17267;
  t17240 = t11543*t17204;
  t17246 = t11543*t17242;
  t17247 = t17242*t17032;
  t17248 = t12649*t17213;
  t17249 = 0.24*t10743*t1676;
  t17250 = t17249 + t17212;
  t17251 = t12649*t17250;
  t17252 = -0.24*t10743*t1676;
  t17253 = t17252 + t17220;
  t17254 = t12649*t17253;
  t17258 = t17240 + t17246 + t17209 + t17247 + t17248 + t17251 + t17254 + t17228;
  t17259 = 0.384*var2[2]*t17258;
  t17265 = t17184 + t17193 + t17259;
  t17266 = var2[4]*t17265;
  t17269 = 0.384*var2[4]*t17268;
  t17270 = 0.384*var2[4]*t16925;
  t17296 = -1.*t17201*t11186;
  t17297 = 0.24*t1676*t11186;
  t17298 = t17296 + t17297;
  t17292 = t17242*t12649;
  t17293 = t17032*t17250;
  t17294 = t17292 + t17272 + t17273 + t17293;
  t17278 = 0.384*var2[1]*t16925;
  t17279 = 0.384*var2[0]*t17268;
  p_output1[0]=(0.384*t12741*var2[0] + 0.384*(t12747 + t12649*t1612)*var2[1])*var2[4];
  p_output1[1]=t17000;
  p_output1[2]=t17000;
  p_output1[3]=0.384*t17007*var2[4];
  p_output1[4]=0.384*t12741*var2[4];
  p_output1[5]=0.384*t17007*var2[0] + 0.384*t12741*var2[1];
  p_output1[6]=t17000;
  p_output1[7]=(t17184 + t17193 + 0.384*(2.*t11543*t17204 + t17032*t17204 + t17209 + 2.*t12649*t17213 + t12649*(-1.*t10743*t17201 + t17220) + t17228)*var2[2])*var2[4];
  p_output1[8]=t17266;
  p_output1[9]=t17269;
  p_output1[10]=t17270;
  p_output1[11]=0.384*t17275*var2[4];
  p_output1[12]=t17278 + t17279 + 0.384*t17275*var2[2];
  p_output1[13]=t17000;
  p_output1[14]=t17266;
  p_output1[15]=(t17184 + t17193 + 0.384*(t17209 + t17228 + 2.*t11543*t17242 + t17247 + 2.*t12649*t17250 + t17254)*var2[2] + 0.384*(0.24*Power(t1676,2) - 1.*t1676*t17201)*var2[3])*var2[4];
  p_output1[16]=t17269;
  p_output1[17]=t17270;
  p_output1[18]=0.384*t17294*var2[4];
  p_output1[19]=0.384*t17298*var2[4];
  p_output1[20]=t17278 + t17279 + 0.384*t17294*var2[2] + 0.384*t17298*var2[3];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 21, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce3_vec5_five_link_walker.hh"

namespace RightStance
{

void J_Ce3_vec5_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
