/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:26 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t1607;
  double t1578;
  double t1595;
  double t1612;
  double t1650;
  double t1095;
  double t1651;
  double t1653;
  double t1654;
  double t1603;
  double t1638;
  double t1639;
  double t1646;
  double t1661;
  double t1670;
  double t3958;
  double t7710;
  double t7886;
  double t1671;
  double t1674;
  double t1676;
  double t1677;
  double t1688;
  double t1689;
  double t1695;
  double t1703;
  double t1704;
  double t1706;
  double t1707;
  double t1712;
  double t1734;
  double t1740;
  double t1806;
  double t3694;
  double t3733;
  double t7919;
  double t7931;
  double t7951;
  double t7964;
  double t7966;
  double t8068;
  double t8183;
  double t8258;
  double t8306;
  double t8317;
  double t8394;
  double t8454;
  double t8395;
  double t8460;
  double t8461;
  double t8472;
  double t8473;
  double t8476;
  double t8478;
  double t8507;
  double t8508;
  double t8510;
  double t8471;
  double t8481;
  double t8534;
  double t8598;
  double t8599;
  double t8484;
  double t8104;
  double t8207;
  double t8256;
  double t8344;
  double t8366;
  double t8368;
  double t8377;
  double t8391;
  double t8625;
  double t8628;
  double t8631;
  double t8647;
  double t8650;
  double t8651;
  double t8652;
  double t8054;
  double t8055;
  double t8012;
  double t8045;
  double t8661;
  double t8670;
  double t8672;
  double t8678;
  double t8682;
  double t8685;
  double t8686;
  double t9515;
  double t9526;
  double t9535;
  double t9578;
  double t9641;
  double t9654;
  double t9658;
  double t9660;
  double t9663;
  double t8526;
  double t8528;
  double t8487;
  double t8492;
  double t13382;
  double t13346;
  double t13347;
  double t13356;
  double t13357;
  double t13358;
  double t13360;
  double t13365;
  double t13366;
  double t13379;
  double t13431;
  double t13435;
  double t13437;
  double t13438;
  double t13448;
  double t13453;
  double t13489;
  double t13490;
  double t13500;
  double t13501;
  double t13508;
  double t13509;
  double t13510;
  double t13511;
  double t13517;
  double t13524;
  double t13527;
  double t13540;
  double t13547;
  double t13548;
  double t13516;
  double t13528;
  double t13529;
  double t13539;
  double t13550;
  double t13555;
  double t13561;
  double t13562;
  double t13563;
  double t13564;
  double t13575;
  double t13576;
  double t13566;
  double t13580;
  double t13581;
  double t13568;
  double t13462;
  double t13472;
  double t13477;
  double t13478;
  double t13485;
  double t13488;
  double t13614;
  double t13615;
  double t13616;
  double t13617;
  double t13618;
  double t13619;
  double t13626;
  double t13627;
  double t13635;
  double t13636;
  double t13637;
  double t13596;
  double t13600;
  double t13604;
  double t13608;
  double t13612;
  double t13613;
  double t13634;
  double t13638;
  double t13639;
  double t13641;
  double t13642;
  double t13643;
  double t13654;
  double t13655;
  double t13662;
  double t13647;
  double t13664;
  double t13665;
  double t13669;
  double t13679;
  double t13680;
  double t13672;
  double t13683;
  double t13684;
  double t13674;
  double t13696;
  double t13697;
  double t13698;
  double t13700;
  double t13705;
  double t13706;
  double t13707;
  double t13708;
  double t13712;
  double t13713;
  double t13733;
  double t13734;
  double t13735;
  double t13736;
  double t13739;
  double t13740;
  double t13741;
  double t13742;
  double t13746;
  double t13747;
  t1607 = Cos(var1[3]);
  t1578 = Cos(var1[4]);
  t1595 = Sin(var1[3]);
  t1612 = Sin(var1[4]);
  t1650 = Cos(var1[2]);
  t1095 = Sin(var1[2]);
  t1651 = t1607*t1578;
  t1653 = -1.*t1595*t1612;
  t1654 = t1651 + t1653;
  t1603 = -1.*t1578*t1595;
  t1638 = -1.*t1607*t1612;
  t1639 = t1603 + t1638;
  t1646 = t1095*t1639;
  t1661 = t1650*t1654;
  t1670 = t1646 + t1661;
  t3958 = t1650*t1607;
  t7710 = -1.*t1095*t1595;
  t7886 = t3958 + t7710;
  t1671 = t1578*t1595;
  t1674 = t1607*t1612;
  t1676 = t1671 + t1674;
  t1677 = t1650*t1676;
  t1688 = t1095*t1654;
  t1689 = t1677 + t1688;
  t1695 = 6.4*t1670*t1689;
  t1703 = t1650*t1639;
  t1704 = -1.*t1607*t1578;
  t1706 = t1595*t1612;
  t1707 = t1704 + t1706;
  t1712 = t1095*t1707;
  t1734 = t1703 + t1712;
  t1740 = 6.4*t1670*t1734;
  t1806 = -1.*t1607*t1095;
  t3694 = -1.*t1650*t1595;
  t3733 = t1806 + t3694;
  t7919 = 13.6*t3733*t7886;
  t7931 = t1607*t1095;
  t7951 = t1650*t1595;
  t7964 = t7931 + t7951;
  t7966 = 13.6*t7964*t7886;
  t8068 = Cos(var1[5]);
  t8183 = Sin(var1[5]);
  t8258 = t1650*t8068;
  t8306 = -1.*t1095*t8183;
  t8317 = t8258 + t8306;
  t8394 = Cos(var1[6]);
  t8454 = Sin(var1[6]);
  t8395 = -1.*t8394*t8183;
  t8460 = -1.*t8068*t8454;
  t8461 = t8395 + t8460;
  t8472 = t8068*t8394;
  t8473 = -1.*t8183*t8454;
  t8476 = t8472 + t8473;
  t8478 = t1650*t8476;
  t8507 = t8394*t8183;
  t8508 = t8068*t8454;
  t8510 = t8507 + t8508;
  t8471 = t1095*t8461;
  t8481 = t8471 + t8478;
  t8534 = t1650*t8510;
  t8598 = t1095*t8476;
  t8599 = t8534 + t8598;
  t8484 = t1650*t8461;
  t8104 = -1.*t8068*t1095;
  t8207 = -1.*t1650*t8183;
  t8256 = t8104 + t8207;
  t8344 = 13.6*t8256*t8317;
  t8366 = t8068*t1095;
  t8368 = t1650*t8183;
  t8377 = t8366 + t8368;
  t8391 = 13.6*t8377*t8317;
  t8625 = 6.4*t8481*t8599;
  t8628 = -1.*t8068*t8394;
  t8631 = t8183*t8454;
  t8647 = t8628 + t8631;
  t8650 = t1095*t8647;
  t8651 = t8484 + t8650;
  t8652 = 6.4*t8481*t8651;
  t8054 = -1.*t1095*t1676;
  t8055 = t8054 + t1661;
  t8012 = -1.*t1095*t1654;
  t8045 = t1703 + t8012;
  t8661 = 3.2*t1670*t8055;
  t8670 = 3.2*t8045*t1689;
  t8672 = -1.*t1095*t1639;
  t8678 = t1650*t1707;
  t8682 = t8672 + t8678;
  t8685 = 3.2*t1670*t8682;
  t8686 = 3.2*t8045*t1734;
  t9515 = Power(t3733,2);
  t9526 = 6.8*t9515;
  t9535 = 6.8*t3733*t7964;
  t9578 = Power(t7886,2);
  t9641 = 6.8*t9578;
  t9654 = -1.*t1650*t1607;
  t9658 = t1095*t1595;
  t9660 = t9654 + t9658;
  t9663 = 6.8*t7886*t9660;
  t8526 = -1.*t1095*t8510;
  t8528 = t8526 + t8478;
  t8487 = -1.*t1095*t8476;
  t8492 = t8484 + t8487;
  t13382 = -1.*t1095*t8461;
  t13346 = Power(t8256,2);
  t13347 = 6.8*t13346;
  t13356 = 6.8*t8256*t8377;
  t13357 = Power(t8317,2);
  t13358 = 6.8*t13357;
  t13360 = -1.*t1650*t8068;
  t13365 = t1095*t8183;
  t13366 = t13360 + t13365;
  t13379 = 6.8*t8317*t13366;
  t13431 = 3.2*t8481*t8528;
  t13435 = 3.2*t8492*t8599;
  t13437 = t1650*t8647;
  t13438 = t13382 + t13437;
  t13448 = 3.2*t8481*t13438;
  t13453 = 3.2*t8492*t8651;
  t13489 = -1.*t1578;
  t13490 = 1. + t13489;
  t13500 = 0.4*t13490;
  t13501 = 0.64*t1578;
  t13508 = t13500 + t13501;
  t13509 = t13508*t1595;
  t13510 = 0.24*t1607*t1612;
  t13511 = t13509 + t13510;
  t13517 = t1607*t13508;
  t13524 = -0.24*t1595*t1612;
  t13527 = t13517 + t13524;
  t13540 = -1.*t13508*t1595;
  t13547 = -0.24*t1607*t1612;
  t13548 = t13540 + t13547;
  t13516 = -1.*t13511*t1654;
  t13528 = -1.*t1639*t13527;
  t13529 = t13516 + t13528;
  t13539 = 3.2*t1670*t13529;
  t13550 = t13511*t1654;
  t13555 = t1639*t13527;
  t13561 = t13511*t1676;
  t13562 = t1654*t13527;
  t13563 = t13561 + t13562;
  t13564 = 3.2*t13563*t1734;
  t13575 = -0.24*t1578*t1595;
  t13576 = t13575 + t13547;
  t13566 = -1.*t1639*t13511;
  t13580 = 0.24*t1607*t1578;
  t13581 = t13580 + t13524;
  t13568 = -1.*t13527*t1707;
  t13462 = Power(t1607,2);
  t13472 = 0.11*t13462;
  t13477 = Power(t1595,2);
  t13478 = 0.11*t13477;
  t13485 = t13472 + t13478;
  t13488 = 6.8*t3733*t13485;
  t13614 = -1.*t8394;
  t13615 = 1. + t13614;
  t13616 = 0.4*t13615;
  t13617 = 0.64*t8394;
  t13618 = t13616 + t13617;
  t13619 = t13618*t8183;
  t13626 = 0.24*t8068*t8454;
  t13627 = t13619 + t13626;
  t13635 = t8068*t13618;
  t13636 = -0.24*t8183*t8454;
  t13637 = t13635 + t13636;
  t13596 = Power(t8068,2);
  t13600 = 0.11*t13596;
  t13604 = Power(t8183,2);
  t13608 = 0.11*t13604;
  t13612 = t13600 + t13608;
  t13613 = 6.8*t8256*t13612;
  t13634 = -1.*t13627*t8476;
  t13638 = -1.*t8461*t13637;
  t13639 = t13634 + t13638;
  t13641 = t13627*t8510;
  t13642 = t8476*t13637;
  t13643 = t13641 + t13642;
  t13654 = -1.*t13618*t8183;
  t13655 = -0.24*t8068*t8454;
  t13662 = t13654 + t13655;
  t13647 = 3.2*t8481*t13639;
  t13664 = t13627*t8476;
  t13665 = t8461*t13637;
  t13669 = 3.2*t13643*t8651;
  t13679 = -0.24*t8394*t8183;
  t13680 = t13679 + t13655;
  t13672 = -1.*t8461*t13627;
  t13683 = 0.24*t8068*t8394;
  t13684 = t13683 + t13636;
  t13674 = -1.*t13637*t8647;
  t13696 = 0.748*t3733;
  t13697 = t13508*t1612;
  t13698 = -0.24*t1578*t1612;
  t13700 = t13697 + t13698;
  t13705 = t13508*t1578;
  t13706 = Power(t1612,2);
  t13707 = 0.24*t13706;
  t13708 = t13705 + t13707;
  t13712 = 3.2*t13700*t1670;
  t13713 = 3.2*t13708*t1734;
  t13733 = 0.748*t8256;
  t13734 = t13618*t8454;
  t13735 = -0.24*t8394*t8454;
  t13736 = t13734 + t13735;
  t13739 = t13618*t8394;
  t13740 = Power(t8454,2);
  t13741 = 0.24*t13740;
  t13742 = t13739 + t13741;
  t13746 = 3.2*t13736*t8481;
  t13747 = 3.2*t13742*t8651;
  p_output1[0]=var2[0]*(-0.5*(t7919 + t7966 + 6.4*t1670*t8045 + 6.4*t1689*t8055 + t8344 + t8391 + 6.4*t8481*t8492 + 6.4*t8528*t8599)*var2[2] - 0.5*(t1695 + t1740 + t7919 + t7966)*var2[3] - 0.5*(t1695 + t1740)*var2[4] - 0.5*(t8344 + t8391 + t8625 + t8652)*var2[5] - 0.5*(t8625 + t8652)*var2[6]);
  p_output1[1]=var2[0]*(-0.5*(t13347 + t13356 + t13358 + t13379 + 3.2*t1689*(-1.*t1650*t1676 + t8012) + 3.2*Power(t8045,2) + 3.2*Power(t8055,2) + 3.2*(t13382 - 1.*t1650*t8476)*t8481 + 3.2*Power(t8492,2) + 3.2*Power(t8528,2) + 3.2*(t8487 - 1.*t1650*t8510)*t8599 + 3.2*t1670*(-1.*t1650*t1654 + t8672) + t9526 + t9535 + t9641 + t9663)*var2[2] - 0.5*(t8661 + t8670 + t8685 + t8686 + t9526 + t9535 + t9641 + t9663)*var2[3] - 0.5*(t8661 + t8670 + t8685 + t8686)*var2[4] - 0.5*(t13347 + t13356 + t13358 + t13379 + t13431 + t13435 + t13448 + t13453)*var2[5] - 0.5*(t13431 + t13435 + t13448 + t13453)*var2[6]);
  p_output1[2]=var2[0]*(-0.5*(-2.88*t1095 + t13488 + t13613 + 3.2*t13563*t8045 + 3.2*t13529*t8055 + 3.2*t13643*t8492 + 3.2*t13639*t8528)*var2[2] - 0.5*(t13488 + t13539 + t13564 + 3.2*t1670*(t13550 + t13555 + t13548*t1654 + t13527*t1676) + 3.2*(t13566 + t13568 - 1.*t13548*t1639 - 1.*t13527*t1654)*t1689)*var2[3] - 0.5*(t13539 + t13564 + 3.2*t1670*(t13550 + t13555 + t13576*t1654 + t13581*t1676) + 3.2*(t13566 + t13568 - 1.*t13576*t1639 - 1.*t13581*t1654)*t1689)*var2[4] - 0.5*(t13613 + t13647 + t13669 + 3.2*t8481*(t13664 + t13665 + t13662*t8476 + t13637*t8510) + 3.2*(t13672 + t13674 - 1.*t13662*t8461 - 1.*t13637*t8476)*t8599)*var2[5] - 0.5*(t13647 + t13669 + 3.2*t8481*(t13664 + t13665 + t13680*t8476 + t13684*t8510) + 3.2*(t13672 + t13674 - 1.*t13680*t8461 - 1.*t13684*t8476)*t8599)*var2[6]);
  p_output1[3]=var2[0]*(-0.5*(t13696 + 3.2*t13708*t8045 + 3.2*t13700*t8055)*var2[2] - 0.5*(t13696 + t13712 + t13713)*var2[3] - 0.5*(t13712 + t13713 + 3.2*(-1.*t13508*t1612 + 0.24*t1578*t1612)*t1670 + 3.2*(t13705 - 0.24*Power(t1578,2))*t1689)*var2[4]);
  p_output1[4]=var2[0]*(-0.384*t8045*var2[2] - 0.384*t1734*var2[3] - 0.384*t1734*var2[4]);
  p_output1[5]=var2[0]*(-0.5*(t13733 + 3.2*t13742*t8492 + 3.2*t13736*t8528)*var2[2] - 0.5*(t13733 + t13746 + t13747)*var2[5] - 0.5*(t13746 + t13747 + 3.2*(-1.*t13618*t8454 + 0.24*t8394*t8454)*t8481 + 3.2*(t13739 - 0.24*Power(t8394,2))*t8599)*var2[6]);
  p_output1[6]=var2[0]*(-0.384*t8492*var2[2] - 0.384*t8651*var2[5] - 0.384*t8651*var2[6]);
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce1_vec1_five_link_walker.hh"

namespace RightStance
{

void Ce1_vec1_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
