/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:08 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t10282;
  double t10351;
  double t10222;
  double t10352;
  double t91;
  double t10297;
  double t10359;
  double t10366;
  double t10379;
  double t10380;
  double t10381;
  double t10382;
  double t3873;
  double t3880;
  double t10393;
  double t10394;
  double t10395;
  double t10371;
  double t10383;
  double t10384;
  double t10387;
  double t10388;
  double t10389;
  double t10390;
  double t10391;
  double t10392;
  double t10398;
  double t10399;
  double t10400;
  double t10401;
  double t10405;
  double t10407;
  double t10418;
  double t10426;
  double t10428;
  double t10429;
  double t10430;
  t10282 = Cos(var1[3]);
  t10351 = Sin(var1[2]);
  t10222 = Cos(var1[2]);
  t10352 = Sin(var1[3]);
  t91 = Cos(var1[4]);
  t10297 = t10222*t10282;
  t10359 = -1.*t10351*t10352;
  t10366 = t10297 + t10359;
  t10379 = -1.*t10282*t10351;
  t10380 = -1.*t10222*t10352;
  t10381 = t10379 + t10380;
  t10382 = Sin(var1[4]);
  t3873 = -1.*t91;
  t3880 = 1. + t3873;
  t10393 = -1.*t10222*t10282;
  t10394 = t10351*t10352;
  t10395 = t10393 + t10394;
  t10371 = 0.4*t3880*t10366;
  t10383 = -0.4*t10381*t10382;
  t10384 = t91*t10366;
  t10387 = t10381*t10382;
  t10388 = t10384 + t10387;
  t10389 = 0.8*t10388;
  t10390 = t10371 + t10383 + t10389;
  t10391 = var2[0]*t10390;
  t10392 = 0.4*t3880*t10381;
  t10398 = -0.4*t10395*t10382;
  t10399 = t91*t10381;
  t10400 = t10395*t10382;
  t10401 = t10399 + t10400;
  t10405 = 0.8*t10401;
  t10407 = t10392 + t10398 + t10405;
  t10418 = var2[2]*t10407;
  t10426 = t10391 + t10418;
  t10428 = t10282*t10351;
  t10429 = t10222*t10352;
  t10430 = t10428 + t10429;
  p_output1[0]=var2[0];
  p_output1[1]=var2[2];
  p_output1[2]=t10426;
  p_output1[3]=t10426;
  p_output1[4]=(0.4*t10382*t10430 + 0.8*(t10384 - 1.*t10382*t10430) - 0.4*t10366*t91)*var2[0] + (0.4*t10366*t10382 + 0.8*(-1.*t10366*t10382 + t10399) - 0.4*t10381*t91)*var2[2];
  p_output1[5]=0;
  p_output1[6]=0;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 3 && ncols == 1) && 
      !(mrows == 1 && ncols == 3))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "fRightToe_vec_RightStance.hh"

namespace RightStance
{

void fRightToe_vec_RightStance_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
