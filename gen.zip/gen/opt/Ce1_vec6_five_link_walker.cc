/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:35 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t8433;
  double t14035;
  double t8094;
  double t8426;
  double t1089;
  double t8420;
  double t8446;
  double t14017;
  double t14018;
  double t14019;
  double t14034;
  double t14050;
  double t14061;
  double t14077;
  double t8414;
  double t8428;
  double t8429;
  double t8432;
  double t14036;
  double t14037;
  double t14043;
  double t14108;
  double t14109;
  double t14110;
  double t14079;
  double t14104;
  double t14105;
  double t14106;
  double t14107;
  double t14111;
  double t14117;
  double t14118;
  double t14119;
  double t14044;
  double t14045;
  double t14048;
  double t14120;
  double t14121;
  double t14122;
  double t14123;
  double t14124;
  double t14125;
  double t14112;
  double t14143;
  double t14144;
  double t14145;
  double t14146;
  double t14113;
  double t14147;
  double t14132;
  double t14133;
  double t14134;
  double t14049;
  double t14080;
  double t14156;
  double t14128;
  double t14129;
  double t14130;
  double t14157;
  double t14158;
  double t14159;
  double t14176;
  double t14177;
  double t14178;
  double t14168;
  double t14169;
  double t14170;
  double t14172;
  double t14173;
  double t14174;
  double t14175;
  double t14179;
  double t14199;
  double t14200;
  double t14184;
  double t14202;
  double t14203;
  double t14186;
  t8433 = Cos(var1[6]);
  t14035 = Sin(var1[6]);
  t8094 = Sin(var1[2]);
  t8426 = Sin(var1[5]);
  t1089 = Cos(var1[5]);
  t8420 = Cos(var1[2]);
  t8446 = -1.*t8433;
  t14017 = 1. + t8446;
  t14018 = 0.4*t14017;
  t14019 = 0.64*t8433;
  t14034 = t14018 + t14019;
  t14050 = t1089*t8433;
  t14061 = -1.*t8426*t14035;
  t14077 = t14050 + t14061;
  t8414 = -1.*t1089*t8094;
  t8428 = -1.*t8420*t8426;
  t8429 = t8414 + t8428;
  t8432 = 0.748*t8429;
  t14036 = t14034*t14035;
  t14037 = -0.24*t8433*t14035;
  t14043 = t14036 + t14037;
  t14108 = -1.*t8433*t8426;
  t14109 = -1.*t1089*t14035;
  t14110 = t14108 + t14109;
  t14079 = t8420*t14077;
  t14104 = t14034*t8433;
  t14105 = Power(t14035,2);
  t14106 = 0.24*t14105;
  t14107 = t14104 + t14106;
  t14111 = t8420*t14110;
  t14117 = t8094*t14110;
  t14118 = t14117 + t14079;
  t14119 = 3.2*t14043*t14118;
  t14044 = t8433*t8426;
  t14045 = t1089*t14035;
  t14048 = t14044 + t14045;
  t14120 = -1.*t1089*t8433;
  t14121 = t8426*t14035;
  t14122 = t14120 + t14121;
  t14123 = t8094*t14122;
  t14124 = t14111 + t14123;
  t14125 = 3.2*t14107*t14124;
  t14112 = -1.*t8094*t14077;
  t14143 = -1.*t8420*t1089;
  t14144 = t8094*t8426;
  t14145 = t14143 + t14144;
  t14146 = 0.748*t14145;
  t14113 = t14111 + t14112;
  t14147 = -1.*t8094*t14110;
  t14132 = Power(t8433,2);
  t14133 = -0.24*t14132;
  t14134 = t14104 + t14133;
  t14049 = -1.*t8094*t14048;
  t14080 = t14049 + t14079;
  t14156 = 3.2*t14043*t14113;
  t14128 = -1.*t14034*t14035;
  t14129 = 0.24*t8433*t14035;
  t14130 = t14128 + t14129;
  t14157 = t8420*t14122;
  t14158 = t14147 + t14157;
  t14159 = 3.2*t14107*t14158;
  t14176 = t1089*t14034;
  t14177 = -0.24*t8426*t14035;
  t14178 = t14176 + t14177;
  t14168 = -1.*t14034*t8426;
  t14169 = -0.24*t1089*t14035;
  t14170 = t14168 + t14169;
  t14172 = t14034*t8426;
  t14173 = 0.24*t1089*t14035;
  t14174 = t14172 + t14173;
  t14175 = t14174*t14077;
  t14179 = t14110*t14178;
  t14199 = -0.24*t8433*t8426;
  t14200 = t14199 + t14169;
  t14184 = -1.*t14110*t14174;
  t14202 = 0.24*t1089*t8433;
  t14203 = t14202 + t14177;
  t14186 = -1.*t14178*t14122;
  p_output1[0]=var2[5]*(-0.5*(3.2*t14043*t14080 + 3.2*t14107*t14113 + t8432)*var2[2] - 0.5*(t14119 + t14125 + t8432)*var2[5] - 0.5*(t14119 + t14125 + 3.2*t14118*t14130 + 3.2*t14134*(t14077*t8094 + t14048*t8420))*var2[6]);
  p_output1[1]=var2[5]*(-0.5*(t14146 + 3.2*t14043*(t14112 - 1.*t14048*t8420) + 3.2*t14107*(t14147 - 1.*t14077*t8420))*var2[2] - 0.5*(t14146 + t14156 + t14159)*var2[5] - 0.5*(3.2*t14113*t14130 + 3.2*t14080*t14134 + t14156 + t14159)*var2[6]);
  p_output1[2]=var2[5]*(-0.5*(3.2*t14107*(t14077*t14170 + t14175 + t14048*t14178 + t14179) + 3.2*t14043*(-1.*t14110*t14170 - 1.*t14077*t14178 + t14184 + t14186))*var2[5] - 0.5*(3.2*t14130*(t14048*t14174 + t14077*t14178) + 3.2*t14134*(-1.*t14077*t14174 - 1.*t14110*t14178) + 3.2*t14107*(t14175 + t14179 + t14077*t14200 + t14048*t14203) + 3.2*t14043*(t14184 + t14186 - 1.*t14110*t14200 - 1.*t14077*t14203))*var2[6]);
  p_output1[3]=0;
  p_output1[4]=0;
  p_output1[5]=-0.5*(6.4*t14107*t14130 + 6.4*t14043*t14134)*var2[5]*var2[6];
  p_output1[6]=-0.384*t14130*var2[5]*var2[6];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce1_vec6_five_link_walker.hh"

namespace RightStance
{

void Ce1_vec6_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
