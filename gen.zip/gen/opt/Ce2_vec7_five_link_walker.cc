/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:50 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t9605;
  double t3689;
  double t8301;
  double t9631;
  double t11252;
  double t8402;
  double t11016;
  double t11151;
  double t121;
  double t11418;
  double t11421;
  double t11422;
  double t11471;
  double t11530;
  double t11538;
  double t11539;
  double t11541;
  double t11543;
  double t11545;
  double t11547;
  double t11571;
  double t11184;
  double t11260;
  double t11283;
  double t11328;
  double t11329;
  double t11330;
  double t11575;
  double t11576;
  double t11577;
  double t11578;
  double t11579;
  double t11580;
  double t11609;
  double t11610;
  double t11622;
  double t11623;
  double t11624;
  double t11626;
  double t11630;
  double t11632;
  double t11641;
  double t11643;
  double t11645;
  double t11651;
  double t11673;
  double t11614;
  double t11616;
  double t11617;
  double t11572;
  double t11573;
  double t11574;
  double t11604;
  double t11607;
  double t11531;
  double t11532;
  double t11533;
  double t11558;
  double t11560;
  double t11561;
  double t11586;
  double t11587;
  double t11590;
  double t11608;
  double t11613;
  double t11618;
  double t11619;
  double t11620;
  double t11625;
  double t11636;
  double t11639;
  double t11646;
  double t11647;
  double t11649;
  double t11676;
  double t11678;
  double t11681;
  double t11696;
  double t11720;
  double t11722;
  double t11723;
  double t11725;
  double t11727;
  double t11729;
  double t11763;
  double t11764;
  double t11765;
  double t11767;
  double t11769;
  double t11640;
  double t11679;
  double t11721;
  double t11731;
  double t11741;
  double t11748;
  double t11750;
  double t11752;
  double t11753;
  double t11755;
  double t11548;
  double t11563;
  double t11583;
  double t11593;
  double t11594;
  double t11792;
  double t11801;
  double t11802;
  double t11808;
  double t11809;
  t9605 = Cos(var1[5]);
  t3689 = Cos(var1[6]);
  t8301 = Sin(var1[5]);
  t9631 = Sin(var1[6]);
  t11252 = Sin(var1[2]);
  t8402 = -1.*t3689*t8301;
  t11016 = -1.*t9605*t9631;
  t11151 = t8402 + t11016;
  t121 = Cos(var1[2]);
  t11418 = -1.*t3689;
  t11421 = 1. + t11418;
  t11422 = 0.4*t11421;
  t11471 = 0.64*t3689;
  t11530 = t11422 + t11471;
  t11538 = t11252*t11151;
  t11539 = t9605*t3689;
  t11541 = -1.*t8301*t9631;
  t11543 = t11539 + t11541;
  t11545 = t121*t11543;
  t11547 = t11538 + t11545;
  t11571 = t11530*t3689;
  t11184 = t121*t11151;
  t11260 = -1.*t9605*t3689;
  t11283 = t8301*t9631;
  t11328 = t11260 + t11283;
  t11329 = t11252*t11328;
  t11330 = t11184 + t11329;
  t11575 = t3689*t8301;
  t11576 = t9605*t9631;
  t11577 = t11575 + t11576;
  t11578 = t121*t11577;
  t11579 = t11252*t11543;
  t11580 = t11578 + t11579;
  t11609 = -1.*t11252*t11543;
  t11610 = t11184 + t11609;
  t11622 = t11530*t8301;
  t11623 = 0.24*t9605*t9631;
  t11624 = t11622 + t11623;
  t11626 = t9605*t11530;
  t11630 = -0.24*t8301*t9631;
  t11632 = t11626 + t11630;
  t11641 = -0.24*t3689*t8301;
  t11643 = -0.24*t9605*t9631;
  t11645 = t11641 + t11643;
  t11651 = 0.24*t9605*t3689;
  t11673 = t11651 + t11630;
  t11614 = -1.*t11252*t11151;
  t11616 = t121*t11328;
  t11617 = t11614 + t11616;
  t11572 = Power(t3689,2);
  t11573 = -0.24*t11572;
  t11574 = t11571 + t11573;
  t11604 = -1.*t11252*t11577;
  t11607 = t11604 + t11545;
  t11531 = t11530*t9631;
  t11532 = -0.24*t3689*t9631;
  t11533 = t11531 + t11532;
  t11558 = -1.*t11530*t9631;
  t11560 = 0.24*t3689*t9631;
  t11561 = t11558 + t11560;
  t11586 = Power(t9631,2);
  t11587 = 0.24*t11586;
  t11590 = t11571 + t11587;
  t11608 = 3.2*t11547*t11607;
  t11613 = 3.2*t11610*t11580;
  t11618 = 3.2*t11547*t11617;
  t11619 = 3.2*t11610*t11330;
  t11620 = t11608 + t11613 + t11618 + t11619;
  t11625 = -1.*t11624*t11543;
  t11636 = -1.*t11151*t11632;
  t11639 = t11625 + t11636;
  t11646 = t11645*t11543;
  t11647 = t11624*t11543;
  t11649 = t11151*t11632;
  t11676 = t11577*t11673;
  t11678 = t11646 + t11647 + t11649 + t11676;
  t11681 = t11624*t11577;
  t11696 = t11543*t11632;
  t11720 = t11681 + t11696;
  t11722 = -1.*t11151*t11645;
  t11723 = -1.*t11151*t11624;
  t11725 = -1.*t11543*t11673;
  t11727 = -1.*t11632*t11328;
  t11729 = t11722 + t11723 + t11725 + t11727;
  t11763 = 3.2*t11610*t11639;
  t11764 = 3.2*t11610*t11678;
  t11765 = 3.2*t11720*t11617;
  t11767 = 3.2*t11607*t11729;
  t11769 = t11763 + t11764 + t11765 + t11767;
  t11640 = 3.2*t11547*t11639;
  t11679 = 3.2*t11547*t11678;
  t11721 = 3.2*t11720*t11330;
  t11731 = 3.2*t11580*t11729;
  t11741 = t11640 + t11679 + t11721 + t11731;
  t11748 = 3.2*t11574*t11607;
  t11750 = 3.2*t11533*t11610;
  t11752 = 3.2*t11561*t11610;
  t11753 = 3.2*t11590*t11617;
  t11755 = t11748 + t11750 + t11752 + t11753;
  t11548 = 3.2*t11533*t11547;
  t11563 = 3.2*t11561*t11547;
  t11583 = 3.2*t11574*t11580;
  t11593 = 3.2*t11590*t11330;
  t11594 = t11548 + t11563 + t11583 + t11593;
  t11792 = 3.2*t11574*t11639;
  t11801 = 3.2*t11561*t11720;
  t11802 = 3.2*t11590*t11678;
  t11808 = 3.2*t11533*t11729;
  t11809 = t11792 + t11801 + t11802 + t11808;
  p_output1[0]=var2[6]*(-0.5*(6.4*t11330*t11547 + 6.4*t11547*t11580)*var2[0] - 0.5*t11620*var2[1] - 0.5*t11741*var2[2] - 0.5*t11594*var2[5] - 0.384*t11330*var2[6]);
  p_output1[1]=var2[6]*(-0.5*t11620*var2[0] - 0.5*(6.4*t11607*t11610 + 6.4*t11610*t11617)*var2[1] - 0.5*t11769*var2[2] - 0.5*t11755*var2[5] - 0.384*t11617*var2[6]);
  p_output1[2]=var2[6]*(-0.5*t11741*var2[0] - 0.5*t11769*var2[1] - 0.5*(6.4*t11678*t11720 + 6.4*t11639*t11729)*var2[2] - 0.5*t11809*var2[5] - 0.384*t11678*var2[6]);
  p_output1[3]=0;
  p_output1[4]=0;
  p_output1[5]=var2[6]*(-0.5*t11594*var2[0] - 0.5*t11755*var2[1] - 0.5*t11809*var2[2] - 0.5*(6.4*t11533*t11574 + 6.4*t11561*t11590)*var2[5] - 0.384*t11561*var2[6]);
  p_output1[6]=(-0.384*t11330*var2[0] - 0.384*t11617*var2[1] - 0.384*t11678*var2[2] - 0.384*t11561*var2[5])*var2[6];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce2_vec7_five_link_walker.hh"

namespace RightStance
{

void Ce2_vec7_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
