/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:01 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t920;
  double t1077;
  double t776;
  double t831;
  double t775;
  double t813;
  double t930;
  double t931;
  double t970;
  double t971;
  double t978;
  double t7648;
  double t7664;
  double t7668;
  double t8191;
  double t8224;
  double t8265;
  double t8273;
  double t8326;
  double t8356;
  double t8363;
  double t1082;
  double t3725;
  double t3745;
  double t3808;
  double t3884;
  double t4002;
  double t9662;
  double t10070;
  double t10077;
  double t10079;
  double t10080;
  double t8683;
  double t9736;
  double t10096;
  double t785;
  double t843;
  double t882;
  double t884;
  double t8070;
  double t10134;
  double t10135;
  double t10136;
  double t10244;
  double t10245;
  double t10246;
  double t10236;
  double t10237;
  double t10238;
  double t10240;
  double t10241;
  double t10242;
  double t10264;
  double t10265;
  double t10266;
  double t10268;
  double t10269;
  double t10270;
  double t7603;
  double t8078;
  double t10133;
  double t10137;
  double t10138;
  double t10139;
  double t10143;
  double t10145;
  double t10146;
  double t10169;
  double t10170;
  double t10179;
  double t10243;
  double t10247;
  double t10320;
  double t10346;
  double t10254;
  double t10349;
  double t10350;
  double t10256;
  t920 = Cos(var1[6]);
  t1077 = Sin(var1[6]);
  t776 = Sin(var1[2]);
  t831 = Sin(var1[5]);
  t775 = Cos(var1[5]);
  t813 = Cos(var1[2]);
  t930 = -1.*t920;
  t931 = 1. + t930;
  t970 = 0.4*t931;
  t971 = 0.64*t920;
  t978 = t970 + t971;
  t7648 = t775*t920;
  t7664 = -1.*t831*t1077;
  t7668 = t7648 + t7664;
  t8191 = t978*t920;
  t8224 = Power(t1077,2);
  t8265 = 0.24*t8224;
  t8273 = t8191 + t8265;
  t8326 = -1.*t920*t831;
  t8356 = -1.*t775*t1077;
  t8363 = t8326 + t8356;
  t1082 = t978*t1077;
  t3725 = -0.24*t920*t1077;
  t3745 = t1082 + t3725;
  t3808 = t920*t831;
  t3884 = t775*t1077;
  t4002 = t3808 + t3884;
  t9662 = -1.*t776*t7668;
  t10070 = -1.*t813*t775;
  t10077 = t776*t831;
  t10079 = t10070 + t10077;
  t10080 = -0.748*t10079;
  t8683 = t813*t8363;
  t9736 = t8683 + t9662;
  t10096 = -1.*t776*t8363;
  t785 = -1.*t775*t776;
  t843 = -1.*t813*t831;
  t882 = t785 + t843;
  t884 = -0.748*t882;
  t8070 = t813*t7668;
  t10134 = -1.*t775*t920;
  t10135 = t831*t1077;
  t10136 = t10134 + t10135;
  t10244 = t775*t978;
  t10245 = -0.24*t831*t1077;
  t10246 = t10244 + t10245;
  t10236 = -1.*t978*t831;
  t10237 = -0.24*t775*t1077;
  t10238 = t10236 + t10237;
  t10240 = t978*t831;
  t10241 = 0.24*t775*t1077;
  t10242 = t10240 + t10241;
  t10264 = -1.*t978*t1077;
  t10265 = 0.24*t920*t1077;
  t10266 = t10264 + t10265;
  t10268 = Power(t920,2);
  t10269 = -0.24*t10268;
  t10270 = t8191 + t10269;
  t7603 = -1.*t776*t4002;
  t8078 = t7603 + t8070;
  t10133 = -3.2*t3745*t9736;
  t10137 = t813*t10136;
  t10138 = t10096 + t10137;
  t10139 = -3.2*t8273*t10138;
  t10143 = t776*t8363;
  t10145 = t10143 + t8070;
  t10146 = -3.2*t3745*t10145;
  t10169 = t776*t10136;
  t10170 = t8683 + t10169;
  t10179 = -3.2*t8273*t10170;
  t10243 = t10242*t7668;
  t10247 = t8363*t10246;
  t10320 = -0.24*t920*t831;
  t10346 = t10320 + t10237;
  t10254 = -1.*t8363*t10242;
  t10349 = 0.24*t775*t920;
  t10350 = t10349 + t10245;
  t10256 = -1.*t10246*t10136;
  p_output1[0]=0;
  p_output1[1]=0;
  p_output1[2]=(-0.5*(-3.2*t3745*t8078 + t884 - 3.2*t8273*t9736)*var2[0] - 0.5*(t10080 - 3.2*(t10096 - 1.*t7668*t813)*t8273 - 3.2*t3745*(-1.*t4002*t813 + t9662))*var2[1])*var2[5];
  p_output1[3]=0;
  p_output1[4]=0;
  p_output1[5]=(-0.5*(t10146 + t10179 + t884)*var2[0] - 0.5*(t10080 + t10133 + t10139)*var2[1] - 0.5*(-3.2*(t10243 + t10247 + t10246*t4002 + t10238*t7668)*t8273 - 3.2*t3745*(t10254 + t10256 - 1.*t10246*t7668 - 1.*t10238*t8363))*var2[2])*var2[5];
  p_output1[6]=var2[5]*(-0.5*(t10146 + t10179 - 3.2*t10145*t10266 - 3.2*t10270*(t7668*t776 + t4002*t813))*var2[0] - 0.5*(t10133 + t10139 - 3.2*t10270*t8078 - 3.2*t10266*t9736)*var2[1] - 0.5*(-3.2*t10266*(t10242*t4002 + t10246*t7668) - 3.2*(t10243 + t10247 + t10350*t4002 + t10346*t7668)*t8273 - 3.2*t10270*(-1.*t10242*t7668 - 1.*t10246*t8363) - 3.2*t3745*(t10254 + t10256 - 1.*t10350*t7668 - 1.*t10346*t8363))*var2[2] - 0.5*(-6.4*t10270*t3745 - 6.4*t10266*t8273)*var2[5] + 0.384*t10266*var2[6]);
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce3_vec6_five_link_walker.hh"

namespace RightStance
{

void Ce3_vec6_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
