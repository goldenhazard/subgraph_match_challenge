/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:32:56 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2,const double *var3,const double *var4)
{
  double t17708;
  double t17710;
  double t17707;
  double t17721;
  double t10880;
  double t17709;
  double t17722;
  double t17723;
  double t17731;
  double t17732;
  double t17740;
  double t17741;
  double t17747;
  double t17748;
  double t17749;
  double t17763;
  double t17764;
  double t17765;
  double t17766;
  double t17684;
  double t17706;
  double t17770;
  double t17771;
  double t17773;
  double t17769;
  double t17775;
  double t17776;
  double t17777;
  double t17778;
  double t17784;
  double t17800;
  double t17802;
  double t17807;
  double t17808;
  double t17809;
  double t17810;
  double t17811;
  double t17818;
  double t17819;
  double t17820;
  double t17817;
  double t17821;
  double t17822;
  double t17823;
  double t17824;
  double t17825;
  double t17816;
  double t17826;
  double t17827;
  double t17828;
  double t17724;
  double t17742;
  double t17743;
  double t17744;
  double t17745;
  double t17746;
  double t17767;
  double t17768;
  double t17785;
  double t17786;
  double t17787;
  double t17798;
  double t17799;
  double t17801;
  double t17803;
  double t17804;
  double t17805;
  double t17806;
  double t17812;
  double t17813;
  double t17814;
  double t17815;
  double t17829;
  double t17830;
  double t17831;
  double t17841;
  double t17842;
  double t17843;
  double t17844;
  double t17845;
  double t17859;
  double t17860;
  double t17861;
  double t17862;
  double t17832;
  double t17833;
  double t17834;
  double t17835;
  double t17836;
  double t17867;
  double t17873;
  double t17875;
  double t17880;
  double t17881;
  double t17882;
  double t17883;
  double t17884;
  double t17889;
  double t17890;
  double t17891;
  double t17892;
  double t17893;
  double t17894;
  double t17895;
  double t17896;
  double t17897;
  double t17898;
  double t17869;
  double t17870;
  double t17871;
  double t17872;
  double t17874;
  double t17876;
  double t17877;
  double t17878;
  double t17879;
  double t17885;
  double t17886;
  double t17887;
  double t17888;
  double t17899;
  double t17900;
  double t17901;
  double t17916;
  double t17917;
  double t17918;
  double t17919;
  t17708 = Cos(var1[3]);
  t17710 = Sin(var1[2]);
  t17707 = Cos(var1[2]);
  t17721 = Sin(var1[3]);
  t10880 = Cos(var1[4]);
  t17709 = t17707*t17708;
  t17722 = -1.*t17710*t17721;
  t17723 = t17709 + t17722;
  t17731 = -1.*t17708*t17710;
  t17732 = -1.*t17707*t17721;
  t17740 = t17731 + t17732;
  t17741 = Sin(var1[4]);
  t17747 = -0.4*t10880*t17740;
  t17748 = 0.4*t17723*t17741;
  t17749 = t10880*t17740;
  t17763 = -1.*t17723*t17741;
  t17764 = t17749 + t17763;
  t17765 = 0.8*t17764;
  t17766 = t17747 + t17748 + t17765;
  t17684 = -1.*t10880;
  t17706 = 1. + t17684;
  t17770 = -1.*t17707*t17708;
  t17771 = t17710*t17721;
  t17773 = t17770 + t17771;
  t17769 = 0.4*t17706*t17740;
  t17775 = -0.4*t17773*t17741;
  t17776 = t17773*t17741;
  t17777 = t17749 + t17776;
  t17778 = 0.8*t17777;
  t17784 = t17769 + t17775 + t17778;
  t17800 = 0.4*t17740*t17741;
  t17802 = -1.*t17740*t17741;
  t17807 = -0.4*t10880*t17773;
  t17808 = t10880*t17773;
  t17809 = t17808 + t17802;
  t17810 = 0.8*t17809;
  t17811 = t17807 + t17800 + t17810;
  t17818 = t17708*t17710;
  t17819 = t17707*t17721;
  t17820 = t17818 + t17819;
  t17817 = 0.4*t17706*t17773;
  t17821 = -0.4*t17820*t17741;
  t17822 = t17820*t17741;
  t17823 = t17808 + t17822;
  t17824 = 0.8*t17823;
  t17825 = t17817 + t17821 + t17824;
  t17816 = var2[4]*t17811;
  t17826 = var2[2]*t17825;
  t17827 = var2[3]*t17825;
  t17828 = t17816 + t17826 + t17827;
  t17724 = 0.4*t17706*t17723;
  t17742 = -0.4*t17740*t17741;
  t17743 = t10880*t17723;
  t17744 = t17740*t17741;
  t17745 = t17743 + t17744;
  t17746 = 0.8*t17745;
  t17767 = var3[4]*t17766;
  t17768 = var2[4]*t17766;
  t17785 = var3[2]*t17784;
  t17786 = var3[3]*t17784;
  t17787 = var2[2]*t17784;
  t17798 = var2[3]*t17784;
  t17799 = 0.4*t10880*t17723;
  t17801 = -1.*t10880*t17723;
  t17803 = t17801 + t17802;
  t17804 = 0.8*t17803;
  t17805 = t17799 + t17800 + t17804;
  t17806 = var2[4]*t17805;
  t17812 = var2[2]*t17811;
  t17813 = var2[3]*t17811;
  t17814 = t17806 + t17812 + t17813;
  t17815 = var2[4]*t17814;
  t17829 = var2[2]*t17828;
  t17830 = var2[3]*t17828;
  t17831 = t17724 + t17742 + t17746 + t17767 + t17768 + t17785 + t17786 + t17787 + t17798 + t17815 + t17829 + t17830;
  t17841 = 0.4*t10880*t17820;
  t17842 = -1.*t10880*t17820;
  t17843 = t17842 + t17763;
  t17844 = 0.8*t17843;
  t17845 = t17841 + t17748 + t17844;
  t17859 = 2.*var2[4]*t17766;
  t17860 = 2.*var2[2]*t17784;
  t17861 = 2.*var2[3]*t17784;
  t17862 = t17724 + t17742 + t17746 + t17859 + t17860 + t17861;
  t17832 = -0.4*t10880*t17723;
  t17833 = 0.4*t17820*t17741;
  t17834 = -1.*t17820*t17741;
  t17835 = t17743 + t17834;
  t17836 = 0.8*t17835;
  t17867 = t17724 + t17742 + t17746;
  t17873 = 0.4*t17773*t17741;
  t17875 = -1.*t17773*t17741;
  t17880 = -0.4*t10880*t17820;
  t17881 = t10880*t17820;
  t17882 = t17881 + t17875;
  t17883 = 0.8*t17882;
  t17884 = t17880 + t17873 + t17883;
  t17889 = 0.4*t17706*t17820;
  t17890 = -0.4*t17723*t17741;
  t17891 = t17723*t17741;
  t17892 = t17881 + t17891;
  t17893 = 0.8*t17892;
  t17894 = t17889 + t17890 + t17893;
  t17895 = var2[2]*t17894;
  t17896 = var2[3]*t17894;
  t17897 = var2[4]*t17884;
  t17898 = t17895 + t17896 + t17897;
  t17869 = var3[4]*t17811;
  t17870 = var3[2]*t17825;
  t17871 = var3[3]*t17825;
  t17872 = 0.4*t10880*t17740;
  t17874 = -1.*t10880*t17740;
  t17876 = t17874 + t17875;
  t17877 = 0.8*t17876;
  t17878 = t17872 + t17873 + t17877;
  t17879 = var2[4]*t17878;
  t17885 = var2[2]*t17884;
  t17886 = var2[3]*t17884;
  t17887 = t17879 + t17885 + t17886;
  t17888 = var2[4]*t17887;
  t17899 = var2[2]*t17898;
  t17900 = var2[3]*t17898;
  t17901 = t17769 + t17775 + t17778 + t17869 + t17816 + t17870 + t17871 + t17826 + t17827 + t17888 + t17899 + t17900;
  t17916 = 2.*var2[4]*t17811;
  t17917 = 2.*var2[2]*t17825;
  t17918 = 2.*var2[3]*t17825;
  t17919 = t17769 + t17775 + t17778 + t17916 + t17917 + t17918;
  p_output1[0]=1.;
  p_output1[1]=t17831;
  p_output1[2]=t17831;
  p_output1[3]=t17832 + t17833 + t17836 + t17766*var2[2] + t17814*var2[2] + t17766*var2[3] + t17814*var2[3] + t17845*var2[4] + var2[4]*(t17805*var2[2] + t17805*var2[3] + (t17799 + t17821 + 0.8*(t17801 + t17822))*var2[4]) + t17766*var3[2] + t17766*var3[3] + t17845*var3[4];
  p_output1[4]=1.;
  p_output1[5]=t17862;
  p_output1[6]=t17862;
  p_output1[7]=t17832 + t17833 + t17836 + 2.*t17766*var2[2] + 2.*t17766*var2[3] + 2.*t17845*var2[4];
  p_output1[8]=1.;
  p_output1[9]=t17867;
  p_output1[10]=t17867;
  p_output1[11]=t17832 + t17833 + t17836;
  p_output1[12]=-1.;
  p_output1[13]=-1.;
  p_output1[14]=1.;
  p_output1[15]=t17901;
  p_output1[16]=t17901;
  p_output1[17]=t17747 + t17748 + t17765 + t17806 + t17812 + t17813 + t17887*var2[2] + t17887*var2[3] + var2[4]*(t17878*var2[2] + t17878*var2[3] + (t17872 + t17890 + 0.8*(t17874 + t17891))*var2[4]) + t17811*var3[2] + t17811*var3[3] + t17805*var3[4];
  p_output1[18]=1.;
  p_output1[19]=t17919;
  p_output1[20]=t17919;
  p_output1[21]=t17747 + t17748 + t17765 + 2.*t17811*var2[2] + 2.*t17811*var2[3] + 2.*t17805*var2[4];
  p_output1[22]=1.;
  p_output1[23]=t17784;
  p_output1[24]=t17784;
  p_output1[25]=t17766;
  p_output1[26]=-1.;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2,*var3,*var4;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 4)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Four input(s) required (var1,var2,var3,var4).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }
  mrows = mxGetM(prhs[2]);
  ncols = mxGetN(prhs[2]);
  if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var3 is wrong.");
    }
  mrows = mxGetM(prhs[3]);
  ncols = mxGetN(prhs[3]);
  if( !mxIsDouble(prhs[3]) || mxIsComplex(prhs[3]) ||
    ( !(mrows == 3 && ncols == 1) && 
      !(mrows == 1 && ncols == 3))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var4 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
  var3 = mxGetPr(prhs[2]);
  var4 = mxGetPr(prhs[3]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 27, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2,var3,var4);


}

#else // MATLAB_MEX_FILE

#include "J_ddh_RightToe_RightStance.hh"

namespace RightStance
{

void J_ddh_RightToe_RightStance_raw(double *p_output1, const double *var1,const double *var2,const double *var3,const double *var4)
{
  // Call Subroutines
  output1(p_output1, var1, var2, var3, var4);

}

}

#endif // MATLAB_MEX_FILE
