/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:54 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t3733;
  double t1599;
  double t1617;
  double t8046;
  double t1121;
  double t10294;
  double t11167;
  double t11305;
  double t11326;
  double t11399;
  double t11608;
  double t3592;
  double t8104;
  double t9515;
  double t12134;
  double t12191;
  double t12209;
  double t12483;
  double t12524;
  double t12539;
  double t11642;
  double t10219;
  double t10372;
  double t10521;
  double t10772;
  double t11072;
  double t11137;
  double t12070;
  double t12071;
  double t12102;
  double t12104;
  double t12219;
  double t12249;
  double t13335;
  double t13360;
  double t14705;
  double t14796;
  double t14908;
  double t14946;
  double t14952;
  double t15040;
  double t15086;
  double t15127;
  double t15132;
  double t15139;
  double t15141;
  double t15142;
  double t15143;
  double t15153;
  double t15154;
  double t15159;
  double t15176;
  double t15177;
  double t11679;
  double t11737;
  double t12036;
  double t12734;
  double t12766;
  double t12932;
  double t15209;
  double t15213;
  double t12409;
  double t12449;
  double t12475;
  double t12659;
  double t12673;
  double t12714;
  double t15033;
  double t15184;
  double t15185;
  double t15193;
  double t15140;
  double t15144;
  double t15145;
  double t15167;
  double t15168;
  double t15166;
  double t15178;
  double t15182;
  double t15251;
  double t15252;
  double t15198;
  double t15201;
  double t15195;
  double t15200;
  double t15202;
  double t15262;
  double t15263;
  double t15264;
  double t15214;
  double t15216;
  double t15217;
  double t15221;
  double t15222;
  double t15223;
  double t15224;
  double t15225;
  double t15226;
  double t15232;
  double t15233;
  double t15234;
  double t15235;
  double t15236;
  double t15237;
  double t15238;
  double t15239;
  double t15240;
  double t15241;
  double t15242;
  double t15246;
  double t15247;
  double t15259;
  double t15260;
  double t15265;
  double t15268;
  double t15278;
  double t15279;
  double t15283;
  double t15284;
  double t15330;
  double t15331;
  double t15332;
  double t15333;
  double t15334;
  double t15314;
  double t15315;
  double t15316;
  double t15318;
  double t15319;
  double t15320;
  double t15321;
  double t15322;
  double t15324;
  double t15325;
  double t15326;
  double t15327;
  double t15328;
  double t15007;
  double t15035;
  double t13485;
  double t13647;
  double t13188;
  double t14699;
  double t15002;
  double t15006;
  double t15039;
  double t15087;
  double t15088;
  double t15253;
  double t15254;
  double t15255;
  double t15261;
  double t15266;
  double t15267;
  double t15269;
  double t15271;
  double t15272;
  double t15273;
  double t15276;
  double t15277;
  double t15280;
  double t15285;
  double t15364;
  double t15292;
  double t15293;
  double t15294;
  double t15366;
  double t15368;
  double t15371;
  double t15372;
  double t15373;
  double t15374;
  double t15375;
  double t15376;
  double t15377;
  double t15378;
  double t15379;
  double t15380;
  double t15383;
  double t15301;
  double t15302;
  double t15303;
  double t15306;
  double t15307;
  double t15308;
  double t15323;
  double t15152;
  double t15183;
  double t15194;
  double t15203;
  double t15205;
  double t12343;
  double t12570;
  double t12728;
  double t13036;
  double t13083;
  double t13187;
  double t15406;
  double t15206;
  double t15356;
  double t15357;
  double t15358;
  double t15359;
  double t15360;
  double t15257;
  double t15258;
  double t15270;
  double t15274;
  double t15275;
  double t15286;
  double t15287;
  double t15381;
  double t15382;
  double t15384;
  double t15385;
  double t15386;
  double t15387;
  double t15388;
  double t15300;
  double t15304;
  double t15305;
  double t15309;
  double t15310;
  double t15398;
  double t15399;
  double t15400;
  double t15401;
  double t15402;
  double t15329;
  double t15408;
  double t15460;
  double t15461;
  double t15462;
  double t15463;
  double t15464;
  double t15456;
  double t15457;
  double t15458;
  double t15343;
  double t15344;
  double t15345;
  double t15346;
  double t15347;
  double t15365;
  double t15367;
  double t15369;
  double t15215;
  double t15218;
  double t15219;
  double t15419;
  double t15420;
  double t15421;
  double t15422;
  double t15423;
  double t15392;
  double t15393;
  double t15394;
  double t15395;
  double t15396;
  double t15291;
  double t15295;
  double t15296;
  double t15297;
  double t15298;
  double t15436;
  double t15437;
  double t15438;
  double t15439;
  double t15440;
  double t15441;
  double t15442;
  double t15335;
  double t15409;
  double t15465;
  double t15495;
  double t15496;
  double t15497;
  double t15509;
  double t15510;
  double t11153;
  t3733 = Cos(var1[3]);
  t1599 = Cos(var1[4]);
  t1617 = Sin(var1[3]);
  t8046 = Sin(var1[4]);
  t1121 = Sin(var1[2]);
  t10294 = Cos(var1[2]);
  t11167 = -1.*t1599;
  t11305 = 1. + t11167;
  t11326 = 0.4*t11305;
  t11399 = 0.64*t1599;
  t11608 = t11326 + t11399;
  t3592 = -1.*t1599*t1617;
  t8104 = -1.*t3733*t8046;
  t9515 = t3592 + t8104;
  t12134 = t3733*t1599;
  t12191 = -1.*t1617*t8046;
  t12209 = t12134 + t12191;
  t12483 = t10294*t9515;
  t12524 = -1.*t1121*t12209;
  t12539 = t12483 + t12524;
  t11642 = t11608*t1599;
  t10219 = -1.*t1121*t9515;
  t10372 = -1.*t3733*t1599;
  t10521 = t1617*t8046;
  t10772 = t10372 + t10521;
  t11072 = t10294*t10772;
  t11137 = t10219 + t11072;
  t12070 = t1599*t1617;
  t12071 = t3733*t8046;
  t12102 = t12070 + t12071;
  t12104 = -1.*t1121*t12102;
  t12219 = t10294*t12209;
  t12249 = t12104 + t12219;
  t13335 = t1121*t9515;
  t13360 = t13335 + t12219;
  t14705 = -1.*t10294*t12209;
  t14796 = t10219 + t14705;
  t14908 = t10294*t12102;
  t14946 = t1121*t12209;
  t14952 = t14908 + t14946;
  t15040 = t1121*t10772;
  t15086 = t12483 + t15040;
  t15127 = t11608*t1617;
  t15132 = 0.24*t3733*t8046;
  t15139 = t15127 + t15132;
  t15141 = t3733*t11608;
  t15142 = -0.24*t1617*t8046;
  t15143 = t15141 + t15142;
  t15153 = -0.24*t1599*t1617;
  t15154 = -0.24*t3733*t8046;
  t15159 = t15153 + t15154;
  t15176 = 0.24*t3733*t1599;
  t15177 = t15176 + t15142;
  t11679 = Power(t1599,2);
  t11737 = -0.24*t11679;
  t12036 = t11642 + t11737;
  t12734 = Power(t8046,2);
  t12766 = 0.24*t12734;
  t12932 = t11642 + t12766;
  t15209 = t1121*t12102;
  t15213 = t15209 + t11072;
  t12409 = t11608*t8046;
  t12449 = -0.24*t1599*t8046;
  t12475 = t12409 + t12449;
  t12659 = -1.*t11608*t8046;
  t12673 = 0.24*t1599*t8046;
  t12714 = t12659 + t12673;
  t15033 = -1.*t1121*t10772;
  t15184 = t15139*t12102;
  t15185 = t12209*t15143;
  t15193 = t15184 + t15185;
  t15140 = -1.*t15139*t12209;
  t15144 = -1.*t9515*t15143;
  t15145 = t15140 + t15144;
  t15167 = t15139*t12209;
  t15168 = t9515*t15143;
  t15166 = t15159*t12209;
  t15178 = t12102*t15177;
  t15182 = t15166 + t15167 + t15168 + t15178;
  t15251 = -1.*t11608*t1617;
  t15252 = t15251 + t15154;
  t15198 = -1.*t9515*t15139;
  t15201 = -1.*t15143*t10772;
  t15195 = -1.*t9515*t15159;
  t15200 = -1.*t12209*t15177;
  t15202 = t15195 + t15198 + t15200 + t15201;
  t15262 = -0.24*t3733*t1599;
  t15263 = 0.24*t1617*t8046;
  t15264 = t15262 + t15263;
  t15214 = -0.384*var2[4]*t15213;
  t15216 = 3.2*t12932*t15213;
  t15217 = 3.2*t12475*t15086;
  t15221 = 6.4*t13360*t12539;
  t15222 = 3.2*t14952*t11137;
  t15223 = 3.2*t12539*t15213;
  t15224 = t14908 + t15033;
  t15225 = 3.2*t13360*t15224;
  t15226 = 3.2*t12249*t15086;
  t15232 = 6.4*t11137*t15086;
  t15233 = t15221 + t15222 + t15223 + t15225 + t15226 + t15232;
  t15234 = -0.5*var2[1]*t15233;
  t15235 = Power(t13360,2);
  t15236 = 6.4*t15235;
  t15237 = 6.4*t13360*t15213;
  t15238 = 6.4*t14952*t15086;
  t15239 = Power(t15086,2);
  t15240 = 6.4*t15239;
  t15241 = t15236 + t15237 + t15238 + t15240;
  t15242 = -0.5*var2[0]*t15241;
  t15246 = 3.2*t15193*t15213;
  t15247 = 3.2*t15145*t15086;
  t15259 = -1.*t15159*t12209;
  t15260 = -1.*t12102*t15143;
  t15265 = -1.*t9515*t15264;
  t15268 = -1.*t15139*t10772;
  t15278 = t9515*t15139;
  t15279 = t15159*t12102;
  t15283 = t12209*t15264;
  t15284 = t15143*t10772;
  t15330 = 3.2*t12475*t13360;
  t15331 = 3.2*t12714*t13360;
  t15332 = 3.2*t12036*t14952;
  t15333 = 3.2*t12932*t15086;
  t15334 = t15330 + t15331 + t15332 + t15333;
  t15314 = 6.4*t13360*t14952;
  t15315 = 6.4*t13360*t15086;
  t15316 = t15314 + t15315;
  t15318 = 3.2*t13360*t12249;
  t15319 = 3.2*t12539*t14952;
  t15320 = 3.2*t13360*t11137;
  t15321 = 3.2*t12539*t15086;
  t15322 = t15318 + t15319 + t15320 + t15321;
  t15324 = 3.2*t13360*t15145;
  t15325 = 3.2*t13360*t15182;
  t15326 = 3.2*t15193*t15086;
  t15327 = 3.2*t14952*t15202;
  t15328 = t15324 + t15325 + t15326 + t15327;
  t15007 = -1.*t10294*t9515;
  t15035 = t15007 + t15033;
  t13485 = -1.*t10294*t12102;
  t13647 = t13485 + t12524;
  t13188 = 6.4*t12249*t12539;
  t14699 = 3.2*t13360*t13647;
  t15002 = 3.2*t14796*t14952;
  t15006 = 6.4*t12539*t11137;
  t15039 = 3.2*t13360*t15035;
  t15087 = 3.2*t14796*t15086;
  t15088 = t13188 + t14699 + t15002 + t15006 + t15039 + t15087;
  t15253 = t15252*t12209;
  t15254 = t12102*t15143;
  t15255 = t15253 + t15167 + t15168 + t15254;
  t15261 = -1.*t9515*t15177;
  t15266 = -1.*t15252*t10772;
  t15267 = -1.*t15159*t10772;
  t15269 = t15259 + t15144 + t15260 + t15261 + t15265 + t15266 + t15267 + t15268;
  t15271 = -1.*t9515*t15252;
  t15272 = -1.*t12209*t15143;
  t15273 = t15271 + t15198 + t15272 + t15201;
  t15276 = t9515*t15252;
  t15277 = t9515*t15159;
  t15280 = t12209*t15177;
  t15285 = t15276 + t15277 + t15278 + t15279 + t15185 + t15280 + t15283 + t15284;
  t15364 = -0.384*var2[4]*t15224;
  t15292 = -1.*t11608*t1599;
  t15293 = 0.24*t11679;
  t15294 = t15292 + t15293;
  t15366 = 3.2*t12475*t11137;
  t15368 = 3.2*t12932*t15224;
  t15371 = Power(t12539,2);
  t15372 = 6.4*t15371;
  t15373 = 6.4*t12249*t11137;
  t15374 = Power(t11137,2);
  t15375 = 6.4*t15374;
  t15376 = 6.4*t12539*t15224;
  t15377 = t15372 + t15373 + t15375 + t15376;
  t15378 = -0.5*var2[1]*t15377;
  t15379 = -0.5*var2[0]*t15233;
  t15380 = 3.2*t15145*t11137;
  t15383 = 3.2*t15193*t15224;
  t15301 = -2.*t9515*t15177;
  t15302 = -2.*t15159*t10772;
  t15303 = t15259 + t15260 + t15301 + t15265 + t15302 + t15268;
  t15306 = 2.*t9515*t15159;
  t15307 = 2.*t12209*t15177;
  t15308 = t15306 + t15278 + t15279 + t15307 + t15283 + t15284;
  t15323 = -0.5*var2[4]*t15322;
  t15152 = 3.2*t12539*t15145;
  t15183 = 3.2*t12539*t15182;
  t15194 = 3.2*t15193*t11137;
  t15203 = 3.2*t12249*t15202;
  t15205 = t15152 + t15183 + t15194 + t15203;
  t12343 = 3.2*t12036*t12249;
  t12570 = 3.2*t12475*t12539;
  t12728 = 3.2*t12714*t12539;
  t13036 = 3.2*t12932*t11137;
  t13083 = t12343 + t12570 + t12728 + t13036;
  t13187 = -0.5*var2[3]*t13083;
  t15406 = t13188 + t15006;
  t15206 = -0.5*var2[2]*t15205;
  t15356 = 3.2*t14796*t15145;
  t15357 = 3.2*t14796*t15182;
  t15358 = 3.2*t15193*t15035;
  t15359 = 3.2*t13647*t15202;
  t15360 = t15356 + t15357 + t15358 + t15359;
  t15257 = 3.2*t15255*t15086;
  t15258 = 3.2*t15182*t15086;
  t15270 = 3.2*t14952*t15269;
  t15274 = 3.2*t13360*t15273;
  t15275 = 3.2*t13360*t15202;
  t15286 = 3.2*t13360*t15285;
  t15287 = t15246 + t15247 + t15257 + t15258 + t15270 + t15274 + t15275 + t15286;
  t15381 = 3.2*t15255*t11137;
  t15382 = 3.2*t15182*t11137;
  t15384 = 3.2*t12249*t15269;
  t15385 = 3.2*t12539*t15273;
  t15386 = 3.2*t12539*t15202;
  t15387 = 3.2*t12539*t15285;
  t15388 = t15380 + t15381 + t15382 + t15383 + t15384 + t15385 + t15386 + t15387;
  t15300 = 6.4*t15182*t15086;
  t15304 = 3.2*t14952*t15303;
  t15305 = 6.4*t13360*t15202;
  t15309 = 3.2*t13360*t15308;
  t15310 = t15246 + t15247 + t15300 + t15304 + t15305 + t15309;
  t15398 = 6.4*t15182*t11137;
  t15399 = 3.2*t12249*t15303;
  t15400 = 6.4*t12539*t15202;
  t15401 = 3.2*t12539*t15308;
  t15402 = t15380 + t15398 + t15383 + t15399 + t15400 + t15401;
  t15329 = -0.5*var2[4]*t15328;
  t15408 = -0.5*var2[4]*t15205;
  t15460 = 3.2*t12036*t15145;
  t15461 = 3.2*t12714*t15193;
  t15462 = 3.2*t12932*t15182;
  t15463 = 3.2*t12475*t15202;
  t15464 = t15460 + t15461 + t15462 + t15463;
  t15456 = 6.4*t15193*t15182;
  t15457 = 6.4*t15145*t15202;
  t15458 = t15456 + t15457;
  t15343 = 3.2*t12475*t14796;
  t15344 = 3.2*t12714*t14796;
  t15345 = 3.2*t12036*t13647;
  t15346 = 3.2*t12932*t15035;
  t15347 = t15343 + t15344 + t15345 + t15346;
  t15365 = 3.2*t12036*t12539;
  t15367 = 3.2*t12714*t11137;
  t15369 = t15365 + t15366 + t15367 + t15368;
  t15215 = 3.2*t12036*t13360;
  t15218 = 3.2*t12714*t15086;
  t15219 = t15215 + t15216 + t15217 + t15218;
  t15419 = 3.2*t12714*t15255;
  t15420 = 3.2*t12475*t15269;
  t15421 = 3.2*t12036*t15273;
  t15422 = 3.2*t12932*t15285;
  t15423 = t15419 + t15420 + t15421 + t15422;
  t15392 = 3.2*t12714*t12249;
  t15393 = 6.4*t12036*t12539;
  t15394 = 3.2*t15294*t12539;
  t15395 = 6.4*t12714*t11137;
  t15396 = t15392 + t15393 + t15394 + t15366 + t15395 + t15368;
  t15291 = 6.4*t12036*t13360;
  t15295 = 3.2*t15294*t13360;
  t15296 = 3.2*t12714*t14952;
  t15297 = 6.4*t12714*t15086;
  t15298 = t15291 + t15295 + t15296 + t15216 + t15217 + t15297;
  t15436 = 3.2*t12714*t15145;
  t15437 = 3.2*t15294*t15193;
  t15438 = 6.4*t12714*t15182;
  t15439 = 3.2*t12475*t15303;
  t15440 = 6.4*t12036*t15202;
  t15441 = 3.2*t12932*t15308;
  t15442 = t15436 + t15437 + t15438 + t15439 + t15440 + t15441;
  t15335 = -0.5*var2[4]*t15334;
  t15409 = -0.5*var2[4]*t13083;
  t15465 = -0.5*var2[4]*t15464;
  t15495 = 6.4*t12036*t12475;
  t15496 = 6.4*t12714*t12932;
  t15497 = t15495 + t15496;
  t15509 = -0.384*var2[0]*t15213;
  t15510 = -0.384*var2[1]*t15224;
  t11153 = -0.384*var2[4]*t11137;
  p_output1[0]=(t11153 + t13187 + t15206 - 0.5*(6.4*t11137*t13360 + 6.4*t12249*t13360 + 6.4*t12539*t14952 + 6.4*t12539*t15086)*var2[0] - 0.5*t15088*var2[1])*var2[4];
  p_output1[1]=(t15214 + t15234 + t15242 - 0.5*t15287*var2[2] - 0.5*t15219*var2[3])*var2[4];
  p_output1[2]=(t15214 + t15234 + t15242 - 0.5*t15310*var2[2] - 0.5*t15298*var2[3])*var2[4];
  p_output1[3]=-0.5*t15316*var2[4];
  p_output1[4]=t15323;
  p_output1[5]=t15329;
  p_output1[6]=t15335;
  p_output1[7]=-0.5*t15316*var2[0] - 0.5*t15322*var2[1] - 0.5*t15328*var2[2] - 0.5*t15334*var2[3] - 0.768*t15086*var2[4];
  p_output1[8]=var2[4]*(-0.5*t15088*var2[0] - 0.5*(6.4*t12539*t13647 + 6.4*t11137*t14796 + 6.4*t12249*t14796 + 6.4*t12539*t15035)*var2[1] - 0.5*t15360*var2[2] - 0.5*t15347*var2[3] - 0.384*t15035*var2[4]);
  p_output1[9]=(t15364 + t15378 + t15379 - 0.5*t15388*var2[2] - 0.5*t15369*var2[3])*var2[4];
  p_output1[10]=(t15364 + t15378 + t15379 - 0.5*t15402*var2[2] - 0.5*t15396*var2[3])*var2[4];
  p_output1[11]=t15323;
  p_output1[12]=-0.5*t15406*var2[4];
  p_output1[13]=t15408;
  p_output1[14]=t15409;
  p_output1[15]=t13187 + t15206 - 0.5*t15322*var2[0] - 0.5*t15406*var2[1] - 0.768*t11137*var2[4];
  p_output1[16]=(-0.5*t15205*var2[0] - 0.5*t15360*var2[1])*var2[4];
  p_output1[17]=var2[4]*(-0.5*t15287*var2[0] - 0.5*t15388*var2[1] - 0.5*(6.4*t15182*t15255 + 6.4*t15145*t15269 + 6.4*t15202*t15273 + 6.4*t15193*t15285)*var2[2] - 0.5*t15423*var2[3] - 0.384*t15285*var2[4]);
  p_output1[18]=var2[4]*(-0.5*t15310*var2[0] - 0.5*t15402*var2[1] - 0.5*(6.4*Power(t15182,2) + 6.4*Power(t15202,2) + 6.4*t15145*t15303 + 6.4*t15193*t15308)*var2[2] - 0.5*t15442*var2[3] - 0.384*t15308*var2[4]);
  p_output1[19]=t15329;
  p_output1[20]=t15408;
  p_output1[21]=-0.5*t15458*var2[4];
  p_output1[22]=t15465;
  p_output1[23]=-0.5*t15328*var2[0] - 0.5*t15205*var2[1] - 0.5*t15458*var2[2] - 0.5*t15464*var2[3] - 0.768*t15182*var2[4];
  p_output1[24]=(-0.5*t13083*var2[0] - 0.5*t15347*var2[1])*var2[4];
  p_output1[25]=(-0.5*t15219*var2[0] - 0.5*t15369*var2[1] - 0.5*t15423*var2[2])*var2[4];
  p_output1[26]=var2[4]*(-0.5*t15298*var2[0] - 0.5*t15396*var2[1] - 0.5*t15442*var2[2] - 0.5*(6.4*Power(t12036,2) + 6.4*t12475*t12714 + 6.4*Power(t12714,2) + 6.4*t12932*t15294)*var2[3] - 0.384*t15294*var2[4]);
  p_output1[27]=t15335;
  p_output1[28]=t15409;
  p_output1[29]=t15465;
  p_output1[30]=-0.5*t15497*var2[4];
  p_output1[31]=-0.5*t15334*var2[0] - 0.5*t13083*var2[1] - 0.5*t15464*var2[2] - 0.5*t15497*var2[3] - 0.768*t12714*var2[4];
  p_output1[32]=(-0.384*t11137*var2[0] - 0.384*t15035*var2[1])*var2[4];
  p_output1[33]=(t15509 + t15510 - 0.384*t15285*var2[2])*var2[4];
  p_output1[34]=(t15509 + t15510 - 0.384*t15308*var2[2] - 0.384*t15294*var2[3])*var2[4];
  p_output1[35]=-0.384*t15086*var2[4];
  p_output1[36]=t11153;
  p_output1[37]=-0.384*t15182*var2[4];
  p_output1[38]=-0.384*t12714*var2[4];
  p_output1[39]=-0.384*t15086*var2[0] - 0.384*t11137*var2[1] - 0.384*t15182*var2[2] - 0.384*t12714*var2[3];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 40, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce2_vec5_five_link_walker.hh"

namespace RightStance
{

void J_Ce2_vec5_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
