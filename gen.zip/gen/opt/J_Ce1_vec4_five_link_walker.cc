/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:25 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t1099;
  double t253;
  double t290;
  double t55;
  double t3667;
  double t54;
  double t1613;
  double t1705;
  double t1707;
  double t1728;
  double t3579;
  double t6109;
  double t6112;
  double t6122;
  double t188;
  double t331;
  double t332;
  double t1098;
  double t6151;
  double t6152;
  double t6154;
  double t6031;
  double t6086;
  double t6087;
  double t6168;
  double t3606;
  double t3741;
  double t3883;
  double t3932;
  double t6095;
  double t6155;
  double t6159;
  double t6160;
  double t6200;
  double t6203;
  double t6212;
  double t6213;
  double t6214;
  double t6239;
  double t6240;
  double t6244;
  double t6246;
  double t6247;
  double t6252;
  double t6260;
  double t6261;
  double t6263;
  double t6304;
  double t6305;
  double t6306;
  double t6309;
  double t6310;
  double t6311;
  double t6281;
  double t6282;
  double t6284;
  double t6262;
  double t6264;
  double t6277;
  double t6285;
  double t6290;
  double t6337;
  double t6338;
  double t6339;
  double t6340;
  double t6342;
  double t6426;
  double t6427;
  double t6432;
  double t6433;
  double t6434;
  double t6438;
  double t6439;
  double t6442;
  double t6393;
  double t6399;
  double t6405;
  double t6443;
  double t6497;
  double t6498;
  double t6499;
  double t6123;
  double t7891;
  double t7966;
  double t8036;
  double t8061;
  double t6124;
  double t8197;
  double t8625;
  double t6167;
  double t6169;
  double t8652;
  double t8678;
  double t8688;
  double t9538;
  double t9646;
  double t9647;
  double t9648;
  double t9582;
  double t9599;
  double t9602;
  double t9661;
  double t9734;
  double t9801;
  double t6380;
  double t6387;
  double t6388;
  double t6150;
  double t6170;
  double t6171;
  double t6183;
  double t6291;
  double t9880;
  double t9881;
  double t9882;
  double t9863;
  double t9864;
  double t9865;
  double t9892;
  double t9893;
  double t9894;
  double t9885;
  double t9886;
  double t9887;
  double t9884;
  double t9929;
  double t9930;
  double t9895;
  double t9904;
  double t9933;
  double t9934;
  double t9936;
  double t9937;
  double t9918;
  double t9923;
  double t9924;
  double t9925;
  double t9926;
  double t9927;
  double t9928;
  double t9931;
  double t9932;
  double t9935;
  double t9938;
  double t9939;
  double t9940;
  double t9941;
  double t9942;
  double t9943;
  double t9944;
  double t9945;
  double t9946;
  double t9947;
  double t9948;
  double t9949;
  double t9950;
  double t9951;
  double t9952;
  double t9953;
  double t9958;
  double t9959;
  double t9960;
  double t9961;
  double t9979;
  double t9984;
  double t9987;
  double t9988;
  double t9990;
  double t9991;
  double t9992;
  double t9998;
  double t9999;
  double t10000;
  double t10014;
  double t10015;
  double t10016;
  double t10017;
  double t10018;
  double t10406;
  double t10417;
  double t10464;
  t1099 = Cos(var1[4]);
  t253 = Sin(var1[2]);
  t290 = Sin(var1[3]);
  t55 = Cos(var1[3]);
  t3667 = Sin(var1[4]);
  t54 = Cos(var1[2]);
  t1613 = -1.*t1099;
  t1705 = 1. + t1613;
  t1707 = 0.4*t1705;
  t1728 = 0.64*t1099;
  t3579 = t1707 + t1728;
  t6109 = t55*t1099;
  t6112 = -1.*t290*t3667;
  t6122 = t6109 + t6112;
  t188 = -1.*t54*t55;
  t331 = t253*t290;
  t332 = t188 + t331;
  t1098 = 0.748*t332;
  t6151 = t3579*t3667;
  t6152 = -0.24*t1099*t3667;
  t6154 = t6151 + t6152;
  t6031 = -1.*t1099*t290;
  t6086 = -1.*t55*t3667;
  t6087 = t6031 + t6086;
  t6168 = -1.*t253*t6122;
  t3606 = t3579*t1099;
  t3741 = Power(t3667,2);
  t3883 = 0.24*t3741;
  t3932 = t3606 + t3883;
  t6095 = -1.*t253*t6087;
  t6155 = t1099*t290;
  t6159 = t55*t3667;
  t6160 = t6155 + t6159;
  t6200 = t54*t6087;
  t6203 = t6200 + t6168;
  t6212 = 3.2*t6154*t6203;
  t6213 = -1.*t55*t1099;
  t6214 = t290*t3667;
  t6239 = t6213 + t6214;
  t6240 = t54*t6239;
  t6244 = t6095 + t6240;
  t6246 = 3.2*t3932*t6244;
  t6247 = t1098 + t6212 + t6246;
  t6252 = Power(t1099,2);
  t6260 = -0.24*t6252;
  t6261 = t3606 + t6260;
  t6263 = t54*t6122;
  t6304 = t253*t6160;
  t6305 = t6304 + t6240;
  t6306 = 3.2*t3932*t6305;
  t6309 = t253*t6239;
  t6310 = t6200 + t6309;
  t6311 = 3.2*t6154*t6310;
  t6281 = -1.*t3579*t3667;
  t6282 = 0.24*t1099*t3667;
  t6284 = t6281 + t6282;
  t6262 = -1.*t253*t6160;
  t6264 = t6262 + t6263;
  t6277 = 3.2*t6261*t6264;
  t6285 = 3.2*t6284*t6203;
  t6290 = t6277 + t6212 + t6285 + t6246;
  t6337 = t253*t6087;
  t6338 = t6337 + t6263;
  t6339 = 3.2*t6261*t6338;
  t6340 = 3.2*t6284*t6310;
  t6342 = t6339 + t6306 + t6311 + t6340;
  t6426 = -1.*t55*t253;
  t6427 = -1.*t54*t290;
  t6432 = t6426 + t6427;
  t6433 = 0.748*t6432;
  t6434 = 3.2*t6154*t6264;
  t6438 = 3.2*t3932*t6203;
  t6439 = t6433 + t6434 + t6438;
  t6442 = 3.2*t6154*t6338;
  t6393 = t54*t6160;
  t6399 = t253*t6122;
  t6405 = t6393 + t6399;
  t6443 = 3.2*t3932*t6310;
  t6497 = 3.2*t6284*t6338;
  t6498 = 3.2*t6261*t6405;
  t6499 = t6442 + t6497 + t6498 + t6443;
  t6123 = -1.*t54*t6122;
  t7891 = t55*t253;
  t7966 = t54*t290;
  t8036 = t7891 + t7966;
  t8061 = 0.748*t8036;
  t6124 = t6095 + t6123;
  t8197 = -1.*t54*t6087;
  t8625 = 3.2*t6154*t6124;
  t6167 = -1.*t54*t6160;
  t6169 = t6167 + t6168;
  t8652 = -1.*t253*t6239;
  t8678 = t8197 + t8652;
  t8688 = 3.2*t3932*t8678;
  t9538 = t8061 + t8625 + t8688;
  t9646 = 3.2*t6154*t6244;
  t9647 = t6393 + t8652;
  t9648 = 3.2*t3932*t9647;
  t9582 = 3.2*t6284*t6124;
  t9599 = 3.2*t6261*t6169;
  t9602 = t8625 + t9582 + t9599 + t8688;
  t9661 = 3.2*t6261*t6203;
  t9734 = 3.2*t6284*t6244;
  t9801 = t9661 + t9646 + t9734 + t9648;
  t6380 = -1.*t3579*t1099;
  t6387 = 0.24*t6252;
  t6388 = t6380 + t6387;
  t6150 = 3.2*t3932*t6124;
  t6170 = 3.2*t6154*t6169;
  t6171 = t1098 + t6150 + t6170;
  t6183 = -0.5*var2[2]*t6171;
  t6291 = -0.5*var2[4]*t6290;
  t9880 = t55*t3579;
  t9881 = -0.24*t290*t3667;
  t9882 = t9880 + t9881;
  t9863 = -1.*t3579*t290;
  t9864 = -0.24*t55*t3667;
  t9865 = t9863 + t9864;
  t9892 = t3579*t290;
  t9893 = 0.24*t55*t3667;
  t9894 = t9892 + t9893;
  t9885 = -1.*t55*t3579;
  t9886 = 0.24*t290*t3667;
  t9887 = t9885 + t9886;
  t9884 = -1.*t6160*t9882;
  t9929 = -0.24*t1099*t290;
  t9930 = t9929 + t9864;
  t9895 = -1.*t9894*t6239;
  t9904 = t6087*t9894;
  t9933 = 0.24*t55*t1099;
  t9934 = t9933 + t9881;
  t9936 = -0.24*t55*t1099;
  t9937 = t9936 + t9886;
  t9918 = t9882*t6239;
  t9923 = t9865*t6122;
  t9924 = t9894*t6122;
  t9925 = t6087*t9882;
  t9926 = t6160*t9882;
  t9927 = t9923 + t9924 + t9925 + t9926;
  t9928 = 3.2*t6284*t9927;
  t9931 = -1.*t9930*t6122;
  t9932 = -1.*t6087*t9882;
  t9935 = -1.*t6087*t9934;
  t9938 = -1.*t6087*t9937;
  t9939 = -1.*t9865*t6239;
  t9940 = -1.*t9930*t6239;
  t9941 = t9931 + t9932 + t9884 + t9935 + t9938 + t9939 + t9940 + t9895;
  t9942 = 3.2*t6154*t9941;
  t9943 = -1.*t6087*t9865;
  t9944 = -1.*t6087*t9894;
  t9945 = -1.*t6122*t9882;
  t9946 = -1.*t9882*t6239;
  t9947 = t9943 + t9944 + t9945 + t9946;
  t9948 = 3.2*t6261*t9947;
  t9949 = t6087*t9865;
  t9950 = t6087*t9930;
  t9951 = t9930*t6160;
  t9952 = t6122*t9882;
  t9953 = t6122*t9934;
  t9958 = t6122*t9937;
  t9959 = t9949 + t9950 + t9904 + t9951 + t9952 + t9953 + t9958 + t9918;
  t9960 = 3.2*t3932*t9959;
  t9961 = t9928 + t9942 + t9948 + t9960;
  t9979 = -1.*t9894*t6122;
  t9984 = t9979 + t9932;
  t9987 = t9894*t6160;
  t9988 = t9987 + t9952;
  t9990 = t9930*t6122;
  t9991 = t6160*t9934;
  t9992 = t9990 + t9924 + t9925 + t9991;
  t9998 = -1.*t6087*t9930;
  t9999 = -1.*t6122*t9934;
  t10000 = t9998 + t9944 + t9999 + t9946;
  t10014 = 3.2*t6261*t9984;
  t10015 = 3.2*t6284*t9988;
  t10016 = 3.2*t3932*t9992;
  t10017 = 3.2*t6154*t10000;
  t10018 = t10014 + t10015 + t10016 + t10017;
  t10406 = 6.4*t6261*t6154;
  t10417 = 6.4*t6284*t3932;
  t10464 = t10406 + t10417;
  p_output1[0]=var2[3]*(t6183 + t6291 - 0.5*t6247*var2[3]);
  p_output1[1]=var2[3]*(-0.5*t6247*var2[2] - 0.5*(t1098 + t6306 + t6311)*var2[3] - 0.5*t6342*var2[4]);
  p_output1[2]=var2[3]*(-0.5*t6290*var2[2] - 0.5*t6342*var2[3] - 0.5*(t6306 + 6.4*t6284*t6310 + t6311 + 6.4*t6261*t6338 + 3.2*t6338*t6388 + 3.2*t6284*t6405)*var2[4]);
  p_output1[3]=-0.5*t6439*var2[3];
  p_output1[4]=-0.5*t6439*var2[2] - 1.*(t6433 + t6442 + t6443)*var2[3] - 0.5*t6499*var2[4];
  p_output1[5]=-0.5*t6499*var2[3];
  p_output1[6]=var2[3]*(-0.5*(3.2*t6154*(t6123 + t6304) + t8061 + 3.2*t3932*(t6399 + t8197))*var2[2] - 0.5*t9538*var2[3] - 0.5*t9602*var2[4]);
  p_output1[7]=var2[3]*(-0.5*t9538*var2[2] - 0.5*(t8061 + t9646 + t9648)*var2[3] - 0.5*t9801*var2[4]);
  p_output1[8]=var2[3]*(-0.5*t9602*var2[2] - 0.5*t9801*var2[3] - 0.5*(6.4*t6203*t6261 + 6.4*t6244*t6284 + 3.2*t6264*t6284 + 3.2*t6203*t6388 + t9646 + t9648)*var2[4]);
  p_output1[9]=-0.5*t6171*var2[3];
  p_output1[10]=t6183 + t6291 - 1.*t6247*var2[3];
  p_output1[11]=-0.5*t6290*var2[3];
  p_output1[12]=var2[3]*(-0.5*(3.2*t6154*(-1.*t6122*t9865 - 2.*t6239*t9865 - 2.*t6087*t9882 + t9884 - 1.*t6087*t9887 + t9895) + 3.2*t3932*(2.*t6087*t9865 + t6160*t9865 + 2.*t6122*t9882 + t6122*t9887 + t9904 + t9918))*var2[3] - 0.5*t9961*var2[4]);
  p_output1[13]=var2[3]*(-0.5*t9961*var2[3] - 0.5*(6.4*t10000*t6261 + 3.2*t6154*(t9884 + t9895 - 2.*t6239*t9930 + t9931 - 2.*t6087*t9934 + t9938) + 3.2*t3932*(t9904 + t9918 + 2.*t6087*t9930 + 2.*t6122*t9934 + t9951 + t9958) + 3.2*t6284*t9984 + 3.2*t6388*t9988 + 6.4*t6284*t9992)*var2[4]);
  p_output1[14]=-1.*(3.2*t3932*t9927 + 3.2*t6154*t9947)*var2[3] - 0.5*t10018*var2[4];
  p_output1[15]=-0.5*t10018*var2[3];
  p_output1[16]=-0.5*(6.4*Power(t6261,2) + 6.4*t6154*t6284 + 6.4*Power(t6284,2) + 6.4*t3932*t6388)*var2[3]*var2[4];
  p_output1[17]=-0.5*t10464*var2[4];
  p_output1[18]=-0.5*t10464*var2[3];
  p_output1[19]=-0.384*t6388*var2[3]*var2[4];
  p_output1[20]=-0.384*t6284*var2[4];
  p_output1[21]=-0.384*t6284*var2[3];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 22, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce1_vec4_five_link_walker.hh"

namespace RightStance
{

void J_Ce1_vec4_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
