/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:42 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t14127;
  double t4100;
  double t12270;
  double t14131;
  double t14148;
  double t4066;
  double t14150;
  double t14151;
  double t14152;
  double t14196;
  double t14197;
  double t14198;
  double t14201;
  double t14204;
  double t14126;
  double t14140;
  double t14141;
  double t14142;
  double t14155;
  double t14160;
  double t14225;
  double t14222;
  double t14223;
  double t14226;
  double t14230;
  double t14231;
  double t14232;
  double t14240;
  double t14241;
  double t14242;
  double t14243;
  double t14244;
  double t14224;
  double t14227;
  double t14228;
  double t14229;
  double t14233;
  double t14234;
  double t14162;
  double t14171;
  double t14181;
  double t14262;
  double t14263;
  double t14264;
  double t14212;
  double t14208;
  double t14209;
  double t14210;
  double t14211;
  double t14213;
  double t14236;
  double t14237;
  double t14238;
  double t14277;
  double t14278;
  double t14279;
  double t14252;
  double t14248;
  double t14249;
  double t14250;
  double t14251;
  double t14253;
  double t14266;
  double t14267;
  double t14268;
  double t14270;
  double t14271;
  double t14273;
  double t14274;
  double t14275;
  double t14281;
  double t14282;
  double t14283;
  double t14285;
  double t14286;
  double t14288;
  double t14289;
  double t14290;
  double t14343;
  double t14344;
  double t14345;
  double t14347;
  double t14348;
  double t14349;
  double t14363;
  double t14364;
  double t14365;
  double t14367;
  double t14368;
  double t14369;
  double t14303;
  double t14304;
  double t14305;
  double t14299;
  double t14300;
  double t14301;
  double t14215;
  double t14216;
  double t14217;
  double t14218;
  double t14205;
  double t14206;
  double t14207;
  double t14311;
  double t14312;
  double t14323;
  double t14324;
  double t14325;
  double t14319;
  double t14320;
  double t14321;
  double t14255;
  double t14256;
  double t14257;
  double t14258;
  double t14245;
  double t14246;
  double t14247;
  double t14331;
  double t14332;
  double t14265;
  double t14280;
  double t14294;
  double t14295;
  double t14296;
  double t14297;
  double t14298;
  double t14302;
  double t14306;
  double t14307;
  double t14308;
  double t14309;
  double t14310;
  double t14313;
  double t14314;
  double t14315;
  double t14316;
  double t14317;
  double t14318;
  double t14322;
  double t14326;
  double t14327;
  double t14328;
  double t14329;
  double t14330;
  double t14333;
  double t14334;
  double t14337;
  double t14338;
  double t14339;
  double t14340;
  double t14341;
  double t14346;
  double t14350;
  double t14351;
  double t14353;
  double t14354;
  double t14355;
  double t14357;
  double t14358;
  double t14359;
  double t14360;
  double t14361;
  double t14366;
  double t14370;
  double t14371;
  double t14373;
  double t14374;
  double t14375;
  double t14402;
  double t14403;
  double t14404;
  double t14405;
  double t14406;
  double t14407;
  double t14408;
  double t14409;
  double t14336;
  double t14342;
  double t14352;
  double t14356;
  double t14362;
  double t14372;
  double t14376;
  double t14377;
  double t14182;
  double t14214;
  double t14219;
  double t14220;
  double t14382;
  double t14383;
  double t14384;
  double t14385;
  double t14239;
  double t14254;
  double t14259;
  double t14260;
  double t14388;
  double t14389;
  double t14390;
  double t14391;
  t14127 = Cos(var1[3]);
  t4100 = Cos(var1[4]);
  t12270 = Sin(var1[3]);
  t14131 = Sin(var1[4]);
  t14148 = Sin(var1[2]);
  t4066 = Cos(var1[2]);
  t14150 = t14127*t4100;
  t14151 = -1.*t12270*t14131;
  t14152 = t14150 + t14151;
  t14196 = -1.*t4100;
  t14197 = 1. + t14196;
  t14198 = 0.4*t14197;
  t14201 = 0.64*t4100;
  t14204 = t14198 + t14201;
  t14126 = -1.*t4100*t12270;
  t14140 = -1.*t14127*t14131;
  t14141 = t14126 + t14140;
  t14142 = t4066*t14141;
  t14155 = -1.*t14148*t14152;
  t14160 = t14142 + t14155;
  t14225 = Cos(var1[5]);
  t14222 = Cos(var1[6]);
  t14223 = Sin(var1[5]);
  t14226 = Sin(var1[6]);
  t14230 = t14225*t14222;
  t14231 = -1.*t14223*t14226;
  t14232 = t14230 + t14231;
  t14240 = -1.*t14222;
  t14241 = 1. + t14240;
  t14242 = 0.4*t14241;
  t14243 = 0.64*t14222;
  t14244 = t14242 + t14243;
  t14224 = -1.*t14222*t14223;
  t14227 = -1.*t14225*t14226;
  t14228 = t14224 + t14227;
  t14229 = t4066*t14228;
  t14233 = -1.*t14148*t14232;
  t14234 = t14229 + t14233;
  t14162 = -1.*t14127*t14148;
  t14171 = -1.*t4066*t12270;
  t14181 = t14162 + t14171;
  t14262 = t4066*t14127;
  t14263 = -1.*t14148*t12270;
  t14264 = t14262 + t14263;
  t14212 = t4066*t14152;
  t14208 = t4100*t12270;
  t14209 = t14127*t14131;
  t14210 = t14208 + t14209;
  t14211 = -1.*t14148*t14210;
  t14213 = t14211 + t14212;
  t14236 = -1.*t14225*t14148;
  t14237 = -1.*t4066*t14223;
  t14238 = t14236 + t14237;
  t14277 = t4066*t14225;
  t14278 = -1.*t14148*t14223;
  t14279 = t14277 + t14278;
  t14252 = t4066*t14232;
  t14248 = t14222*t14223;
  t14249 = t14225*t14226;
  t14250 = t14248 + t14249;
  t14251 = -1.*t14148*t14250;
  t14253 = t14251 + t14252;
  t14266 = t14127*t14148;
  t14267 = t4066*t12270;
  t14268 = t14266 + t14267;
  t14270 = t14148*t14141;
  t14271 = t14270 + t14212;
  t14273 = t4066*t14210;
  t14274 = t14148*t14152;
  t14275 = t14273 + t14274;
  t14281 = t14225*t14148;
  t14282 = t4066*t14223;
  t14283 = t14281 + t14282;
  t14285 = t14148*t14228;
  t14286 = t14285 + t14252;
  t14288 = t4066*t14250;
  t14289 = t14148*t14232;
  t14290 = t14288 + t14289;
  t14343 = t14204*t12270;
  t14344 = 0.24*t14127*t14131;
  t14345 = t14343 + t14344;
  t14347 = t14127*t14204;
  t14348 = -0.24*t12270*t14131;
  t14349 = t14347 + t14348;
  t14363 = t14244*t14223;
  t14364 = 0.24*t14225*t14226;
  t14365 = t14363 + t14364;
  t14367 = t14225*t14244;
  t14368 = -0.24*t14223*t14226;
  t14369 = t14367 + t14368;
  t14303 = -1.*t14148*t14141;
  t14304 = -1.*t4066*t14152;
  t14305 = t14303 + t14304;
  t14299 = -1.*t4066*t14127;
  t14300 = t14148*t12270;
  t14301 = t14299 + t14300;
  t14215 = t14204*t4100;
  t14216 = Power(t14131,2);
  t14217 = 0.24*t14216;
  t14218 = t14215 + t14217;
  t14205 = t14204*t14131;
  t14206 = -0.24*t4100*t14131;
  t14207 = t14205 + t14206;
  t14311 = -1.*t4066*t14210;
  t14312 = t14311 + t14155;
  t14323 = -1.*t14148*t14228;
  t14324 = -1.*t4066*t14232;
  t14325 = t14323 + t14324;
  t14319 = -1.*t4066*t14225;
  t14320 = t14148*t14223;
  t14321 = t14319 + t14320;
  t14255 = t14244*t14222;
  t14256 = Power(t14226,2);
  t14257 = 0.24*t14256;
  t14258 = t14255 + t14257;
  t14245 = t14244*t14226;
  t14246 = -0.24*t14222*t14226;
  t14247 = t14245 + t14246;
  t14331 = -1.*t4066*t14250;
  t14332 = t14331 + t14233;
  t14265 = 13.6*t14181*t14264;
  t14280 = 13.6*t14238*t14279;
  t14294 = Power(t14181,2);
  t14295 = 6.8*t14294;
  t14296 = 6.8*t14181*t14268;
  t14297 = Power(t14264,2);
  t14298 = 6.8*t14297;
  t14302 = 6.8*t14264*t14301;
  t14306 = 3.2*t14305*t14271;
  t14307 = Power(t14213,2);
  t14308 = 3.2*t14307;
  t14309 = Power(t14160,2);
  t14310 = 3.2*t14309;
  t14313 = 3.2*t14312*t14275;
  t14314 = Power(t14238,2);
  t14315 = 6.8*t14314;
  t14316 = 6.8*t14238*t14283;
  t14317 = Power(t14279,2);
  t14318 = 6.8*t14317;
  t14322 = 6.8*t14279*t14321;
  t14326 = 3.2*t14325*t14286;
  t14327 = Power(t14253,2);
  t14328 = 3.2*t14327;
  t14329 = Power(t14234,2);
  t14330 = 3.2*t14329;
  t14333 = 3.2*t14332*t14290;
  t14334 = t14295 + t14296 + t14298 + t14302 + t14306 + t14308 + t14310 + t14313 + t14315 + t14316 + t14318 + t14322 + t14326 + t14328 + t14330 + t14333;
  t14337 = Power(t14127,2);
  t14338 = 0.11*t14337;
  t14339 = Power(t12270,2);
  t14340 = 0.11*t14339;
  t14341 = t14338 + t14340;
  t14346 = -1.*t14345*t14152;
  t14350 = -1.*t14141*t14349;
  t14351 = t14346 + t14350;
  t14353 = t14345*t14210;
  t14354 = t14152*t14349;
  t14355 = t14353 + t14354;
  t14357 = Power(t14225,2);
  t14358 = 0.11*t14357;
  t14359 = Power(t14223,2);
  t14360 = 0.11*t14359;
  t14361 = t14358 + t14360;
  t14366 = -1.*t14365*t14232;
  t14370 = -1.*t14228*t14369;
  t14371 = t14366 + t14370;
  t14373 = t14365*t14250;
  t14374 = t14232*t14369;
  t14375 = t14373 + t14374;
  t14402 = -2.88*t4066;
  t14403 = 6.8*t14301*t14341;
  t14404 = 3.2*t14312*t14351;
  t14405 = 3.2*t14305*t14355;
  t14406 = 6.8*t14321*t14361;
  t14407 = 3.2*t14332*t14371;
  t14408 = 3.2*t14325*t14375;
  t14409 = t14402 + t14403 + t14404 + t14405 + t14406 + t14407 + t14408;
  t14336 = -2.88*t14148;
  t14342 = 6.8*t14181*t14341;
  t14352 = 3.2*t14213*t14351;
  t14356 = 3.2*t14160*t14355;
  t14362 = 6.8*t14238*t14361;
  t14372 = 3.2*t14253*t14371;
  t14376 = 3.2*t14234*t14375;
  t14377 = t14336 + t14342 + t14352 + t14356 + t14362 + t14372 + t14376;
  t14182 = 0.748*t14181;
  t14214 = 3.2*t14207*t14213;
  t14219 = 3.2*t14218*t14160;
  t14220 = t14182 + t14214 + t14219;
  t14382 = 0.748*t14301;
  t14383 = 3.2*t14218*t14305;
  t14384 = 3.2*t14207*t14312;
  t14385 = t14382 + t14383 + t14384;
  t14239 = 0.748*t14238;
  t14254 = 3.2*t14247*t14253;
  t14259 = 3.2*t14258*t14234;
  t14260 = t14239 + t14254 + t14259;
  t14388 = 0.748*t14321;
  t14389 = 3.2*t14258*t14325;
  t14390 = 3.2*t14247*t14332;
  t14391 = t14388 + t14389 + t14390;
  p_output1[0]=var2[2]*(-0.5*(t14265 + 13.6*t14264*t14268 + 6.4*t14160*t14271 + 6.4*t14213*t14275 + t14280 + 13.6*t14279*t14283 + 6.4*t14234*t14286 + 6.4*t14253*t14290)*var2[0] - 0.5*t14334*var2[1] - 0.5*t14377*var2[2] - 0.5*t14220*var2[3] - 0.384*t14160*var2[4] - 0.5*t14260*var2[5] - 0.384*t14234*var2[6]);
  p_output1[1]=var2[2]*(-0.5*t14334*var2[0] - 0.5*(t14265 + t14280 + 13.6*t14181*t14301 + 6.4*t14160*t14305 + 6.4*t14213*t14312 + 13.6*t14238*t14321 + 6.4*t14234*t14325 + 6.4*t14253*t14332)*var2[1] - 0.5*t14409*var2[2] - 0.5*t14385*var2[3] - 0.384*t14305*var2[4] - 0.5*t14391*var2[5] - 0.384*t14325*var2[6]);
  p_output1[2]=(-0.5*t14377*var2[0] - 0.5*t14409*var2[1])*var2[2];
  p_output1[3]=(-0.5*t14220*var2[0] - 0.5*t14385*var2[1])*var2[2];
  p_output1[4]=(-0.384*t14160*var2[0] - 0.384*t14305*var2[1])*var2[2];
  p_output1[5]=(-0.5*t14260*var2[0] - 0.5*t14391*var2[1])*var2[2];
  p_output1[6]=(-0.384*t14234*var2[0] - 0.384*t14325*var2[1])*var2[2];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce2_vec3_five_link_walker.hh"

namespace RightStance
{

void Ce2_vec3_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
