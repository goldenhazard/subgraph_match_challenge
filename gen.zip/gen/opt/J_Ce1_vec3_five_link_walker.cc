/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:22 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t74;
  double t1704;
  double t35;
  double t1603;
  double t5789;
  double t5791;
  double t5796;
  double t5799;
  double t5800;
  double t5790;
  double t5792;
  double t5794;
  double t5824;
  double t5826;
  double t5827;
  double t5872;
  double t5884;
  double t5795;
  double t5801;
  double t5802;
  double t5891;
  double t5892;
  double t5894;
  double t5897;
  double t5898;
  double t5917;
  double t5935;
  double t5936;
  double t5937;
  double t5924;
  double t5925;
  double t5926;
  double t5945;
  double t5946;
  double t5947;
  double t5895;
  double t5918;
  double t5922;
  double t5923;
  double t5928;
  double t5929;
  double t5941;
  double t5942;
  double t5943;
  double t5944;
  double t5948;
  double t5949;
  double t5950;
  double t5951;
  double t5952;
  double t5953;
  double t5962;
  double t5963;
  double t5955;
  double t5965;
  double t5966;
  double t5957;
  double t1116;
  double t3791;
  double t3792;
  double t3834;
  double t3956;
  double t5748;
  double t5752;
  double t5782;
  double t5788;
  double t5983;
  double t5985;
  double t5994;
  double t5996;
  double t6000;
  double t6001;
  double t6002;
  double t6005;
  double t6006;
  double t6007;
  double t6008;
  double t6009;
  double t6014;
  double t6015;
  double t6016;
  double t6010;
  double t6011;
  double t6012;
  double t5995;
  double t5997;
  double t5998;
  double t6017;
  double t6018;
  double t6019;
  double t5984;
  double t5986;
  double t5987;
  double t5988;
  double t5989;
  double t5990;
  double t5991;
  double t5992;
  double t5993;
  double t6003;
  double t6013;
  double t6020;
  double t6021;
  double t6032;
  double t6033;
  double t6026;
  double t6027;
  double t6028;
  double t6023;
  double t6035;
  double t6036;
  double t6037;
  double t6045;
  double t6046;
  double t6047;
  double t6034;
  double t6039;
  double t6040;
  double t6048;
  double t6049;
  double t6050;
  double t6052;
  double t6054;
  double t6057;
  double t6072;
  double t6073;
  double t6059;
  double t6075;
  double t6076;
  double t6061;
  double t5927;
  double t5938;
  double t5939;
  double t5940;
  double t5954;
  double t5956;
  double t5958;
  double t5959;
  double t5960;
  double t6092;
  double t6093;
  double t6110;
  double t6111;
  double t6102;
  double t6103;
  double t6104;
  double t6089;
  double t6090;
  double t6091;
  double t6094;
  double t5964;
  double t5967;
  double t5968;
  double t6096;
  double t6097;
  double t6098;
  double t6101;
  double t6107;
  double t5970;
  double t5971;
  double t5972;
  double t6116;
  double t6130;
  double t6131;
  double t6120;
  double t5969;
  double t5973;
  double t5974;
  double t6126;
  double t6127;
  double t6128;
  double t6129;
  double t6132;
  double t6133;
  double t6134;
  double t6135;
  double t6136;
  double t6138;
  double t6139;
  double t6140;
  double t6141;
  double t6144;
  double t6145;
  double t6146;
  double t6147;
  double t6148;
  double t6149;
  double t6038;
  double t6041;
  double t6042;
  double t6043;
  double t6058;
  double t6060;
  double t6062;
  double t6064;
  double t6066;
  double t6180;
  double t6181;
  double t6201;
  double t6202;
  double t6190;
  double t6191;
  double t6195;
  double t6173;
  double t6175;
  double t6179;
  double t6182;
  double t6074;
  double t6077;
  double t6078;
  double t6184;
  double t6185;
  double t6186;
  double t6189;
  double t6198;
  double t6080;
  double t6081;
  double t6082;
  double t6206;
  double t6220;
  double t6223;
  double t6210;
  double t6079;
  double t6083;
  double t6084;
  double t6215;
  double t6217;
  double t6218;
  double t6219;
  double t6224;
  double t6225;
  double t6226;
  double t6227;
  double t6228;
  double t6229;
  double t6230;
  double t6231;
  double t6232;
  double t6233;
  double t6234;
  double t6235;
  double t6236;
  double t6237;
  double t6238;
  double t6269;
  double t6274;
  double t6265;
  double t6266;
  double t6267;
  double t6268;
  double t6286;
  double t6287;
  double t6288;
  double t6289;
  double t6294;
  double t6296;
  double t6270;
  double t6275;
  double t6276;
  double t6278;
  double t6279;
  double t6280;
  double t6295;
  double t6297;
  double t6298;
  double t6300;
  double t6301;
  double t6303;
  double t5980;
  double t5981;
  double t5977;
  double t5978;
  double t6319;
  double t6321;
  double t6322;
  double t6323;
  double t6326;
  double t6312;
  double t6316;
  double t6317;
  double t6318;
  double t6024;
  double t6343;
  double t6350;
  double t6351;
  double t6361;
  double t6025;
  double t6364;
  double t5999;
  double t6004;
  double t6372;
  double t6374;
  double t6375;
  double t6377;
  double t6320;
  double t6327;
  double t6328;
  double t6099;
  double t6100;
  double t6105;
  double t6106;
  double t6108;
  double t6113;
  double t6117;
  double t6118;
  double t6119;
  double t6121;
  double t6394;
  double t6400;
  double t6401;
  double t6331;
  double t6332;
  double t6333;
  double t6411;
  double t6412;
  double t6413;
  double t6417;
  double t6418;
  double t6419;
  double t6420;
  double t6156;
  double t6157;
  double t6158;
  double t6161;
  double t6165;
  double t6166;
  double t6373;
  double t6378;
  double t6379;
  double t6187;
  double t6188;
  double t6196;
  double t6197;
  double t6199;
  double t6205;
  double t6207;
  double t6208;
  double t6209;
  double t6211;
  double t6450;
  double t6452;
  double t6453;
  double t6384;
  double t6385;
  double t6386;
  double t6524;
  double t6525;
  double t6526;
  double t7882;
  double t7919;
  double t8016;
  double t8031;
  double t6248;
  double t6249;
  double t6250;
  double t6254;
  double t6258;
  double t6259;
  double t5961;
  double t5975;
  double t5976;
  double t5979;
  double t5982;
  double t6022;
  double t6029;
  double t6030;
  double t6071;
  double t6085;
  double t6088;
  double t6153;
  double t6172;
  double t6245;
  double t9748;
  double t9790;
  double t9791;
  double t9809;
  double t10250;
  double t10896;
  double t10897;
  double t10899;
  double t10900;
  double t10953;
  double t11390;
  double t11414;
  double t11415;
  double t11441;
  double t11448;
  double t11456;
  double t11476;
  double t11520;
  double t11529;
  double t11566;
  double t11569;
  double t11582;
  double t11634;
  double t11637;
  double t11652;
  double t11662;
  double t11663;
  double t11664;
  double t11674;
  double t11684;
  double t11687;
  double t11689;
  double t11707;
  double t11708;
  double t11724;
  double t11726;
  double t11728;
  double t11730;
  double t11732;
  double t11749;
  double t11897;
  double t11922;
  double t11941;
  double t11970;
  double t11975;
  double t11980;
  double t11982;
  double t12011;
  double t12231;
  double t12234;
  double t12254;
  double t12283;
  double t12300;
  double t12309;
  double t12315;
  double t12357;
  double t12360;
  double t12361;
  double t12363;
  double t12369;
  double t12374;
  double t12375;
  double t12381;
  double t12384;
  double t12387;
  double t12398;
  double t12632;
  double t12637;
  double t12651;
  double t12701;
  double t12737;
  double t12745;
  double t12746;
  double t12748;
  t74 = Cos(var1[3]);
  t1704 = Sin(var1[3]);
  t35 = Cos(var1[2]);
  t1603 = Sin(var1[2]);
  t5789 = Cos(var1[4]);
  t5791 = Sin(var1[4]);
  t5796 = t74*t5789;
  t5799 = -1.*t1704*t5791;
  t5800 = t5796 + t5799;
  t5790 = -1.*t5789*t1704;
  t5792 = -1.*t74*t5791;
  t5794 = t5790 + t5792;
  t5824 = -1.*t5789;
  t5826 = 1. + t5824;
  t5827 = 0.4*t5826;
  t5872 = 0.64*t5789;
  t5884 = t5827 + t5872;
  t5795 = t35*t5794;
  t5801 = -1.*t1603*t5800;
  t5802 = t5795 + t5801;
  t5891 = t5884*t1704;
  t5892 = 0.24*t74*t5791;
  t5894 = t5891 + t5892;
  t5897 = t74*t5884;
  t5898 = -0.24*t1704*t5791;
  t5917 = t5897 + t5898;
  t5935 = t5789*t1704;
  t5936 = t74*t5791;
  t5937 = t5935 + t5936;
  t5924 = -1.*t5884*t1704;
  t5925 = -0.24*t74*t5791;
  t5926 = t5924 + t5925;
  t5945 = -1.*t74*t5789;
  t5946 = t1704*t5791;
  t5947 = t5945 + t5946;
  t5895 = -1.*t5894*t5800;
  t5918 = -1.*t5794*t5917;
  t5922 = t5895 + t5918;
  t5923 = 3.2*t5802*t5922;
  t5928 = t5894*t5800;
  t5929 = t5794*t5917;
  t5941 = t5894*t5937;
  t5942 = t5800*t5917;
  t5943 = t5941 + t5942;
  t5944 = -1.*t1603*t5794;
  t5948 = t35*t5947;
  t5949 = t5944 + t5948;
  t5950 = 3.2*t5943*t5949;
  t5951 = -1.*t1603*t5937;
  t5952 = t35*t5800;
  t5953 = t5951 + t5952;
  t5962 = -0.24*t5789*t1704;
  t5963 = t5962 + t5925;
  t5955 = -1.*t5794*t5894;
  t5965 = 0.24*t74*t5789;
  t5966 = t5965 + t5898;
  t5957 = -1.*t5917*t5947;
  t1116 = -1.*t35*t74;
  t3791 = t1603*t1704;
  t3792 = t1116 + t3791;
  t3834 = Power(t74,2);
  t3956 = 0.11*t3834;
  t5748 = Power(t1704,2);
  t5752 = 0.11*t5748;
  t5782 = t3956 + t5752;
  t5788 = 6.8*t3792*t5782;
  t5983 = Cos(var1[5]);
  t5985 = Sin(var1[5]);
  t5994 = Cos(var1[6]);
  t5996 = Sin(var1[6]);
  t6000 = t5983*t5994;
  t6001 = -1.*t5985*t5996;
  t6002 = t6000 + t6001;
  t6005 = -1.*t5994;
  t6006 = 1. + t6005;
  t6007 = 0.4*t6006;
  t6008 = 0.64*t5994;
  t6009 = t6007 + t6008;
  t6014 = -1.*t5994*t5985;
  t6015 = -1.*t5983*t5996;
  t6016 = t6014 + t6015;
  t6010 = t6009*t5985;
  t6011 = 0.24*t5983*t5996;
  t6012 = t6010 + t6011;
  t5995 = t5994*t5985;
  t5997 = t5983*t5996;
  t5998 = t5995 + t5997;
  t6017 = t5983*t6009;
  t6018 = -0.24*t5985*t5996;
  t6019 = t6017 + t6018;
  t5984 = -1.*t35*t5983;
  t5986 = t1603*t5985;
  t5987 = t5984 + t5986;
  t5988 = Power(t5983,2);
  t5989 = 0.11*t5988;
  t5990 = Power(t5985,2);
  t5991 = 0.11*t5990;
  t5992 = t5989 + t5991;
  t5993 = 6.8*t5987*t5992;
  t6003 = -1.*t1603*t6002;
  t6013 = -1.*t6012*t6002;
  t6020 = -1.*t6016*t6019;
  t6021 = t6013 + t6020;
  t6032 = t35*t6016;
  t6033 = t6032 + t6003;
  t6026 = t6012*t5998;
  t6027 = t6002*t6019;
  t6028 = t6026 + t6027;
  t6023 = -1.*t1603*t6016;
  t6035 = -1.*t6009*t5985;
  t6036 = -0.24*t5983*t5996;
  t6037 = t6035 + t6036;
  t6045 = -1.*t5983*t5994;
  t6046 = t5985*t5996;
  t6047 = t6045 + t6046;
  t6034 = 3.2*t6033*t6021;
  t6039 = t6012*t6002;
  t6040 = t6016*t6019;
  t6048 = t35*t6047;
  t6049 = t6023 + t6048;
  t6050 = 3.2*t6028*t6049;
  t6052 = -1.*t1603*t5998;
  t6054 = t35*t6002;
  t6057 = t6052 + t6054;
  t6072 = -0.24*t5994*t5985;
  t6073 = t6072 + t6036;
  t6059 = -1.*t6016*t6012;
  t6075 = 0.24*t5983*t5994;
  t6076 = t6075 + t6018;
  t6061 = -1.*t6019*t6047;
  t5927 = t5926*t5800;
  t5938 = t5937*t5917;
  t5939 = t5927 + t5928 + t5929 + t5938;
  t5940 = 3.2*t5802*t5939;
  t5954 = -1.*t5794*t5926;
  t5956 = -1.*t5800*t5917;
  t5958 = t5954 + t5955 + t5956 + t5957;
  t5959 = 3.2*t5953*t5958;
  t5960 = t5788 + t5923 + t5940 + t5950 + t5959;
  t6092 = t1603*t5947;
  t6093 = t5795 + t6092;
  t6110 = t1603*t5794;
  t6111 = t6110 + t5952;
  t6102 = -1.*t74*t5884;
  t6103 = 0.24*t1704*t5791;
  t6104 = t6102 + t6103;
  t6089 = t1603*t5937;
  t6090 = t6089 + t5948;
  t6091 = 3.2*t5943*t6090;
  t6094 = 3.2*t5922*t6093;
  t5964 = t5963*t5800;
  t5967 = t5937*t5966;
  t5968 = t5964 + t5928 + t5929 + t5967;
  t6096 = t35*t5937;
  t6097 = t1603*t5800;
  t6098 = t6096 + t6097;
  t6101 = -1.*t5937*t5917;
  t6107 = -1.*t5894*t5947;
  t5970 = -1.*t5794*t5963;
  t5971 = -1.*t5800*t5966;
  t5972 = t5970 + t5955 + t5971 + t5957;
  t6116 = t5794*t5894;
  t6130 = -0.24*t74*t5789;
  t6131 = t6130 + t6103;
  t6120 = t5917*t5947;
  t5969 = 3.2*t5802*t5968;
  t5973 = 3.2*t5953*t5972;
  t5974 = t5923 + t5969 + t5950 + t5973;
  t6126 = 3.2*t5939*t6093;
  t6127 = 3.2*t5968*t6093;
  t6128 = -1.*t5963*t5800;
  t6129 = -1.*t5794*t5966;
  t6132 = -1.*t5794*t6131;
  t6133 = -1.*t5926*t5947;
  t6134 = -1.*t5963*t5947;
  t6135 = t6128 + t5918 + t6101 + t6129 + t6132 + t6133 + t6134 + t6107;
  t6136 = 3.2*t6098*t6135;
  t6138 = 3.2*t6111*t5958;
  t6139 = 3.2*t6111*t5972;
  t6140 = t5794*t5926;
  t6141 = t5794*t5963;
  t6144 = t5963*t5937;
  t6145 = t5800*t5966;
  t6146 = t5800*t6131;
  t6147 = t6140 + t6141 + t6116 + t6144 + t5942 + t6145 + t6146 + t6120;
  t6148 = 3.2*t6111*t6147;
  t6149 = t6091 + t6094 + t6126 + t6127 + t6136 + t6138 + t6139 + t6148;
  t6038 = t6037*t6002;
  t6041 = t5998*t6019;
  t6042 = t6038 + t6039 + t6040 + t6041;
  t6043 = 3.2*t6033*t6042;
  t6058 = -1.*t6016*t6037;
  t6060 = -1.*t6002*t6019;
  t6062 = t6058 + t6059 + t6060 + t6061;
  t6064 = 3.2*t6057*t6062;
  t6066 = t5993 + t6034 + t6043 + t6050 + t6064;
  t6180 = t1603*t6047;
  t6181 = t6032 + t6180;
  t6201 = t1603*t6016;
  t6202 = t6201 + t6054;
  t6190 = -1.*t5983*t6009;
  t6191 = 0.24*t5985*t5996;
  t6195 = t6190 + t6191;
  t6173 = t1603*t5998;
  t6175 = t6173 + t6048;
  t6179 = 3.2*t6028*t6175;
  t6182 = 3.2*t6021*t6181;
  t6074 = t6073*t6002;
  t6077 = t5998*t6076;
  t6078 = t6074 + t6039 + t6040 + t6077;
  t6184 = t35*t5998;
  t6185 = t1603*t6002;
  t6186 = t6184 + t6185;
  t6189 = -1.*t5998*t6019;
  t6198 = -1.*t6012*t6047;
  t6080 = -1.*t6016*t6073;
  t6081 = -1.*t6002*t6076;
  t6082 = t6080 + t6059 + t6081 + t6061;
  t6206 = t6016*t6012;
  t6220 = -0.24*t5983*t5994;
  t6223 = t6220 + t6191;
  t6210 = t6019*t6047;
  t6079 = 3.2*t6033*t6078;
  t6083 = 3.2*t6057*t6082;
  t6084 = t6034 + t6079 + t6050 + t6083;
  t6215 = 3.2*t6042*t6181;
  t6217 = 3.2*t6078*t6181;
  t6218 = -1.*t6073*t6002;
  t6219 = -1.*t6016*t6076;
  t6224 = -1.*t6016*t6223;
  t6225 = -1.*t6037*t6047;
  t6226 = -1.*t6073*t6047;
  t6227 = t6218 + t6020 + t6189 + t6219 + t6224 + t6225 + t6226 + t6198;
  t6228 = 3.2*t6186*t6227;
  t6229 = 3.2*t6202*t6062;
  t6230 = 3.2*t6202*t6082;
  t6231 = t6016*t6037;
  t6232 = t6016*t6073;
  t6233 = t6073*t5998;
  t6234 = t6002*t6076;
  t6235 = t6002*t6223;
  t6236 = t6231 + t6232 + t6206 + t6233 + t6027 + t6234 + t6235 + t6210;
  t6237 = 3.2*t6202*t6236;
  t6238 = t6179 + t6182 + t6215 + t6217 + t6228 + t6229 + t6230 + t6237;
  t6269 = 3.2*t6111*t5922;
  t6274 = 3.2*t5943*t6093;
  t6265 = -1.*t74*t1603;
  t6266 = -1.*t35*t1704;
  t6267 = t6265 + t6266;
  t6268 = 6.8*t6267*t5782;
  t6286 = -1.*t5983*t1603;
  t6287 = -1.*t35*t5985;
  t6288 = t6286 + t6287;
  t6289 = 6.8*t6288*t5992;
  t6294 = 3.2*t6202*t6021;
  t6296 = 3.2*t6028*t6181;
  t6270 = 3.2*t6111*t5939;
  t6275 = 3.2*t6098*t5958;
  t6276 = t6268 + t6269 + t6270 + t6274 + t6275;
  t6278 = 3.2*t6111*t5968;
  t6279 = 3.2*t6098*t5972;
  t6280 = t6269 + t6278 + t6274 + t6279;
  t6295 = 3.2*t6202*t6042;
  t6297 = 3.2*t6186*t6062;
  t6298 = t6289 + t6294 + t6295 + t6296 + t6297;
  t6300 = 3.2*t6202*t6078;
  t6301 = 3.2*t6186*t6082;
  t6303 = t6294 + t6300 + t6296 + t6301;
  t5980 = -1.*t35*t5800;
  t5981 = t5944 + t5980;
  t5977 = -1.*t35*t5937;
  t5978 = t5977 + t5801;
  t6319 = 3.2*t5981*t5922;
  t6321 = -1.*t35*t5794;
  t6322 = -1.*t1603*t5947;
  t6323 = t6321 + t6322;
  t6326 = 3.2*t5943*t6323;
  t6312 = t74*t1603;
  t6316 = t35*t1704;
  t6317 = t6312 + t6316;
  t6318 = 6.8*t6317*t5782;
  t6024 = -1.*t35*t6002;
  t6343 = t5983*t1603;
  t6350 = t35*t5985;
  t6351 = t6343 + t6350;
  t6361 = 6.8*t6351*t5992;
  t6025 = t6023 + t6024;
  t6364 = -1.*t35*t6016;
  t5999 = -1.*t35*t5998;
  t6004 = t5999 + t6003;
  t6372 = 3.2*t6025*t6021;
  t6374 = -1.*t1603*t6047;
  t6375 = t6364 + t6374;
  t6377 = 3.2*t6028*t6375;
  t6320 = 3.2*t5981*t5939;
  t6327 = 3.2*t5978*t5958;
  t6328 = t6318 + t6319 + t6320 + t6326 + t6327;
  t6099 = -1.*t5926*t5800;
  t6100 = -2.*t5794*t5917;
  t6105 = -1.*t5794*t6104;
  t6106 = -2.*t5926*t5947;
  t6108 = t6099 + t6100 + t6101 + t6105 + t6106 + t6107;
  t6113 = 2.*t5794*t5926;
  t6117 = t5926*t5937;
  t6118 = 2.*t5800*t5917;
  t6119 = t5800*t6104;
  t6121 = t6113 + t6116 + t6117 + t6118 + t6119 + t6120;
  t6394 = 3.2*t5922*t5949;
  t6400 = t6096 + t6322;
  t6401 = 3.2*t5943*t6400;
  t6331 = 3.2*t5981*t5968;
  t6332 = 3.2*t5978*t5972;
  t6333 = t6319 + t6331 + t6326 + t6332;
  t6411 = 3.2*t5939*t5949;
  t6412 = 3.2*t5968*t5949;
  t6413 = 3.2*t5953*t6135;
  t6417 = 3.2*t5802*t5958;
  t6418 = 3.2*t5802*t5972;
  t6419 = 3.2*t5802*t6147;
  t6420 = t6394 + t6411 + t6412 + t6401 + t6413 + t6417 + t6418 + t6419;
  t6156 = -2.*t5794*t5966;
  t6157 = -2.*t5963*t5947;
  t6158 = t6128 + t6101 + t6156 + t6132 + t6157 + t6107;
  t6161 = 2.*t5794*t5963;
  t6165 = 2.*t5800*t5966;
  t6166 = t6161 + t6116 + t6144 + t6165 + t6146 + t6120;
  t6373 = 3.2*t6025*t6042;
  t6378 = 3.2*t6004*t6062;
  t6379 = t6361 + t6372 + t6373 + t6377 + t6378;
  t6187 = -1.*t6037*t6002;
  t6188 = -2.*t6016*t6019;
  t6196 = -1.*t6016*t6195;
  t6197 = -2.*t6037*t6047;
  t6199 = t6187 + t6188 + t6189 + t6196 + t6197 + t6198;
  t6205 = 2.*t6016*t6037;
  t6207 = t6037*t5998;
  t6208 = 2.*t6002*t6019;
  t6209 = t6002*t6195;
  t6211 = t6205 + t6206 + t6207 + t6208 + t6209 + t6210;
  t6450 = 3.2*t6021*t6049;
  t6452 = t6184 + t6374;
  t6453 = 3.2*t6028*t6452;
  t6384 = 3.2*t6025*t6078;
  t6385 = 3.2*t6004*t6082;
  t6386 = t6372 + t6384 + t6377 + t6385;
  t6524 = 3.2*t6042*t6049;
  t6525 = 3.2*t6078*t6049;
  t6526 = 3.2*t6057*t6227;
  t7882 = 3.2*t6033*t6062;
  t7919 = 3.2*t6033*t6082;
  t8016 = 3.2*t6033*t6236;
  t8031 = t6450 + t6524 + t6525 + t6453 + t6526 + t7882 + t7919 + t8016;
  t6248 = -2.*t6016*t6076;
  t6249 = -2.*t6073*t6047;
  t6250 = t6218 + t6189 + t6248 + t6224 + t6249 + t6198;
  t6254 = 2.*t6016*t6073;
  t6258 = 2.*t6002*t6076;
  t6259 = t6254 + t6206 + t6233 + t6258 + t6235 + t6210;
  t5961 = -0.5*var2[3]*t5960;
  t5975 = -0.5*var2[4]*t5974;
  t5976 = -2.88*t35;
  t5979 = 3.2*t5978*t5922;
  t5982 = 3.2*t5981*t5943;
  t6022 = 3.2*t6004*t6021;
  t6029 = 3.2*t6025*t6028;
  t6030 = t5976 + t5788 + t5979 + t5982 + t5993 + t6022 + t6029;
  t6071 = -0.5*var2[5]*t6066;
  t6085 = -0.5*var2[6]*t6084;
  t6088 = -0.5*var2[2]*t5960;
  t6153 = -0.5*var2[2]*t5974;
  t6172 = -0.5*var2[2]*t6066;
  t6245 = -0.5*var2[2]*t6084;
  t9748 = 6.4*t5939*t5968;
  t9790 = 6.4*t5922*t6135;
  t9791 = 6.4*t5958*t5972;
  t9809 = 6.4*t5943*t6147;
  t10250 = t9748 + t9790 + t9791 + t9809;
  t10896 = 6.4*t6042*t6078;
  t10897 = 6.4*t6021*t6227;
  t10899 = 6.4*t6062*t6082;
  t10900 = 6.4*t6028*t6236;
  t10953 = t10896 + t10897 + t10899 + t10900;
  t11390 = 6.4*t5939*t5943;
  t11414 = 6.4*t5922*t5958;
  t11415 = t11390 + t11414;
  t11441 = 6.4*t5943*t5968;
  t11448 = 6.4*t5922*t5972;
  t11456 = t11441 + t11448;
  t11476 = 6.4*t6042*t6028;
  t11520 = 6.4*t6021*t6062;
  t11529 = t11476 + t11520;
  t11566 = 6.4*t6028*t6078;
  t11569 = 6.4*t6021*t6082;
  t11582 = t11566 + t11569;
  t11634 = t5884*t5791;
  t11637 = -0.24*t5789*t5791;
  t11652 = t11634 + t11637;
  t11662 = t5884*t5789;
  t11663 = Power(t5791,2);
  t11664 = 0.24*t11663;
  t11674 = t11662 + t11664;
  t11684 = -1.*t5884*t5791;
  t11687 = 0.24*t5789*t5791;
  t11689 = t11684 + t11687;
  t11707 = 3.2*t11689*t5939;
  t11708 = 3.2*t11652*t6135;
  t11724 = Power(t5789,2);
  t11726 = -0.24*t11724;
  t11728 = t11662 + t11726;
  t11730 = 3.2*t11728*t5958;
  t11732 = 3.2*t11674*t6147;
  t11749 = t11707 + t11708 + t11730 + t11732;
  t11897 = 3.2*t11674*t5939;
  t11922 = 3.2*t11652*t5958;
  t11941 = t11897 + t11922;
  t11970 = 3.2*t11728*t5922;
  t11975 = 3.2*t11689*t5943;
  t11980 = 3.2*t11674*t5968;
  t11982 = 3.2*t11652*t5972;
  t12011 = t11970 + t11975 + t11980 + t11982;
  t12231 = t6009*t5996;
  t12234 = -0.24*t5994*t5996;
  t12254 = t12231 + t12234;
  t12283 = t6009*t5994;
  t12300 = Power(t5996,2);
  t12309 = 0.24*t12300;
  t12315 = t12283 + t12309;
  t12357 = -1.*t6009*t5996;
  t12360 = 0.24*t5994*t5996;
  t12361 = t12357 + t12360;
  t12363 = 3.2*t12361*t6042;
  t12369 = 3.2*t12254*t6227;
  t12374 = Power(t5994,2);
  t12375 = -0.24*t12374;
  t12381 = t12283 + t12375;
  t12384 = 3.2*t12381*t6062;
  t12387 = 3.2*t12315*t6236;
  t12398 = t12363 + t12369 + t12384 + t12387;
  t12632 = 3.2*t12315*t6042;
  t12637 = 3.2*t12254*t6062;
  t12651 = t12632 + t12637;
  t12701 = 3.2*t12381*t6021;
  t12737 = 3.2*t12361*t6028;
  t12745 = 3.2*t12315*t6078;
  t12746 = 3.2*t12254*t6082;
  t12748 = t12701 + t12737 + t12745 + t12746;
  p_output1[0]=var2[2]*(t5961 + t5975 + t6071 + t6085 - 0.5*t6030*var2[2]);
  p_output1[1]=var2[2]*(t6088 - 0.5*(t5788 + t6091 + 6.4*t5939*t6093 + t6094 + 3.2*t6098*t6108 + 6.4*t5958*t6111 + 3.2*t6111*t6121)*var2[3] - 0.5*t6149*var2[4]);
  p_output1[2]=var2[2]*(t6153 - 0.5*t6149*var2[3] - 0.5*(t6091 + 6.4*t5968*t6093 + t6094 + 6.4*t5972*t6111 + 3.2*t6098*t6158 + 3.2*t6111*t6166)*var2[4]);
  p_output1[3]=var2[2]*(t6172 - 0.5*(t5993 + t6179 + 6.4*t6042*t6181 + t6182 + 3.2*t6186*t6199 + 6.4*t6062*t6202 + 3.2*t6202*t6211)*var2[5] - 0.5*t6238*var2[6]);
  p_output1[4]=var2[2]*(t6245 - 0.5*t6238*var2[5] - 0.5*(t6179 + 6.4*t6078*t6181 + t6182 + 6.4*t6082*t6202 + 3.2*t6186*t6250 + 3.2*t6202*t6259)*var2[6]);
  p_output1[5]=-1.*(-2.88*t1603 + 3.2*t5802*t5943 + 3.2*t5922*t5953 + 3.2*t6028*t6033 + 3.2*t6021*t6057 + t6268 + t6289)*var2[2] - 0.5*t6276*var2[3] - 0.5*t6280*var2[4] - 0.5*t6298*var2[5] - 0.5*t6303*var2[6];
  p_output1[6]=-0.5*t6276*var2[2];
  p_output1[7]=-0.5*t6280*var2[2];
  p_output1[8]=-0.5*t6298*var2[2];
  p_output1[9]=-0.5*t6303*var2[2];
  p_output1[10]=var2[2]*(-0.5*(2.88*t1603 + 3.2*t5922*(t5980 + t6089) + 3.2*t6021*(t6024 + t6173) + t6318 + 3.2*t5943*(t6097 + t6321) + t6361 + 3.2*t6028*(t6185 + t6364))*var2[2] - 0.5*t6328*var2[3] - 0.5*t6333*var2[4] - 0.5*t6379*var2[5] - 0.5*t6386*var2[6]);
  p_output1[11]=var2[2]*(-0.5*t6328*var2[2] - 0.5*(6.4*t5939*t5949 + 6.4*t5802*t5958 + 3.2*t5953*t6108 + 3.2*t5802*t6121 + t6318 + t6394 + t6401)*var2[3] - 0.5*t6420*var2[4]);
  p_output1[12]=var2[2]*(-0.5*t6333*var2[2] - 0.5*t6420*var2[3] - 0.5*(6.4*t5949*t5968 + 6.4*t5802*t5972 + 3.2*t5953*t6158 + 3.2*t5802*t6166 + t6394 + t6401)*var2[4]);
  p_output1[13]=var2[2]*(-0.5*t6379*var2[2] - 0.5*(6.4*t6042*t6049 + 6.4*t6033*t6062 + 3.2*t6057*t6199 + 3.2*t6033*t6211 + t6361 + t6450 + t6453)*var2[5] - 0.5*t8031*var2[6]);
  p_output1[14]=var2[2]*(-0.5*t6386*var2[2] - 0.5*t8031*var2[5] - 0.5*(6.4*t6049*t6078 + 6.4*t6033*t6082 + 3.2*t6057*t6250 + 3.2*t6033*t6259 + t6450 + t6453)*var2[6]);
  p_output1[15]=t5961 + t5975 + t6071 + t6085 - 1.*t6030*var2[2];
  p_output1[16]=t6088;
  p_output1[17]=t6153;
  p_output1[18]=t6172;
  p_output1[19]=t6245;
  p_output1[20]=var2[2]*(-0.5*(6.4*Power(t5939,2) + 6.4*Power(t5958,2) + 6.4*t5922*t6108 + 6.4*t5943*t6121)*var2[3] - 0.5*t10250*var2[4]);
  p_output1[21]=var2[2]*(-0.5*t10250*var2[3] - 0.5*(6.4*Power(t5968,2) + 6.4*Power(t5972,2) + 6.4*t5922*t6158 + 6.4*t5943*t6166)*var2[4]);
  p_output1[22]=var2[2]*(-0.5*(6.4*Power(t6042,2) + 6.4*Power(t6062,2) + 6.4*t6021*t6199 + 6.4*t6028*t6211)*var2[5] - 0.5*t10953*var2[6]);
  p_output1[23]=var2[2]*(-0.5*t10953*var2[5] - 0.5*(6.4*Power(t6078,2) + 6.4*Power(t6082,2) + 6.4*t6021*t6250 + 6.4*t6028*t6259)*var2[6]);
  p_output1[24]=-0.5*t11415*var2[3] - 0.5*t11456*var2[4] - 0.5*t11529*var2[5] - 0.5*t11582*var2[6];
  p_output1[25]=-0.5*t11415*var2[2];
  p_output1[26]=-0.5*t11456*var2[2];
  p_output1[27]=-0.5*t11529*var2[2];
  p_output1[28]=-0.5*t11582*var2[2];
  p_output1[29]=var2[2]*(-0.5*(3.2*t11652*t6108 + 3.2*t11674*t6121)*var2[3] - 0.5*t11749*var2[4]);
  p_output1[30]=var2[2]*(-0.5*t11749*var2[3] - 0.5*(3.2*t11689*t5922 + 3.2*(0.24*t11724 - 1.*t5789*t5884)*t5943 + 6.4*t11689*t5968 + 6.4*t11728*t5972 + 3.2*t11652*t6158 + 3.2*t11674*t6166)*var2[4]);
  p_output1[31]=-0.5*t11941*var2[3] - 0.5*t12011*var2[4];
  p_output1[32]=-0.5*t11941*var2[2];
  p_output1[33]=-0.5*t12011*var2[2];
  p_output1[34]=var2[2]*(-0.384*t6121*var2[3] - 0.384*t6147*var2[4]);
  p_output1[35]=var2[2]*(-0.384*t6147*var2[3] - 0.384*t6166*var2[4]);
  p_output1[36]=-0.384*t5939*var2[3] - 0.384*t5968*var2[4];
  p_output1[37]=-0.384*t5939*var2[2];
  p_output1[38]=-0.384*t5968*var2[2];
  p_output1[39]=var2[2]*(-0.5*(3.2*t12254*t6199 + 3.2*t12315*t6211)*var2[5] - 0.5*t12398*var2[6]);
  p_output1[40]=var2[2]*(-0.5*t12398*var2[5] - 0.5*(3.2*t12361*t6021 + 3.2*(0.24*t12374 - 1.*t5994*t6009)*t6028 + 6.4*t12361*t6078 + 6.4*t12381*t6082 + 3.2*t12254*t6250 + 3.2*t12315*t6259)*var2[6]);
  p_output1[41]=-0.5*t12651*var2[5] - 0.5*t12748*var2[6];
  p_output1[42]=-0.5*t12651*var2[2];
  p_output1[43]=-0.5*t12748*var2[2];
  p_output1[44]=var2[2]*(-0.384*t6211*var2[5] - 0.384*t6236*var2[6]);
  p_output1[45]=var2[2]*(-0.384*t6236*var2[5] - 0.384*t6259*var2[6]);
  p_output1[46]=-0.384*t6042*var2[5] - 0.384*t6078*var2[6];
  p_output1[47]=-0.384*t6042*var2[2];
  p_output1[48]=-0.384*t6078*var2[2];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 49, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_Ce1_vec3_five_link_walker.hh"

namespace RightStance
{

void J_Ce1_vec3_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
