/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:31:10 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t10433;
  double t10427;
  double t10431;
  double t10434;
  double t10449;
  double t984;
  double t10450;
  double t10451;
  double t10452;
  double t10460;
  double t10461;
  double t10466;
  double t10469;
  double t10473;
  double t10432;
  double t10435;
  double t10447;
  double t10448;
  double t10453;
  double t10454;
  double t10530;
  double t10526;
  double t10527;
  double t10531;
  double t10535;
  double t10539;
  double t10540;
  double t10549;
  double t10550;
  double t10551;
  double t10552;
  double t10553;
  double t10528;
  double t10532;
  double t10533;
  double t10534;
  double t10541;
  double t10542;
  double t10456;
  double t10457;
  double t10458;
  double t10587;
  double t10588;
  double t10589;
  double t10515;
  double t10510;
  double t10511;
  double t10512;
  double t10514;
  double t10517;
  double t10545;
  double t10546;
  double t10547;
  double t10612;
  double t10613;
  double t10614;
  double t10561;
  double t10557;
  double t10558;
  double t10559;
  double t10560;
  double t10562;
  double t10591;
  double t10592;
  double t10593;
  double t10595;
  double t10596;
  double t10608;
  double t10609;
  double t10610;
  double t10616;
  double t10617;
  double t10618;
  double t10620;
  double t10621;
  double t10659;
  double t10670;
  double t10671;
  double t10738;
  double t10742;
  double t10744;
  double t10748;
  double t10749;
  double t10750;
  double t10775;
  double t10776;
  double t10777;
  double t10779;
  double t10780;
  double t10781;
  double t10459;
  double t10474;
  double t10482;
  double t10509;
  double t10519;
  double t10520;
  double t10521;
  double t10522;
  double t10839;
  double t10840;
  double t10841;
  double t10842;
  double t10843;
  double t10590;
  double t10594;
  double t10675;
  double t10676;
  double t10677;
  double t10678;
  double t10679;
  double t10680;
  double t10681;
  double t10682;
  double t10683;
  double t10684;
  double t10723;
  double t10724;
  double t10725;
  double t10727;
  double t10729;
  double t10736;
  double t10747;
  double t10751;
  double t10752;
  double t10754;
  double t10755;
  double t10756;
  double t11039;
  double t11077;
  double t11101;
  double t10844;
  double t10845;
  double t10846;
  double t10850;
  double t10851;
  double t10854;
  double t10855;
  double t10856;
  double t10857;
  double t10924;
  double t10927;
  double t11033;
  double t11103;
  double t11115;
  double t11196;
  double t11581;
  double t11584;
  double t11213;
  double t11598;
  double t11605;
  double t11228;
  double t10548;
  double t10554;
  double t10555;
  double t10556;
  double t10564;
  double t10565;
  double t10566;
  double t10567;
  double t11744;
  double t11751;
  double t11768;
  double t11775;
  double t11777;
  double t10615;
  double t10619;
  double t10695;
  double t10696;
  double t10700;
  double t10701;
  double t10702;
  double t10703;
  double t10704;
  double t10705;
  double t10706;
  double t10707;
  double t10769;
  double t10770;
  double t10771;
  double t10772;
  double t10773;
  double t10774;
  double t10778;
  double t10782;
  double t10783;
  double t10832;
  double t10833;
  double t10834;
  double t11961;
  double t11962;
  double t11966;
  double t11796;
  double t11804;
  double t11807;
  double t11834;
  double t11851;
  double t11855;
  double t11899;
  double t11918;
  double t11919;
  double t11933;
  double t11942;
  double t11960;
  double t11990;
  double t12000;
  double t12064;
  double t12131;
  double t12133;
  double t12066;
  double t12137;
  double t12138;
  double t12081;
  double t10685;
  double t10686;
  double t10692;
  double t10693;
  double t10708;
  double t10709;
  double t10717;
  double t10718;
  double t10687;
  double t10688;
  double t10689;
  double t10690;
  double t10691;
  double t10694;
  double t10710;
  double t10711;
  double t10713;
  double t10715;
  double t10716;
  double t10719;
  double t10720;
  double t12479;
  double t12498;
  double t11028;
  double t12519;
  double t11102;
  double t11138;
  double t11164;
  double t11210;
  double t11215;
  double t11299;
  double t12546;
  double t11440;
  double t11445;
  double t11451;
  double t12547;
  double t11402;
  double t11413;
  double t11425;
  double t12548;
  double t12565;
  double t12585;
  double t11562;
  double t12607;
  double t11595;
  double t11606;
  double t11611;
  double t12610;
  double t11629;
  double t11648;
  double t11667;
  double t12491;
  double t12501;
  double t11952;
  double t12539;
  double t11980;
  double t12003;
  double t12027;
  double t12065;
  double t12078;
  double t12084;
  double t12654;
  double t12096;
  double t12097;
  double t12099;
  double t12656;
  double t12090;
  double t12092;
  double t12093;
  double t12660;
  double t12663;
  double t12664;
  double t12129;
  double t12668;
  double t12135;
  double t12140;
  double t12141;
  double t12671;
  double t12147;
  double t12148;
  double t12149;
  double t12343;
  double t12344;
  double t12347;
  double t12352;
  double t12372;
  double t12392;
  double t12395;
  double t12396;
  double t12399;
  double t12238;
  double t12261;
  double t12262;
  double t12285;
  double t10722;
  double t10753;
  double t10757;
  double t10831;
  double t10835;
  double t10836;
  double t10518;
  double t10523;
  double t10524;
  double t10563;
  double t10568;
  double t10569;
  double t12516;
  double t12531;
  double t12538;
  double t12540;
  double t12541;
  double t12542;
  double t12608;
  double t12611;
  double t12620;
  double t11189;
  double t11386;
  double t11389;
  double t12643;
  double t12645;
  double t12647;
  double t11615;
  double t11668;
  double t11672;
  double t12669;
  double t12672;
  double t12675;
  double t12059;
  double t12085;
  double t12086;
  double t12692;
  double t12693;
  double t12694;
  double t12142;
  double t12151;
  double t12169;
  double t12401;
  double t12402;
  double t12447;
  double t12452;
  double t12453;
  double t12454;
  double t12456;
  double t12459;
  double t12481;
  double t12487;
  double t12488;
  double t12557;
  double t10847;
  double t12712;
  double t12716;
  double t12718;
  double t12631;
  double t12633;
  double t12634;
  double t11426;
  double t11452;
  double t11474;
  double t12779;
  double t12780;
  double t12781;
  double t12782;
  double t12783;
  double t12461;
  double t12463;
  double t12464;
  double t12465;
  double t12907;
  double t12915;
  double t12918;
  double t12921;
  double t13027;
  double t13029;
  double t12466;
  double t12700;
  double t12929;
  double t12931;
  double t13014;
  double t13015;
  double t12493;
  double t12494;
  double t12495;
  double t12661;
  double t11816;
  double t12820;
  double t12822;
  double t12823;
  double t12678;
  double t12679;
  double t12680;
  double t12095;
  double t12100;
  double t12101;
  double t12835;
  double t12836;
  double t12837;
  double t12839;
  double t12840;
  double t12467;
  double t12469;
  double t12473;
  double t12474;
  double t12933;
  double t12934;
  double t12935;
  double t12936;
  double t13097;
  double t13098;
  double t12475;
  double t12702;
  double t12938;
  double t12939;
  double t13086;
  double t13087;
  t10433 = Cos(var1[3]);
  t10427 = Cos(var1[4]);
  t10431 = Sin(var1[3]);
  t10434 = Sin(var1[4]);
  t10449 = Sin(var1[2]);
  t984 = Cos(var1[2]);
  t10450 = t10433*t10427;
  t10451 = -1.*t10431*t10434;
  t10452 = t10450 + t10451;
  t10460 = -1.*t10427;
  t10461 = 1. + t10460;
  t10466 = 0.4*t10461;
  t10469 = 0.64*t10427;
  t10473 = t10466 + t10469;
  t10432 = -1.*t10427*t10431;
  t10435 = -1.*t10433*t10434;
  t10447 = t10432 + t10435;
  t10448 = t984*t10447;
  t10453 = -1.*t10449*t10452;
  t10454 = t10448 + t10453;
  t10530 = Cos(var1[5]);
  t10526 = Cos(var1[6]);
  t10527 = Sin(var1[5]);
  t10531 = Sin(var1[6]);
  t10535 = t10530*t10526;
  t10539 = -1.*t10527*t10531;
  t10540 = t10535 + t10539;
  t10549 = -1.*t10526;
  t10550 = 1. + t10549;
  t10551 = 0.4*t10550;
  t10552 = 0.64*t10526;
  t10553 = t10551 + t10552;
  t10528 = -1.*t10526*t10527;
  t10532 = -1.*t10530*t10531;
  t10533 = t10528 + t10532;
  t10534 = t984*t10533;
  t10541 = -1.*t10449*t10540;
  t10542 = t10534 + t10541;
  t10456 = -1.*t10433*t10449;
  t10457 = -1.*t984*t10431;
  t10458 = t10456 + t10457;
  t10587 = t984*t10433;
  t10588 = -1.*t10449*t10431;
  t10589 = t10587 + t10588;
  t10515 = t984*t10452;
  t10510 = t10427*t10431;
  t10511 = t10433*t10434;
  t10512 = t10510 + t10511;
  t10514 = -1.*t10449*t10512;
  t10517 = t10514 + t10515;
  t10545 = -1.*t10530*t10449;
  t10546 = -1.*t984*t10527;
  t10547 = t10545 + t10546;
  t10612 = t984*t10530;
  t10613 = -1.*t10449*t10527;
  t10614 = t10612 + t10613;
  t10561 = t984*t10540;
  t10557 = t10526*t10527;
  t10558 = t10530*t10531;
  t10559 = t10557 + t10558;
  t10560 = -1.*t10449*t10559;
  t10562 = t10560 + t10561;
  t10591 = t10433*t10449;
  t10592 = t984*t10431;
  t10593 = t10591 + t10592;
  t10595 = t10449*t10447;
  t10596 = t10595 + t10515;
  t10608 = t984*t10512;
  t10609 = t10449*t10452;
  t10610 = t10608 + t10609;
  t10616 = t10530*t10449;
  t10617 = t984*t10527;
  t10618 = t10616 + t10617;
  t10620 = t10449*t10533;
  t10621 = t10620 + t10561;
  t10659 = t984*t10559;
  t10670 = t10449*t10540;
  t10671 = t10659 + t10670;
  t10738 = t10473*t10431;
  t10742 = 0.24*t10433*t10434;
  t10744 = t10738 + t10742;
  t10748 = t10433*t10473;
  t10749 = -0.24*t10431*t10434;
  t10750 = t10748 + t10749;
  t10775 = t10553*t10527;
  t10776 = 0.24*t10530*t10531;
  t10777 = t10775 + t10776;
  t10779 = t10530*t10553;
  t10780 = -0.24*t10527*t10531;
  t10781 = t10779 + t10780;
  t10459 = -0.748*t10458;
  t10474 = t10473*t10434;
  t10482 = -0.24*t10427*t10434;
  t10509 = t10474 + t10482;
  t10519 = t10473*t10427;
  t10520 = Power(t10434,2);
  t10521 = 0.24*t10520;
  t10522 = t10519 + t10521;
  t10839 = -1.*t10433*t10427;
  t10840 = t10431*t10434;
  t10841 = t10839 + t10840;
  t10842 = t10449*t10841;
  t10843 = t10448 + t10842;
  t10590 = -13.6*t10458*t10589;
  t10594 = -13.6*t10593*t10589;
  t10675 = Power(t10458,2);
  t10676 = -6.8*t10675;
  t10677 = -6.8*t10458*t10593;
  t10678 = Power(t10589,2);
  t10679 = -6.8*t10678;
  t10680 = -1.*t984*t10433;
  t10681 = t10449*t10431;
  t10682 = t10680 + t10681;
  t10683 = -6.8*t10589*t10682;
  t10684 = -1.*t10449*t10447;
  t10723 = Power(t10433,2);
  t10724 = 0.11*t10723;
  t10725 = Power(t10431,2);
  t10727 = 0.11*t10725;
  t10729 = t10724 + t10727;
  t10736 = -6.8*t10458*t10729;
  t10747 = -1.*t10744*t10452;
  t10751 = -1.*t10447*t10750;
  t10752 = t10747 + t10751;
  t10754 = t10744*t10512;
  t10755 = t10452*t10750;
  t10756 = t10754 + t10755;
  t11039 = -1.*t10473*t10431;
  t11077 = -0.24*t10433*t10434;
  t11101 = t11039 + t11077;
  t10844 = -0.768*var2[4]*t10843;
  t10845 = -3.2*t10509*t10596;
  t10846 = -3.2*t10522*t10843;
  t10850 = -6.4*t10596*t10610;
  t10851 = -6.4*t10596*t10843;
  t10854 = -3.2*t10596*t10517;
  t10855 = -3.2*t10454*t10610;
  t10856 = t984*t10841;
  t10857 = t10684 + t10856;
  t10924 = -3.2*t10596*t10857;
  t10927 = -3.2*t10454*t10843;
  t11033 = -3.2*t10596*t10752;
  t11103 = t10744*t10452;
  t11115 = t10447*t10750;
  t11196 = -3.2*t10756*t10843;
  t11581 = -0.24*t10427*t10431;
  t11584 = t11581 + t11077;
  t11213 = -1.*t10447*t10744;
  t11598 = 0.24*t10433*t10427;
  t11605 = t11598 + t10749;
  t11228 = -1.*t10750*t10841;
  t10548 = -0.748*t10547;
  t10554 = t10553*t10531;
  t10555 = -0.24*t10526*t10531;
  t10556 = t10554 + t10555;
  t10564 = t10553*t10526;
  t10565 = Power(t10531,2);
  t10566 = 0.24*t10565;
  t10567 = t10564 + t10566;
  t11744 = -1.*t10530*t10526;
  t11751 = t10527*t10531;
  t11768 = t11744 + t11751;
  t11775 = t10449*t11768;
  t11777 = t10534 + t11775;
  t10615 = -13.6*t10547*t10614;
  t10619 = -13.6*t10618*t10614;
  t10695 = Power(t10547,2);
  t10696 = -6.8*t10695;
  t10700 = -6.8*t10547*t10618;
  t10701 = Power(t10614,2);
  t10702 = -6.8*t10701;
  t10703 = -1.*t984*t10530;
  t10704 = t10449*t10527;
  t10705 = t10703 + t10704;
  t10706 = -6.8*t10614*t10705;
  t10707 = -1.*t10449*t10533;
  t10769 = Power(t10530,2);
  t10770 = 0.11*t10769;
  t10771 = Power(t10527,2);
  t10772 = 0.11*t10771;
  t10773 = t10770 + t10772;
  t10774 = -6.8*t10547*t10773;
  t10778 = -1.*t10777*t10540;
  t10782 = -1.*t10533*t10781;
  t10783 = t10778 + t10782;
  t10832 = t10777*t10559;
  t10833 = t10540*t10781;
  t10834 = t10832 + t10833;
  t11961 = -1.*t10553*t10527;
  t11962 = -0.24*t10530*t10531;
  t11966 = t11961 + t11962;
  t11796 = -0.768*var2[6]*t11777;
  t11804 = -3.2*t10556*t10621;
  t11807 = -3.2*t10567*t11777;
  t11834 = -6.4*t10621*t10671;
  t11851 = -6.4*t10621*t11777;
  t11855 = -3.2*t10621*t10562;
  t11899 = -3.2*t10542*t10671;
  t11918 = t984*t11768;
  t11919 = t10707 + t11918;
  t11933 = -3.2*t10621*t11919;
  t11942 = -3.2*t10542*t11777;
  t11960 = -3.2*t10621*t10783;
  t11990 = t10777*t10540;
  t12000 = t10533*t10781;
  t12064 = -3.2*t10834*t11777;
  t12131 = -0.24*t10526*t10527;
  t12133 = t12131 + t11962;
  t12066 = -1.*t10533*t10777;
  t12137 = 0.24*t10530*t10526;
  t12138 = t12137 + t10780;
  t12081 = -1.*t10781*t11768;
  t10685 = -1.*t984*t10452;
  t10686 = t10684 + t10685;
  t10692 = -1.*t984*t10512;
  t10693 = t10692 + t10453;
  t10708 = -1.*t984*t10540;
  t10709 = t10707 + t10708;
  t10717 = -1.*t984*t10559;
  t10718 = t10717 + t10541;
  t10687 = -3.2*t10686*t10596;
  t10688 = Power(t10517,2);
  t10689 = -3.2*t10688;
  t10690 = Power(t10454,2);
  t10691 = -3.2*t10690;
  t10694 = -3.2*t10693*t10610;
  t10710 = -3.2*t10709*t10621;
  t10711 = Power(t10562,2);
  t10713 = -3.2*t10711;
  t10715 = Power(t10542,2);
  t10716 = -3.2*t10715;
  t10719 = -3.2*t10718*t10671;
  t10720 = t10676 + t10677 + t10679 + t10683 + t10687 + t10689 + t10691 + t10694 + t10696 + t10700 + t10702 + t10706 + t10710 + t10713 + t10716 + t10719;
  t12479 = -0.748*t10682;
  t12498 = -13.6*t10458*t10682;
  t11028 = t10676 + t10677 + t10679 + t10683 + t10854 + t10855 + t10924 + t10927;
  t12519 = -6.8*t10682*t10729;
  t11102 = t11101*t10452;
  t11138 = t10512*t10750;
  t11164 = t11102 + t11103 + t11115 + t11138;
  t11210 = -1.*t10447*t11101;
  t11215 = -1.*t10452*t10750;
  t11299 = t11210 + t11213 + t11215 + t11228;
  t12546 = -0.768*var2[4]*t10857;
  t11440 = Power(t10427,2);
  t11445 = -0.24*t11440;
  t11451 = t10519 + t11445;
  t12547 = -3.2*t10509*t10454;
  t11402 = -1.*t10473*t10434;
  t11413 = 0.24*t10427*t10434;
  t11425 = t11402 + t11413;
  t12548 = -3.2*t10522*t10857;
  t12565 = -6.4*t10517*t10454;
  t12585 = -6.4*t10454*t10857;
  t11562 = t10854 + t10855 + t10924 + t10927;
  t12607 = -3.2*t10454*t10752;
  t11595 = t11584*t10452;
  t11606 = t10512*t11605;
  t11611 = t11595 + t11103 + t11115 + t11606;
  t12610 = -3.2*t10756*t10857;
  t11629 = -1.*t10447*t11584;
  t11648 = -1.*t10452*t11605;
  t11667 = t11629 + t11213 + t11648 + t11228;
  t12491 = -0.748*t10705;
  t12501 = -13.6*t10547*t10705;
  t11952 = t10696 + t10700 + t10702 + t10706 + t11855 + t11899 + t11933 + t11942;
  t12539 = -6.8*t10705*t10773;
  t11980 = t11966*t10540;
  t12003 = t10559*t10781;
  t12027 = t11980 + t11990 + t12000 + t12003;
  t12065 = -1.*t10533*t11966;
  t12078 = -1.*t10540*t10781;
  t12084 = t12065 + t12066 + t12078 + t12081;
  t12654 = -0.768*var2[6]*t11919;
  t12096 = Power(t10526,2);
  t12097 = -0.24*t12096;
  t12099 = t10564 + t12097;
  t12656 = -3.2*t10556*t10542;
  t12090 = -1.*t10553*t10531;
  t12092 = 0.24*t10526*t10531;
  t12093 = t12090 + t12092;
  t12660 = -3.2*t10567*t11919;
  t12663 = -6.4*t10562*t10542;
  t12664 = -6.4*t10542*t11919;
  t12129 = t11855 + t11899 + t11933 + t11942;
  t12668 = -3.2*t10542*t10783;
  t12135 = t12133*t10540;
  t12140 = t10559*t12138;
  t12141 = t12135 + t11990 + t12000 + t12140;
  t12671 = -3.2*t10834*t11919;
  t12147 = -1.*t10533*t12133;
  t12148 = -1.*t10540*t12138;
  t12149 = t12147 + t12066 + t12148 + t12081;
  t12343 = -6.8*t10458*t10589;
  t12344 = -6.8*t10593*t10589;
  t12347 = -3.2*t10596*t10454;
  t12352 = -3.2*t10517*t10610;
  t12372 = -6.8*t10547*t10614;
  t12392 = -6.8*t10618*t10614;
  t12395 = -3.2*t10621*t10542;
  t12396 = -3.2*t10562*t10671;
  t12399 = t12343 + t12344 + t12347 + t12352 + t12372 + t12392 + t12395 + t12396;
  t12238 = Power(t984,2);
  t12261 = -12.*t12238;
  t12262 = Power(t10449,2);
  t12285 = -12.*t12262;
  t10722 = 2.88*t10449;
  t10753 = -3.2*t10517*t10752;
  t10757 = -3.2*t10454*t10756;
  t10831 = -3.2*t10562*t10783;
  t10835 = -3.2*t10542*t10834;
  t10836 = t10722 + t10736 + t10753 + t10757 + t10774 + t10831 + t10835;
  t10518 = -3.2*t10509*t10517;
  t10523 = -3.2*t10522*t10454;
  t10524 = t10459 + t10518 + t10523;
  t10563 = -3.2*t10556*t10562;
  t10568 = -3.2*t10567*t10542;
  t10569 = t10548 + t10563 + t10568;
  t12516 = 2.88*t984;
  t12531 = -3.2*t10693*t10752;
  t12538 = -3.2*t10686*t10756;
  t12540 = -3.2*t10718*t10783;
  t12541 = -3.2*t10709*t10834;
  t12542 = t12516 + t12519 + t12531 + t12538 + t12539 + t12540 + t12541;
  t12608 = -3.2*t10454*t11164;
  t12611 = -3.2*t10517*t11299;
  t12620 = t12519 + t12607 + t12608 + t12610 + t12611;
  t11189 = -3.2*t10596*t11164;
  t11386 = -3.2*t10610*t11299;
  t11389 = t10736 + t11033 + t11189 + t11196 + t11386;
  t12643 = -3.2*t10454*t11611;
  t12645 = -3.2*t10517*t11667;
  t12647 = t12607 + t12643 + t12610 + t12645;
  t11615 = -3.2*t10596*t11611;
  t11668 = -3.2*t10610*t11667;
  t11672 = t11033 + t11615 + t11196 + t11668;
  t12669 = -3.2*t10542*t12027;
  t12672 = -3.2*t10562*t12084;
  t12675 = t12539 + t12668 + t12669 + t12671 + t12672;
  t12059 = -3.2*t10621*t12027;
  t12085 = -3.2*t10671*t12084;
  t12086 = t10774 + t11960 + t12059 + t12064 + t12085;
  t12692 = -3.2*t10542*t12141;
  t12693 = -3.2*t10562*t12149;
  t12694 = t12668 + t12692 + t12671 + t12693;
  t12142 = -3.2*t10621*t12141;
  t12151 = -3.2*t10671*t12149;
  t12169 = t11960 + t12142 + t12064 + t12151;
  t12401 = -2.88*t984;
  t12402 = -6.8*t10589*t10729;
  t12447 = -3.2*t10610*t10752;
  t12452 = -3.2*t10596*t10756;
  t12453 = -6.8*t10614*t10773;
  t12454 = -3.2*t10671*t10783;
  t12456 = -3.2*t10621*t10834;
  t12459 = t12401 + t12402 + t12447 + t12452 + t12453 + t12454 + t12456;
  t12481 = -3.2*t10522*t10686;
  t12487 = -3.2*t10509*t10693;
  t12488 = t12479 + t12481 + t12487;
  t12557 = t12479 + t12547 + t12548;
  t10847 = t10459 + t10845 + t10846;
  t12712 = -3.2*t10522*t11164;
  t12716 = -3.2*t10509*t11299;
  t12718 = t12712 + t12716;
  t12631 = -3.2*t11451*t10517;
  t12633 = -3.2*t11425*t10454;
  t12634 = t12631 + t12547 + t12633 + t12548;
  t11426 = -3.2*t11425*t10596;
  t11452 = -3.2*t11451*t10610;
  t11474 = t10845 + t11426 + t11452 + t10846;
  t12779 = -3.2*t11451*t10752;
  t12780 = -3.2*t11425*t10756;
  t12781 = -3.2*t10522*t11611;
  t12782 = -3.2*t10509*t11667;
  t12783 = t12779 + t12780 + t12781 + t12782;
  t12461 = -0.748*t10589;
  t12463 = -3.2*t10522*t10596;
  t12464 = -3.2*t10509*t10610;
  t12465 = t12461 + t12463 + t12464;
  t12907 = -0.748*t10729;
  t12915 = -3.2*t10509*t10752;
  t12918 = -3.2*t10522*t10756;
  t12921 = -0.67 + t12907 + t12915 + t12918;
  t13027 = -0.768*var2[1]*t10857;
  t13029 = -0.768*var2[0]*t10843;
  t12466 = -0.768*t10596;
  t12700 = -0.768*t10454;
  t12929 = -0.768*t10756;
  t12931 = -0.2 + t12929;
  t13014 = -0.768*t10522;
  t13015 = -0.2 + t13014;
  t12493 = -3.2*t10567*t10709;
  t12494 = -3.2*t10556*t10718;
  t12495 = t12491 + t12493 + t12494;
  t12661 = t12491 + t12656 + t12660;
  t11816 = t10548 + t11804 + t11807;
  t12820 = -3.2*t10567*t12027;
  t12822 = -3.2*t10556*t12084;
  t12823 = t12820 + t12822;
  t12678 = -3.2*t12099*t10562;
  t12679 = -3.2*t12093*t10542;
  t12680 = t12678 + t12656 + t12679 + t12660;
  t12095 = -3.2*t12093*t10621;
  t12100 = -3.2*t12099*t10671;
  t12101 = t11804 + t12095 + t12100 + t11807;
  t12835 = -3.2*t12099*t10783;
  t12836 = -3.2*t12093*t10834;
  t12837 = -3.2*t10567*t12141;
  t12839 = -3.2*t10556*t12149;
  t12840 = t12835 + t12836 + t12837 + t12839;
  t12467 = -0.748*t10614;
  t12469 = -3.2*t10567*t10621;
  t12473 = -3.2*t10556*t10671;
  t12474 = t12467 + t12469 + t12473;
  t12933 = -0.748*t10773;
  t12934 = -3.2*t10556*t10783;
  t12935 = -3.2*t10567*t10834;
  t12936 = -0.67 + t12933 + t12934 + t12935;
  t13097 = -0.768*var2[1]*t11919;
  t13098 = -0.768*var2[0]*t11777;
  t12475 = -0.768*t10621;
  t12702 = -0.768*t10542;
  t12938 = -0.768*t10834;
  t12939 = -0.2 + t12938;
  t13086 = -0.768*t10567;
  t13087 = -0.2 + t13086;
  p_output1[0]=(t10590 + t10594 - 6.4*t10454*t10596 - 6.4*t10517*t10610 + t10615 + t10619 - 6.4*t10542*t10621 - 6.4*t10562*t10671)*var2[0] + t10720*var2[1] + t10836*var2[2] + t10524*var2[3] - 0.768*t10454*var2[4] + t10569*var2[5] - 0.768*t10542*var2[6];
  p_output1[1]=t10844 + (t10590 + t10594 + t10850 + t10851)*var2[0] + t11028*var2[1] + t11389*var2[2] + t10847*var2[3];
  p_output1[2]=t10844 + (t10850 + t10851)*var2[0] + t11562*var2[1] + t11672*var2[2] + t11474*var2[3];
  p_output1[3]=t11796 + (t10615 + t10619 + t11834 + t11851)*var2[0] + t11952*var2[1] + t12086*var2[2] + t11816*var2[5];
  p_output1[4]=t11796 + (t11834 + t11851)*var2[0] + t12129*var2[1] + t12169*var2[2] + t12101*var2[5];
  p_output1[5]=-6.8*Power(t10593,2) - 3.2*Power(t10596,2) - 3.2*Power(t10610,2) - 6.8*Power(t10618,2) - 3.2*Power(t10621,2) - 3.2*Power(t10671,2) + t10679 + t10702 + t12261 + t12285;
  p_output1[6]=t12399;
  p_output1[7]=t12459;
  p_output1[8]=t12465;
  p_output1[9]=t12466;
  p_output1[10]=t12474;
  p_output1[11]=t12475;
  p_output1[12]=t10720*var2[0] + (t10590 + t10615 - 6.4*t10454*t10686 - 6.4*t10517*t10693 - 6.4*t10542*t10709 - 6.4*t10562*t10718 + t12498 + t12501)*var2[1] + t12542*var2[2] + t12488*var2[3] - 0.768*t10686*var2[4] + t12495*var2[5] - 0.768*t10709*var2[6];
  p_output1[13]=t12546 + t11028*var2[0] + (t10590 + t12498 + t12565 + t12585)*var2[1] + t12620*var2[2] + t12557*var2[3];
  p_output1[14]=t12546 + t11562*var2[0] + (t12565 + t12585)*var2[1] + t12647*var2[2] + t12634*var2[3];
  p_output1[15]=t12654 + t11952*var2[0] + (t10615 + t12501 + t12663 + t12664)*var2[1] + t12675*var2[2] + t12661*var2[5];
  p_output1[16]=t12654 + t12129*var2[0] + (t12663 + t12664)*var2[1] + t12694*var2[2] + t12680*var2[5];
  p_output1[17]=t12399;
  p_output1[18]=t10676 + t10679 + t10689 + t10691 + t10696 + t10702 + t10713 + t10716 + t12261 + t12285;
  p_output1[19]=t10836;
  p_output1[20]=t10524;
  p_output1[21]=t12700;
  p_output1[22]=t10569;
  p_output1[23]=t12702;
  p_output1[24]=t10836*var2[0] + t12542*var2[1];
  p_output1[25]=t11389*var2[0] + t12620*var2[1] + (-6.4*t10756*t11164 - 6.4*t10752*t11299)*var2[2] + t12718*var2[3] - 0.768*t11164*var2[4];
  p_output1[26]=t11672*var2[0] + t12647*var2[1] + (-6.4*t10756*t11611 - 6.4*t10752*t11667)*var2[2] + t12783*var2[3] - 0.768*t11611*var2[4];
  p_output1[27]=t12086*var2[0] + t12675*var2[1] + (-6.4*t10834*t12027 - 6.4*t10783*t12084)*var2[2] + t12823*var2[5] - 0.768*t12027*var2[6];
  p_output1[28]=t12169*var2[0] + t12694*var2[1] + (-6.4*t10834*t12141 - 6.4*t10783*t12149)*var2[2] + t12840*var2[5] - 0.768*t12141*var2[6];
  p_output1[29]=t12459;
  p_output1[30]=t10836;
  p_output1[31]=-3.3612 - 6.8*Power(t10729,2) - 3.2*Power(t10752,2) - 3.2*Power(t10756,2) - 6.8*Power(t10773,2) - 3.2*Power(t10783,2) - 3.2*Power(t10834,2);
  p_output1[32]=t12921;
  p_output1[33]=t12931;
  p_output1[34]=t12936;
  p_output1[35]=t12939;
  p_output1[36]=t10524*var2[0] + t12488*var2[1];
  p_output1[37]=t10847*var2[0] + t12557*var2[1] + t12718*var2[2];
  p_output1[38]=t11474*var2[0] + t12634*var2[1] + t12783*var2[2] + (-6.4*t10522*t11425 - 6.4*t10509*t11451)*var2[3] - 0.768*t11425*var2[4];
  p_output1[39]=t12465;
  p_output1[40]=t10524;
  p_output1[41]=t12921;
  p_output1[42]=-1.58228 - 3.2*Power(t10509,2) - 3.2*Power(t10522,2);
  p_output1[43]=t13015;
  p_output1[44]=-0.768*t10454*var2[0] - 0.768*t10686*var2[1];
  p_output1[45]=t13027 + t13029 - 0.768*t11164*var2[2];
  p_output1[46]=t13027 + t13029 - 0.768*t11611*var2[2] - 0.768*t11425*var2[3];
  p_output1[47]=t12466;
  p_output1[48]=t12700;
  p_output1[49]=t12931;
  p_output1[50]=t13015;
  p_output1[51]=-1.2143199999999998;
  p_output1[52]=t10569*var2[0] + t12495*var2[1];
  p_output1[53]=t11816*var2[0] + t12661*var2[1] + t12823*var2[2];
  p_output1[54]=t12101*var2[0] + t12680*var2[1] + t12840*var2[2] + (-6.4*t10567*t12093 - 6.4*t10556*t12099)*var2[5] - 0.768*t12093*var2[6];
  p_output1[55]=t12474;
  p_output1[56]=t10569;
  p_output1[57]=t12936;
  p_output1[58]=-1.58228 - 3.2*Power(t10556,2) - 3.2*Power(t10567,2);
  p_output1[59]=t13087;
  p_output1[60]=-0.768*t10542*var2[0] - 0.768*t10709*var2[1];
  p_output1[61]=t13097 + t13098 - 0.768*t12027*var2[2];
  p_output1[62]=t13097 + t13098 - 0.768*t12141*var2[2] - 0.768*t12093*var2[5];
  p_output1[63]=t12475;
  p_output1[64]=t12702;
  p_output1[65]=t12939;
  p_output1[66]=t13087;
  p_output1[67]=-1.2143199999999998;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 68, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "J_MmatDx_five_link_walker.hh"

namespace RightStance
{

void J_MmatDx_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
