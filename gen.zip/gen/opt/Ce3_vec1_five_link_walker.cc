/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:30:52 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t8463;
  double t211;
  double t3939;
  double t9628;
  double t11331;
  double t210;
  double t11430;
  double t11437;
  double t11540;
  double t11675;
  double t11742;
  double t11743;
  double t11746;
  double t11747;
  double t8462;
  double t9797;
  double t9798;
  double t11088;
  double t11570;
  double t11597;
  double t11860;
  double t11856;
  double t11857;
  double t11861;
  double t11913;
  double t11914;
  double t11915;
  double t11927;
  double t11929;
  double t11930;
  double t11932;
  double t11935;
  double t11859;
  double t11862;
  double t11863;
  double t11911;
  double t11916;
  double t11917;
  double t11599;
  double t11600;
  double t11603;
  double t11963;
  double t11964;
  double t11965;
  double t11772;
  double t11760;
  double t11761;
  double t11762;
  double t11770;
  double t11773;
  double t11920;
  double t11921;
  double t11925;
  double t12004;
  double t12005;
  double t12007;
  double t11950;
  double t11939;
  double t11940;
  double t11948;
  double t11949;
  double t11951;
  double t11971;
  double t11973;
  double t11974;
  double t11977;
  double t11978;
  double t11981;
  double t11999;
  double t12001;
  double t12009;
  double t12010;
  double t12017;
  double t12021;
  double t12022;
  double t12042;
  double t12061;
  double t12062;
  double t12167;
  double t12171;
  double t12172;
  double t12174;
  double t12175;
  double t12177;
  double t12241;
  double t12242;
  double t12243;
  double t12251;
  double t12253;
  double t12255;
  double t11621;
  double t11756;
  double t11757;
  double t11758;
  double t11806;
  double t11810;
  double t11811;
  double t11813;
  double t12297;
  double t12301;
  double t12303;
  double t12306;
  double t12307;
  double t11968;
  double t11976;
  double t12068;
  double t12072;
  double t12073;
  double t12074;
  double t12075;
  double t12076;
  double t12079;
  double t12080;
  double t12082;
  double t12083;
  double t12152;
  double t12153;
  double t12154;
  double t12160;
  double t12161;
  double t12163;
  double t12173;
  double t12179;
  double t12201;
  double t12206;
  double t12207;
  double t12210;
  double t12391;
  double t12393;
  double t12394;
  double t12308;
  double t12311;
  double t12312;
  double t12341;
  double t12342;
  double t12345;
  double t12346;
  double t12348;
  double t12349;
  double t12350;
  double t12351;
  double t12390;
  double t12400;
  double t12403;
  double t12455;
  double t12508;
  double t12509;
  double t12458;
  double t12512;
  double t12513;
  double t12462;
  double t11926;
  double t11936;
  double t11937;
  double t11938;
  double t11954;
  double t11956;
  double t11958;
  double t11959;
  double t12549;
  double t12555;
  double t12559;
  double t12562;
  double t12564;
  double t12008;
  double t12020;
  double t12103;
  double t12105;
  double t12106;
  double t12107;
  double t12109;
  double t12111;
  double t12117;
  double t12123;
  double t12124;
  double t12125;
  double t12230;
  double t12235;
  double t12236;
  double t12237;
  double t12239;
  double t12240;
  double t12250;
  double t12257;
  double t12259;
  double t12280;
  double t12282;
  double t12284;
  double t12624;
  double t12627;
  double t12629;
  double t12566;
  double t12597;
  double t12598;
  double t12603;
  double t12606;
  double t12613;
  double t12615;
  double t12616;
  double t12617;
  double t12618;
  double t12619;
  double t12622;
  double t12635;
  double t12636;
  double t12642;
  double t12686;
  double t12688;
  double t12644;
  double t12690;
  double t12691;
  double t12646;
  t8463 = Cos(var1[3]);
  t211 = Cos(var1[4]);
  t3939 = Sin(var1[3]);
  t9628 = Sin(var1[4]);
  t11331 = Sin(var1[2]);
  t210 = Cos(var1[2]);
  t11430 = t8463*t211;
  t11437 = -1.*t3939*t9628;
  t11540 = t11430 + t11437;
  t11675 = -1.*t211;
  t11742 = 1. + t11675;
  t11743 = 0.4*t11742;
  t11746 = 0.64*t211;
  t11747 = t11743 + t11746;
  t8462 = -1.*t211*t3939;
  t9797 = -1.*t8463*t9628;
  t9798 = t8462 + t9797;
  t11088 = t210*t9798;
  t11570 = -1.*t11331*t11540;
  t11597 = t11088 + t11570;
  t11860 = Cos(var1[5]);
  t11856 = Cos(var1[6]);
  t11857 = Sin(var1[5]);
  t11861 = Sin(var1[6]);
  t11913 = t11860*t11856;
  t11914 = -1.*t11857*t11861;
  t11915 = t11913 + t11914;
  t11927 = -1.*t11856;
  t11929 = 1. + t11927;
  t11930 = 0.4*t11929;
  t11932 = 0.64*t11856;
  t11935 = t11930 + t11932;
  t11859 = -1.*t11856*t11857;
  t11862 = -1.*t11860*t11861;
  t11863 = t11859 + t11862;
  t11911 = t210*t11863;
  t11916 = -1.*t11331*t11915;
  t11917 = t11911 + t11916;
  t11599 = -1.*t8463*t11331;
  t11600 = -1.*t210*t3939;
  t11603 = t11599 + t11600;
  t11963 = t210*t8463;
  t11964 = -1.*t11331*t3939;
  t11965 = t11963 + t11964;
  t11772 = t210*t11540;
  t11760 = t211*t3939;
  t11761 = t8463*t9628;
  t11762 = t11760 + t11761;
  t11770 = -1.*t11331*t11762;
  t11773 = t11770 + t11772;
  t11920 = -1.*t11860*t11331;
  t11921 = -1.*t210*t11857;
  t11925 = t11920 + t11921;
  t12004 = t210*t11860;
  t12005 = -1.*t11331*t11857;
  t12007 = t12004 + t12005;
  t11950 = t210*t11915;
  t11939 = t11856*t11857;
  t11940 = t11860*t11861;
  t11948 = t11939 + t11940;
  t11949 = -1.*t11331*t11948;
  t11951 = t11949 + t11950;
  t11971 = t8463*t11331;
  t11973 = t210*t3939;
  t11974 = t11971 + t11973;
  t11977 = t11331*t9798;
  t11978 = t11977 + t11772;
  t11981 = t210*t11762;
  t11999 = t11331*t11540;
  t12001 = t11981 + t11999;
  t12009 = t11860*t11331;
  t12010 = t210*t11857;
  t12017 = t12009 + t12010;
  t12021 = t11331*t11863;
  t12022 = t12021 + t11950;
  t12042 = t210*t11948;
  t12061 = t11331*t11915;
  t12062 = t12042 + t12061;
  t12167 = t11747*t3939;
  t12171 = 0.24*t8463*t9628;
  t12172 = t12167 + t12171;
  t12174 = t8463*t11747;
  t12175 = -0.24*t3939*t9628;
  t12177 = t12174 + t12175;
  t12241 = t11935*t11857;
  t12242 = 0.24*t11860*t11861;
  t12243 = t12241 + t12242;
  t12251 = t11860*t11935;
  t12253 = -0.24*t11857*t11861;
  t12255 = t12251 + t12253;
  t11621 = -0.748*t11603;
  t11756 = t11747*t9628;
  t11757 = -0.24*t211*t9628;
  t11758 = t11756 + t11757;
  t11806 = t11747*t211;
  t11810 = Power(t9628,2);
  t11811 = 0.24*t11810;
  t11813 = t11806 + t11811;
  t12297 = -1.*t8463*t211;
  t12301 = t3939*t9628;
  t12303 = t12297 + t12301;
  t12306 = t11331*t12303;
  t12307 = t11088 + t12306;
  t11968 = -13.6*t11603*t11965;
  t11976 = -13.6*t11974*t11965;
  t12068 = Power(t11603,2);
  t12072 = -6.8*t12068;
  t12073 = -6.8*t11603*t11974;
  t12074 = Power(t11965,2);
  t12075 = -6.8*t12074;
  t12076 = -1.*t210*t8463;
  t12079 = t11331*t3939;
  t12080 = t12076 + t12079;
  t12082 = -6.8*t11965*t12080;
  t12083 = -1.*t11331*t9798;
  t12152 = Power(t8463,2);
  t12153 = 0.11*t12152;
  t12154 = Power(t3939,2);
  t12160 = 0.11*t12154;
  t12161 = t12153 + t12160;
  t12163 = -6.8*t11603*t12161;
  t12173 = -1.*t12172*t11540;
  t12179 = -1.*t9798*t12177;
  t12201 = t12173 + t12179;
  t12206 = t12172*t11762;
  t12207 = t11540*t12177;
  t12210 = t12206 + t12207;
  t12391 = -1.*t11747*t3939;
  t12393 = -0.24*t8463*t9628;
  t12394 = t12391 + t12393;
  t12308 = 0.384*var2[4]*t12307;
  t12311 = -3.2*t11758*t11978;
  t12312 = -3.2*t11813*t12307;
  t12341 = -6.4*t11978*t12001;
  t12342 = -6.4*t11978*t12307;
  t12345 = -3.2*t11978*t11773;
  t12346 = -3.2*t11597*t12001;
  t12348 = t210*t12303;
  t12349 = t12083 + t12348;
  t12350 = -3.2*t11978*t12349;
  t12351 = -3.2*t11597*t12307;
  t12390 = -3.2*t11978*t12201;
  t12400 = t12172*t11540;
  t12403 = t9798*t12177;
  t12455 = -3.2*t12210*t12307;
  t12508 = -0.24*t211*t3939;
  t12509 = t12508 + t12393;
  t12458 = -1.*t9798*t12172;
  t12512 = 0.24*t8463*t211;
  t12513 = t12512 + t12175;
  t12462 = -1.*t12177*t12303;
  t11926 = -0.748*t11925;
  t11936 = t11935*t11861;
  t11937 = -0.24*t11856*t11861;
  t11938 = t11936 + t11937;
  t11954 = t11935*t11856;
  t11956 = Power(t11861,2);
  t11958 = 0.24*t11956;
  t11959 = t11954 + t11958;
  t12549 = -1.*t11860*t11856;
  t12555 = t11857*t11861;
  t12559 = t12549 + t12555;
  t12562 = t11331*t12559;
  t12564 = t11911 + t12562;
  t12008 = -13.6*t11925*t12007;
  t12020 = -13.6*t12017*t12007;
  t12103 = Power(t11925,2);
  t12105 = -6.8*t12103;
  t12106 = -6.8*t11925*t12017;
  t12107 = Power(t12007,2);
  t12109 = -6.8*t12107;
  t12111 = -1.*t210*t11860;
  t12117 = t11331*t11857;
  t12123 = t12111 + t12117;
  t12124 = -6.8*t12007*t12123;
  t12125 = -1.*t11331*t11863;
  t12230 = Power(t11860,2);
  t12235 = 0.11*t12230;
  t12236 = Power(t11857,2);
  t12237 = 0.11*t12236;
  t12239 = t12235 + t12237;
  t12240 = -6.8*t11925*t12239;
  t12250 = -1.*t12243*t11915;
  t12257 = -1.*t11863*t12255;
  t12259 = t12250 + t12257;
  t12280 = t12243*t11948;
  t12282 = t11915*t12255;
  t12284 = t12280 + t12282;
  t12624 = -1.*t11935*t11857;
  t12627 = -0.24*t11860*t11861;
  t12629 = t12624 + t12627;
  t12566 = 0.384*var2[6]*t12564;
  t12597 = -3.2*t11938*t12022;
  t12598 = -3.2*t11959*t12564;
  t12603 = -6.4*t12022*t12062;
  t12606 = -6.4*t12022*t12564;
  t12613 = -3.2*t12022*t11951;
  t12615 = -3.2*t11917*t12062;
  t12616 = t210*t12559;
  t12617 = t12125 + t12616;
  t12618 = -3.2*t12022*t12617;
  t12619 = -3.2*t11917*t12564;
  t12622 = -3.2*t12022*t12259;
  t12635 = t12243*t11915;
  t12636 = t11863*t12255;
  t12642 = -3.2*t12284*t12564;
  t12686 = -0.24*t11856*t11857;
  t12688 = t12686 + t12627;
  t12644 = -1.*t11863*t12243;
  t12690 = 0.24*t11860*t11856;
  t12691 = t12690 + t12253;
  t12646 = -1.*t12255*t12559;
  p_output1[0]=0;
  p_output1[1]=0;
  p_output1[2]=var2[0]*(-0.5*(t11968 + t11976 - 6.4*t11597*t11978 - 6.4*t11773*t12001 + t12008 + t12020 - 6.4*t11917*t12022 - 6.4*t11951*t12062)*var2[0] - 0.5*(-3.2*Power(t11597,2) - 3.2*Power(t11773,2) - 3.2*Power(t11917,2) - 3.2*Power(t11951,2) + t12072 + t12073 + t12075 + t12082 + t12105 + t12106 + t12109 + t12124 - 3.2*t11978*(t12083 - 1.*t11540*t210) - 3.2*t12001*(t11570 - 1.*t11762*t210) - 3.2*t12022*(t12125 - 1.*t11915*t210) - 3.2*t12062*(t11916 - 1.*t11948*t210))*var2[1] - 0.5*(2.88*t11331 + t12163 - 3.2*t11773*t12201 - 3.2*t11597*t12210 + t12240 - 3.2*t11951*t12259 - 3.2*t11917*t12284)*var2[2] - 0.5*(t11621 - 3.2*t11758*t11773 - 3.2*t11597*t11813)*var2[3] + 0.384*t11597*var2[4] - 0.5*(t11926 - 3.2*t11938*t11951 - 3.2*t11917*t11959)*var2[5] + 0.384*t11917*var2[6]);
  p_output1[3]=var2[0]*(t12308 - 0.5*(t11968 + t11976 + t12341 + t12342)*var2[0] - 0.5*(t12072 + t12073 + t12075 + t12082 + t12345 + t12346 + t12350 + t12351)*var2[1] - 0.5*(t12163 + t12390 - 3.2*t11978*(t11762*t12177 + t11540*t12394 + t12400 + t12403) + t12455 - 3.2*t12001*(-1.*t11540*t12177 + t12458 + t12462 - 1.*t12394*t9798))*var2[2] - 0.5*(t11621 + t12311 + t12312)*var2[3]);
  p_output1[4]=var2[0]*(t12308 - 0.5*(t12341 + t12342)*var2[0] - 0.5*(t12345 + t12346 + t12350 + t12351)*var2[1] - 0.5*(t12390 + t12455 - 3.2*t11978*(t12400 + t12403 + t11540*t12509 + t11762*t12513) - 3.2*t12001*(t12458 + t12462 - 1.*t11540*t12513 - 1.*t12509*t9798))*var2[2] - 0.5*(t12311 + t12312 - 3.2*t12001*(t11806 - 0.24*Power(t211,2)) - 3.2*t11978*(-1.*t11747*t9628 + 0.24*t211*t9628))*var2[3]);
  p_output1[5]=var2[0]*(t12566 - 0.5*(t12008 + t12020 + t12603 + t12606)*var2[0] - 0.5*(t12105 + t12106 + t12109 + t12124 + t12613 + t12615 + t12618 + t12619)*var2[1] - 0.5*(t12240 + t12622 - 3.2*t12022*(t11948*t12255 + t11915*t12629 + t12635 + t12636) + t12642 - 3.2*t12062*(-1.*t11915*t12255 - 1.*t11863*t12629 + t12644 + t12646))*var2[2] - 0.5*(t11926 + t12597 + t12598)*var2[5]);
  p_output1[6]=var2[0]*(t12566 - 0.5*(t12603 + t12606)*var2[0] - 0.5*(t12613 + t12615 + t12618 + t12619)*var2[1] - 0.5*(t12622 + t12642 - 3.2*t12062*(t12644 + t12646 - 1.*t11863*t12688 - 1.*t11915*t12691) - 3.2*t12022*(t12635 + t12636 + t11915*t12688 + t11948*t12691))*var2[2] - 0.5*(-3.2*(0.24*t11856*t11861 - 1.*t11861*t11935)*t12022 - 3.2*(-0.24*Power(t11856,2) + t11954)*t12062 + t12597 + t12598)*var2[5]);
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 7, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "Ce3_vec1_five_link_walker.hh"

namespace RightStance
{

void Ce3_vec1_five_link_walker_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
