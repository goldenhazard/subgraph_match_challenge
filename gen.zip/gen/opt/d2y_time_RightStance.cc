/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:33:16 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2,const double *var3,const double *var4,const double *var5,const double *var6)
{
  double t865;
  double t871;
  double t876;
  double t880;
  double t888;
  double t910;
  double t914;
  double t927;
  double t936;
  double t950;
  double t964;
  double t977;
  double t986;
  double t997;
  double t999;
  double t1032;
  double t1040;
  double t1045;
  double t1046;
  double t1050;
  double t1051;
  double t1052;
  double t1053;
  double t1054;
  double t1055;
  double t1058;
  double t1062;
  double t1063;
  double t1106;
  double t1107;
  double t1111;
  double t1112;
  double t1113;
  double t1118;
  double t1119;
  double t1124;
  double t1125;
  double t1126;
  double t1127;
  double t1128;
  double t1129;
  double t1100;
  double t1130;
  double t1131;
  double t1132;
  double t1135;
  double t1165;
  double t1173;
  double t1174;
  double t1175;
  double t1176;
  double t1177;
  double t1178;
  double t1179;
  double t1188;
  double t1189;
  double t1190;
  double t1191;
  double t1198;
  double t1199;
  double t1200;
  double t1201;
  double t1204;
  double t1205;
  double t1206;
  double t1207;
  double t1220;
  double t1221;
  double t1285;
  double t1286;
  double t1287;
  double t1289;
  double t1291;
  double t1296;
  double t1297;
  double t1299;
  double t1300;
  double t1313;
  double t1314;
  double t1315;
  double t1316;
  double t1322;
  double t1323;
  double t1324;
  double t1325;
  double t1326;
  double t1327;
  double t1328;
  double t1329;
  double t1330;
  double t1331;
  double t1332;
  double t1334;
  double t1335;
  double t1321;
  double t1336;
  double t1340;
  double t1341;
  double t1378;
  double t1380;
  double t1381;
  double t1382;
  double t1383;
  double t1387;
  double t1388;
  double t1408;
  double t1409;
  double t1410;
  double t1411;
  double t1420;
  double t1421;
  double t3919;
  double t8322;
  double t8454;
  double t8647;
  double t8682;
  double t9673;
  double t9678;
  double t9679;
  double t9680;
  double t1256;
  double t1262;
  double t11769;
  double t11805;
  double t11809;
  double t11966;
  double t12025;
  double t12193;
  double t12531;
  double t12654;
  double t12707;
  double t13550;
  double t13555;
  double t13618;
  double t13680;
  double t15825;
  double t15833;
  double t15834;
  double t15847;
  double t15874;
  double t15888;
  double t15889;
  double t15897;
  double t15901;
  double t15909;
  double t15917;
  double t15930;
  double t15931;
  double t15820;
  double t15934;
  double t15935;
  double t15943;
  double t16032;
  double t16034;
  double t16037;
  double t16038;
  double t16046;
  double t16048;
  double t16051;
  double t16052;
  double t16053;
  double t16054;
  double t16056;
  double t16070;
  double t16074;
  double t16075;
  double t16077;
  double t16078;
  double t16079;
  double t16080;
  double t16082;
  double t16083;
  double t16084;
  double t16089;
  double t16204;
  double t16211;
  double t16228;
  double t16229;
  double t16235;
  double t16238;
  double t16239;
  double t16245;
  double t16246;
  double t16247;
  double t16273;
  double t16277;
  double t16310;
  double t16327;
  double t16329;
  double t16330;
  double t16332;
  double t16337;
  double t16338;
  double t16356;
  double t16390;
  double t16434;
  double t16460;
  double t16466;
  double t16470;
  double t16475;
  double t16323;
  double t16476;
  double t16478;
  double t16484;
  double t18050;
  double t18051;
  double t18052;
  double t18053;
  double t18054;
  double t18055;
  double t18056;
  double t18057;
  double t18058;
  double t18093;
  double t18094;
  double t18099;
  double t18100;
  double t18101;
  double t18102;
  double t18103;
  double t18104;
  double t18105;
  double t18170;
  double t18171;
  double t18172;
  double t18173;
  t865 = -1.*var5[1];
  t871 = var5[0] + t865;
  t876 = Power(t871,-2);
  t880 = 1/t871;
  t888 = 0.5*var1[4];
  t910 = t865 + var1[2] + var1[3] + t888;
  t914 = -1.*t880*t910;
  t927 = 1. + t914;
  t936 = Power(t927,3);
  t950 = Power(t871,-3);
  t964 = Power(t927,2);
  t977 = Power(t871,-4);
  t986 = Power(t910,2);
  t997 = Power(t871,-5);
  t999 = Power(t910,3);
  t1032 = 10.*var4[0]*t876*t936;
  t1040 = -20.*var4[4]*t876*t936;
  t1045 = 10.*var4[8]*t876*t936;
  t1046 = 30.*var4[4]*t950*t964*t910;
  t1050 = -60.*var4[8]*t950*t964*t910;
  t1051 = 30.*var4[12]*t950*t964*t910;
  t1052 = 30.*var4[8]*t977*t927*t986;
  t1053 = -60.*var4[12]*t977*t927*t986;
  t1054 = 30.*var4[16]*t977*t927*t986;
  t1055 = 10.*var4[12]*t997*t999;
  t1058 = -20.*var4[16]*t997*t999;
  t1062 = 10.*var4[20]*t997*t999;
  t1063 = t1032 + t1040 + t1045 + t1046 + t1050 + t1051 + t1052 + t1053 + t1054 + t1055 + t1058 + t1062;
  t1106 = 20.*var4[0]*t876*t936;
  t1107 = -40.*var4[4]*t876*t936;
  t1111 = 20.*var4[8]*t876*t936;
  t1112 = 60.*var4[4]*t950*t964*t910;
  t1113 = -120.*var4[8]*t950*t964*t910;
  t1118 = 60.*var4[12]*t950*t964*t910;
  t1119 = 60.*var4[8]*t977*t927*t986;
  t1124 = -120.*var4[12]*t977*t927*t986;
  t1125 = 60.*var4[16]*t977*t927*t986;
  t1126 = 20.*var4[12]*t997*t999;
  t1127 = -40.*var4[16]*t997*t999;
  t1128 = 20.*var4[20]*t997*t999;
  t1129 = t1106 + t1107 + t1111 + t1112 + t1113 + t1118 + t1119 + t1124 + t1125 + t1126 + t1127 + t1128;
  t1100 = -1.*var2[4]*t1063;
  t1130 = -1.*var2[2]*t1129;
  t1131 = -1.*var2[3]*t1129;
  t1132 = t1100 + t1130 + t1131;
  t1135 = Power(t927,4);
  t1165 = Power(t910,4);
  t1173 = -5.*var4[0]*t880*t1135;
  t1174 = 5.*var4[4]*t880*t1135;
  t1175 = -20.*var4[4]*t876*t936*t910;
  t1176 = 20.*var4[8]*t876*t936*t910;
  t1177 = -30.*var4[8]*t950*t964*t986;
  t1178 = 30.*var4[12]*t950*t964*t986;
  t1179 = -20.*var4[12]*t977*t927*t999;
  t1188 = 20.*var4[16]*t977*t927*t999;
  t1189 = -5.*var4[16]*t997*t1165;
  t1190 = 5.*var4[20]*t997*t1165;
  t1191 = t1173 + t1174 + t1175 + t1176 + t1177 + t1178 + t1179 + t1188 + t1189 + t1190;
  t1198 = 5.*var4[0]*t880*t1135;
  t1199 = -5.*var4[4]*t880*t1135;
  t1200 = 20.*var4[4]*t876*t936*t910;
  t1201 = -20.*var4[8]*t876*t936*t910;
  t1204 = 30.*var4[8]*t950*t964*t986;
  t1205 = -30.*var4[12]*t950*t964*t986;
  t1206 = 20.*var4[12]*t977*t927*t999;
  t1207 = -20.*var4[16]*t977*t927*t999;
  t1220 = 5.*var4[16]*t997*t1165;
  t1221 = -5.*var4[20]*t997*t1165;
  t1285 = 10.*var4[1]*t876*t936;
  t1286 = -20.*var4[5]*t876*t936;
  t1287 = 10.*var4[9]*t876*t936;
  t1289 = 30.*var4[5]*t950*t964*t910;
  t1291 = -60.*var4[9]*t950*t964*t910;
  t1296 = 30.*var4[13]*t950*t964*t910;
  t1297 = 30.*var4[9]*t977*t927*t986;
  t1299 = -60.*var4[13]*t977*t927*t986;
  t1300 = 30.*var4[17]*t977*t927*t986;
  t1313 = 10.*var4[13]*t997*t999;
  t1314 = -20.*var4[17]*t997*t999;
  t1315 = 10.*var4[21]*t997*t999;
  t1316 = t1285 + t1286 + t1287 + t1289 + t1291 + t1296 + t1297 + t1299 + t1300 + t1313 + t1314 + t1315;
  t1322 = 20.*var4[1]*t876*t936;
  t1323 = -40.*var4[5]*t876*t936;
  t1324 = 20.*var4[9]*t876*t936;
  t1325 = 60.*var4[5]*t950*t964*t910;
  t1326 = -120.*var4[9]*t950*t964*t910;
  t1327 = 60.*var4[13]*t950*t964*t910;
  t1328 = 60.*var4[9]*t977*t927*t986;
  t1329 = -120.*var4[13]*t977*t927*t986;
  t1330 = 60.*var4[17]*t977*t927*t986;
  t1331 = 20.*var4[13]*t997*t999;
  t1332 = -40.*var4[17]*t997*t999;
  t1334 = 20.*var4[21]*t997*t999;
  t1335 = t1322 + t1323 + t1324 + t1325 + t1326 + t1327 + t1328 + t1329 + t1330 + t1331 + t1332 + t1334;
  t1321 = -1.*var2[4]*t1316;
  t1336 = -1.*var2[2]*t1335;
  t1340 = -1.*var2[3]*t1335;
  t1341 = t1321 + t1336 + t1340;
  t1378 = -5.*var4[1]*t880*t1135;
  t1380 = 5.*var4[5]*t880*t1135;
  t1381 = -20.*var4[5]*t876*t936*t910;
  t1382 = 20.*var4[9]*t876*t936*t910;
  t1383 = -30.*var4[9]*t950*t964*t986;
  t1387 = 30.*var4[13]*t950*t964*t986;
  t1388 = -20.*var4[13]*t977*t927*t999;
  t1408 = 20.*var4[17]*t977*t927*t999;
  t1409 = -5.*var4[17]*t997*t1165;
  t1410 = 5.*var4[21]*t997*t1165;
  t1411 = t1378 + t1380 + t1381 + t1382 + t1383 + t1387 + t1388 + t1408 + t1409 + t1410;
  t1420 = 5.*var4[1]*t880*t1135;
  t1421 = -5.*var4[5]*t880*t1135;
  t3919 = 20.*var4[5]*t876*t936*t910;
  t8322 = -20.*var4[9]*t876*t936*t910;
  t8454 = 30.*var4[9]*t950*t964*t986;
  t8647 = -30.*var4[13]*t950*t964*t986;
  t8682 = 20.*var4[13]*t977*t927*t999;
  t9673 = -20.*var4[17]*t977*t927*t999;
  t9678 = 5.*var4[17]*t997*t1165;
  t9679 = -5.*var4[21]*t997*t1165;
  t9680 = t1420 + t1421 + t3919 + t8322 + t8454 + t8647 + t8682 + t9673 + t9678 + t9679;
  t1256 = Power(t927,5);
  t1262 = Power(t910,5);
  t11769 = 10.*var4[2]*t876*t936;
  t11805 = -20.*var4[6]*t876*t936;
  t11809 = 10.*var4[10]*t876*t936;
  t11966 = 30.*var4[6]*t950*t964*t910;
  t12025 = -60.*var4[10]*t950*t964*t910;
  t12193 = 30.*var4[14]*t950*t964*t910;
  t12531 = 30.*var4[10]*t977*t927*t986;
  t12654 = -60.*var4[14]*t977*t927*t986;
  t12707 = 30.*var4[18]*t977*t927*t986;
  t13550 = 10.*var4[14]*t997*t999;
  t13555 = -20.*var4[18]*t997*t999;
  t13618 = 10.*var4[22]*t997*t999;
  t13680 = t11769 + t11805 + t11809 + t11966 + t12025 + t12193 + t12531 + t12654 + t12707 + t13550 + t13555 + t13618;
  t15825 = 20.*var4[2]*t876*t936;
  t15833 = -40.*var4[6]*t876*t936;
  t15834 = 20.*var4[10]*t876*t936;
  t15847 = 60.*var4[6]*t950*t964*t910;
  t15874 = -120.*var4[10]*t950*t964*t910;
  t15888 = 60.*var4[14]*t950*t964*t910;
  t15889 = 60.*var4[10]*t977*t927*t986;
  t15897 = -120.*var4[14]*t977*t927*t986;
  t15901 = 60.*var4[18]*t977*t927*t986;
  t15909 = 20.*var4[14]*t997*t999;
  t15917 = -40.*var4[18]*t997*t999;
  t15930 = 20.*var4[22]*t997*t999;
  t15931 = t15825 + t15833 + t15834 + t15847 + t15874 + t15888 + t15889 + t15897 + t15901 + t15909 + t15917 + t15930;
  t15820 = -1.*var2[4]*t13680;
  t15934 = -1.*var2[2]*t15931;
  t15935 = -1.*var2[3]*t15931;
  t15943 = t15820 + t15934 + t15935;
  t16032 = -5.*var4[2]*t880*t1135;
  t16034 = 5.*var4[6]*t880*t1135;
  t16037 = -20.*var4[6]*t876*t936*t910;
  t16038 = 20.*var4[10]*t876*t936*t910;
  t16046 = -30.*var4[10]*t950*t964*t986;
  t16048 = 30.*var4[14]*t950*t964*t986;
  t16051 = -20.*var4[14]*t977*t927*t999;
  t16052 = 20.*var4[18]*t977*t927*t999;
  t16053 = -5.*var4[18]*t997*t1165;
  t16054 = 5.*var4[22]*t997*t1165;
  t16056 = t16032 + t16034 + t16037 + t16038 + t16046 + t16048 + t16051 + t16052 + t16053 + t16054;
  t16070 = 5.*var4[2]*t880*t1135;
  t16074 = -5.*var4[6]*t880*t1135;
  t16075 = 20.*var4[6]*t876*t936*t910;
  t16077 = -20.*var4[10]*t876*t936*t910;
  t16078 = 30.*var4[10]*t950*t964*t986;
  t16079 = -30.*var4[14]*t950*t964*t986;
  t16080 = 20.*var4[14]*t977*t927*t999;
  t16082 = -20.*var4[18]*t977*t927*t999;
  t16083 = 5.*var4[18]*t997*t1165;
  t16084 = -5.*var4[22]*t997*t1165;
  t16089 = t16070 + t16074 + t16075 + t16077 + t16078 + t16079 + t16080 + t16082 + t16083 + t16084;
  t16204 = 10.*var4[3]*t876*t936;
  t16211 = -20.*var4[7]*t876*t936;
  t16228 = 10.*var4[11]*t876*t936;
  t16229 = 30.*var4[7]*t950*t964*t910;
  t16235 = -60.*var4[11]*t950*t964*t910;
  t16238 = 30.*var4[15]*t950*t964*t910;
  t16239 = 30.*var4[11]*t977*t927*t986;
  t16245 = -60.*var4[15]*t977*t927*t986;
  t16246 = 30.*var4[19]*t977*t927*t986;
  t16247 = 10.*var4[15]*t997*t999;
  t16273 = -20.*var4[19]*t997*t999;
  t16277 = 10.*var4[23]*t997*t999;
  t16310 = t16204 + t16211 + t16228 + t16229 + t16235 + t16238 + t16239 + t16245 + t16246 + t16247 + t16273 + t16277;
  t16327 = 20.*var4[3]*t876*t936;
  t16329 = -40.*var4[7]*t876*t936;
  t16330 = 20.*var4[11]*t876*t936;
  t16332 = 60.*var4[7]*t950*t964*t910;
  t16337 = -120.*var4[11]*t950*t964*t910;
  t16338 = 60.*var4[15]*t950*t964*t910;
  t16356 = 60.*var4[11]*t977*t927*t986;
  t16390 = -120.*var4[15]*t977*t927*t986;
  t16434 = 60.*var4[19]*t977*t927*t986;
  t16460 = 20.*var4[15]*t997*t999;
  t16466 = -40.*var4[19]*t997*t999;
  t16470 = 20.*var4[23]*t997*t999;
  t16475 = t16327 + t16329 + t16330 + t16332 + t16337 + t16338 + t16356 + t16390 + t16434 + t16460 + t16466 + t16470;
  t16323 = -1.*var2[4]*t16310;
  t16476 = -1.*var2[2]*t16475;
  t16478 = -1.*var2[3]*t16475;
  t16484 = t16323 + t16476 + t16478;
  t18050 = -5.*var4[3]*t880*t1135;
  t18051 = 5.*var4[7]*t880*t1135;
  t18052 = -20.*var4[7]*t876*t936*t910;
  t18053 = 20.*var4[11]*t876*t936*t910;
  t18054 = -30.*var4[11]*t950*t964*t986;
  t18055 = 30.*var4[15]*t950*t964*t986;
  t18056 = -20.*var4[15]*t977*t927*t999;
  t18057 = 20.*var4[19]*t977*t927*t999;
  t18058 = -5.*var4[19]*t997*t1165;
  t18093 = 5.*var4[23]*t997*t1165;
  t18094 = t18050 + t18051 + t18052 + t18053 + t18054 + t18055 + t18056 + t18057 + t18058 + t18093;
  t18099 = 5.*var4[3]*t880*t1135;
  t18100 = -5.*var4[7]*t880*t1135;
  t18101 = 20.*var4[7]*t876*t936*t910;
  t18102 = -20.*var4[11]*t876*t936*t910;
  t18103 = 30.*var4[11]*t950*t964*t986;
  t18104 = -30.*var4[15]*t950*t964*t986;
  t18105 = 20.*var4[15]*t977*t927*t999;
  t18170 = -20.*var4[19]*t977*t927*t999;
  t18171 = 5.*var4[19]*t997*t1165;
  t18172 = -5.*var4[23]*t997*t1165;
  t18173 = t18099 + t18100 + t18101 + t18102 + t18103 + t18104 + t18105 + t18170 + t18171 + t18172;
  p_output1[0]=t1132*var2[2] + t1132*var2[3] + (t1198 + t1199 + t1200 + t1201 + t1204 + t1205 + t1206 + t1207 + t1220 + t1221)*var3[2] + (1. + t1198 + t1199 + t1200 + t1201 + t1204 + t1205 + t1206 + t1207 + t1220 + t1221)*var3[3] + var3[4]*(2.5*t1135*t880*var4[0] - 2.5*t1135*t880*var4[4] + 10.*t876*t910*t936*var4[4] - 10.*t876*t910*t936*var4[8] + 15.*t950*t964*t986*var4[8] - 15.*t950*t964*t986*var4[12] + 10.*t927*t977*t999*var4[12] + 2.5*t1165*t997*var4[16] - 10.*t927*t977*t999*var4[16] - 2.5*t1165*t997*var4[20]) + var2[4]*(-1.*t1063*var2[2] - 1.*t1063*var2[3] - 1.*var2[4]*(5.*t876*t936*var4[0] - 10.*t876*t936*var4[4] + 15.*t910*t950*t964*var4[4] + 5.*t876*t936*var4[8] - 30.*t910*t950*t964*var4[8] + 15.*t927*t977*t986*var4[8] + 15.*t910*t950*t964*var4[12] - 30.*t927*t977*t986*var4[12] + 5.*t997*t999*var4[12] + 15.*t927*t977*t986*var4[16] - 10.*t997*t999*var4[16] + 5.*t997*t999*var4[20])) + (var1[3] - 1.*t1256*var4[0] - 5.*t1135*t880*t910*var4[4] - 10.*t876*t936*t986*var4[8] - 10.*t950*t964*t999*var4[12] - 5.*t1165*t927*t977*var4[16] - 1.*t1262*t997*var4[20])*var6[0] + (-1.*t1191*var2[2] + var2[3] - 1.*t1191*var2[3] - 1.*var2[4]*(-2.5*t1135*t880*var4[0] + 2.5*t1135*t880*var4[4] - 10.*t876*t910*t936*var4[4] + 10.*t876*t910*t936*var4[8] - 15.*t950*t964*t986*var4[8] + 15.*t950*t964*t986*var4[12] - 10.*t927*t977*t999*var4[12] - 2.5*t1165*t997*var4[16] + 10.*t927*t977*t999*var4[16] + 2.5*t1165*t997*var4[20]))*var6[1];
  p_output1[1]=t1341*var2[2] + t1341*var2[3] + t9680*var3[2] + t9680*var3[3] + var3[4]*(1. + 2.5*t1135*t880*var4[1] - 2.5*t1135*t880*var4[5] + 10.*t876*t910*t936*var4[5] - 10.*t876*t910*t936*var4[9] + 15.*t950*t964*t986*var4[9] - 15.*t950*t964*t986*var4[13] + 10.*t927*t977*t999*var4[13] + 2.5*t1165*t997*var4[17] - 10.*t927*t977*t999*var4[17] - 2.5*t1165*t997*var4[21]) + var2[4]*(-1.*t1316*var2[2] - 1.*t1316*var2[3] - 1.*var2[4]*(5.*t876*t936*var4[1] - 10.*t876*t936*var4[5] + 15.*t910*t950*t964*var4[5] + 5.*t876*t936*var4[9] - 30.*t910*t950*t964*var4[9] + 15.*t927*t977*t986*var4[9] + 15.*t910*t950*t964*var4[13] - 30.*t927*t977*t986*var4[13] + 5.*t997*t999*var4[13] + 15.*t927*t977*t986*var4[17] - 10.*t997*t999*var4[17] + 5.*t997*t999*var4[21])) + (var1[4] - 1.*t1256*var4[1] - 5.*t1135*t880*t910*var4[5] - 10.*t876*t936*t986*var4[9] - 10.*t950*t964*t999*var4[13] - 5.*t1165*t927*t977*var4[17] - 1.*t1262*t997*var4[21])*var6[0] + (-1.*t1411*var2[2] - 1.*t1411*var2[3] + var2[4] - 1.*var2[4]*(-2.5*t1135*t880*var4[1] + 2.5*t1135*t880*var4[5] - 10.*t876*t910*t936*var4[5] + 10.*t876*t910*t936*var4[9] - 15.*t950*t964*t986*var4[9] + 15.*t950*t964*t986*var4[13] - 10.*t927*t977*t999*var4[13] - 2.5*t1165*t997*var4[17] + 10.*t927*t977*t999*var4[17] + 2.5*t1165*t997*var4[21]))*var6[1];
  p_output1[2]=t15943*var2[2] + t15943*var2[3] + t16089*var3[2] + t16089*var3[3] + var3[5] + var3[4]*(2.5*t1135*t880*var4[2] - 2.5*t1135*t880*var4[6] + 10.*t876*t910*t936*var4[6] - 10.*t876*t910*t936*var4[10] + 15.*t950*t964*t986*var4[10] - 15.*t950*t964*t986*var4[14] + 10.*t927*t977*t999*var4[14] + 2.5*t1165*t997*var4[18] - 10.*t927*t977*t999*var4[18] - 2.5*t1165*t997*var4[22]) + var2[4]*(-1.*t13680*var2[2] - 1.*t13680*var2[3] - 1.*var2[4]*(5.*t876*t936*var4[2] - 10.*t876*t936*var4[6] + 15.*t910*t950*t964*var4[6] + 5.*t876*t936*var4[10] - 30.*t910*t950*t964*var4[10] + 15.*t927*t977*t986*var4[10] + 15.*t910*t950*t964*var4[14] - 30.*t927*t977*t986*var4[14] + 5.*t997*t999*var4[14] + 15.*t927*t977*t986*var4[18] - 10.*t997*t999*var4[18] + 5.*t997*t999*var4[22])) + (var1[5] - 1.*t1256*var4[2] - 5.*t1135*t880*t910*var4[6] - 10.*t876*t936*t986*var4[10] - 10.*t950*t964*t999*var4[14] - 5.*t1165*t927*t977*var4[18] - 1.*t1262*t997*var4[22])*var6[0] + (-1.*t16056*var2[2] - 1.*t16056*var2[3] + var2[5] - 1.*var2[4]*(-2.5*t1135*t880*var4[2] + 2.5*t1135*t880*var4[6] - 10.*t876*t910*t936*var4[6] + 10.*t876*t910*t936*var4[10] - 15.*t950*t964*t986*var4[10] + 15.*t950*t964*t986*var4[14] - 10.*t927*t977*t999*var4[14] - 2.5*t1165*t997*var4[18] + 10.*t927*t977*t999*var4[18] + 2.5*t1165*t997*var4[22]))*var6[1];
  p_output1[3]=t16484*var2[2] + t16484*var2[3] + t18173*var3[2] + t18173*var3[3] + var3[6] + var3[4]*(2.5*t1135*t880*var4[3] - 2.5*t1135*t880*var4[7] + 10.*t876*t910*t936*var4[7] - 10.*t876*t910*t936*var4[11] + 15.*t950*t964*t986*var4[11] - 15.*t950*t964*t986*var4[15] + 10.*t927*t977*t999*var4[15] + 2.5*t1165*t997*var4[19] - 10.*t927*t977*t999*var4[19] - 2.5*t1165*t997*var4[23]) + var2[4]*(-1.*t16310*var2[2] - 1.*t16310*var2[3] - 1.*var2[4]*(5.*t876*t936*var4[3] - 10.*t876*t936*var4[7] + 15.*t910*t950*t964*var4[7] + 5.*t876*t936*var4[11] - 30.*t910*t950*t964*var4[11] + 15.*t927*t977*t986*var4[11] + 15.*t910*t950*t964*var4[15] - 30.*t927*t977*t986*var4[15] + 5.*t997*t999*var4[15] + 15.*t927*t977*t986*var4[19] - 10.*t997*t999*var4[19] + 5.*t997*t999*var4[23])) + (var1[6] - 1.*t1256*var4[3] - 5.*t1135*t880*t910*var4[7] - 10.*t876*t936*t986*var4[11] - 10.*t950*t964*t999*var4[15] - 5.*t1165*t927*t977*var4[19] - 1.*t1262*t997*var4[23])*var6[0] + (-1.*t18094*var2[2] - 1.*t18094*var2[3] + var2[6] - 1.*var2[4]*(-2.5*t1135*t880*var4[3] + 2.5*t1135*t880*var4[7] - 10.*t876*t910*t936*var4[7] + 10.*t876*t910*t936*var4[11] - 15.*t950*t964*t986*var4[11] + 15.*t950*t964*t986*var4[15] - 10.*t927*t977*t999*var4[15] - 2.5*t1165*t997*var4[19] + 10.*t927*t977*t999*var4[19] + 2.5*t1165*t997*var4[23]))*var6[1];
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2,*var3,*var4,*var5,*var6;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 6)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Six input(s) required (var1,var2,var3,var4,var5,var6).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }
  mrows = mxGetM(prhs[2]);
  ncols = mxGetN(prhs[2]);
  if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var3 is wrong.");
    }
  mrows = mxGetM(prhs[3]);
  ncols = mxGetN(prhs[3]);
  if( !mxIsDouble(prhs[3]) || mxIsComplex(prhs[3]) ||
    ( !(mrows == 24 && ncols == 1) && 
      !(mrows == 1 && ncols == 24))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var4 is wrong.");
    }
  mrows = mxGetM(prhs[4]);
  ncols = mxGetN(prhs[4]);
  if( !mxIsDouble(prhs[4]) || mxIsComplex(prhs[4]) ||
    ( !(mrows == 2 && ncols == 1) && 
      !(mrows == 1 && ncols == 2))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var5 is wrong.");
    }
  mrows = mxGetM(prhs[5]);
  ncols = mxGetN(prhs[5]);
  if( !mxIsDouble(prhs[5]) || mxIsComplex(prhs[5]) ||
    ( !(mrows == 2 && ncols == 1) && 
      !(mrows == 1 && ncols == 2))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var6 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
  var3 = mxGetPr(prhs[2]);
  var4 = mxGetPr(prhs[3]);
  var5 = mxGetPr(prhs[4]);
  var6 = mxGetPr(prhs[5]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 4, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2,var3,var4,var5,var6);


}

#else // MATLAB_MEX_FILE

#include "d2y_time_RightStance.hh"

namespace RightStance
{

void d2y_time_RightStance_raw(double *p_output1, const double *var1,const double *var2,const double *var3,const double *var4,const double *var5,const double *var6)
{
  // Call Subroutines
  output1(p_output1, var1, var2, var3, var4, var5, var6);

}

}

#endif // MATLAB_MEX_FILE
