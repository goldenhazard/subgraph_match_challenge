/*
 * Automatically Generated from Mathematica.
 * Sat 23 Nov 2019 19:29:37 GMT-08:00
 */

#ifdef MATLAB_MEX_FILE
#include <stdexcept>
#include <cmath>
#include<math.h>
/**
 * Copied from Wolfram Mathematica C Definitions file mdefs.hpp
 * Changed marcos to inline functions (Eric Cousineau)
 */
inline double Power(double x, double y) { return pow(x, y); }
inline double Sqrt(double x) { return sqrt(x); }

inline double Abs(double x) { return fabs(x); }

inline double Exp(double x) { return exp(x); }
inline double Log(double x) { return log(x); }

inline double Sin(double x) { return sin(x); }
inline double Cos(double x) { return cos(x); }
inline double Tan(double x) { return tan(x); }

inline double ArcSin(double x) { return asin(x); }
inline double ArcCos(double x) { return acos(x); }
inline double ArcTan(double x) { return atan(x); }

/* update ArcTan function to use atan2 instead. */
inline double ArcTan(double x, double y) { return atan2(y,x); }

inline double Sinh(double x) { return sinh(x); }
inline double Cosh(double x) { return cosh(x); }
inline double Tanh(double x) { return tanh(x); }

const double E	= 2.71828182845904523536029;
const double Pi = 3.14159265358979323846264;
const double Degree = 0.01745329251994329576924;

inline double Sec(double x) { return 1/cos(x); }
inline double Csc(double x) { return 1/sin(x); }

#endif

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var1,const double *var2)
{
  double t11946;
  double t11506;
  double t11825;
  double t11991;
  double t11485;
  double t11904;
  double t12032;
  double t12035;
  double t12048;
  double t12051;
  double t12052;
  double t12053;
  double t12217;
  double t12338;
  double t12354;
  double t12355;
  double t12321;
  double t12324;
  double t12325;
  double t12332;
  double t12333;
  double t12358;
  double t12373;
  double t12376;
  double t12405;
  double t12406;
  double t12407;
  double t12408;
  double t12426;
  double t12445;
  double t12446;
  double t12451;
  double t12441;
  double t12483;
  double t12484;
  double t12485;
  double t12531;
  double t12532;
  double t12047;
  double t12185;
  double t12247;
  double t12275;
  double t12277;
  double t12279;
  double t12320;
  double t12409;
  double t12412;
  double t12415;
  double t12423;
  double t12424;
  double t12428;
  double t12433;
  double t12434;
  double t12437;
  double t12438;
  double t12568;
  double t12569;
  double t12570;
  t11946 = Cos(var1[2]);
  t11506 = Cos(var1[3]);
  t11825 = Sin(var1[2]);
  t11991 = Sin(var1[3]);
  t11485 = Cos(var1[4]);
  t11904 = -1.*t11506*t11825;
  t12032 = -1.*t11946*t11991;
  t12035 = t11904 + t12032;
  t12048 = t11946*t11506;
  t12051 = -1.*t11825*t11991;
  t12052 = t12048 + t12051;
  t12053 = Sin(var1[4]);
  t12217 = t11485*t12035;
  t12338 = -1.*t11946*t11506;
  t12354 = t11825*t11991;
  t12355 = t12338 + t12354;
  t12321 = -1.*t11485;
  t12324 = 1. + t12321;
  t12325 = 0.4*t12324;
  t12332 = 0. + t12325;
  t12333 = t12332*t12035;
  t12358 = -0.4*t12053;
  t12373 = 0. + t12358;
  t12376 = t12355*t12373;
  t12405 = t12355*t12053;
  t12406 = t12217 + t12405;
  t12407 = 0.8*t12406;
  t12408 = t12333 + t12376 + t12407;
  t12426 = t11485*t12355;
  t12445 = t11506*t11825;
  t12446 = t11946*t11991;
  t12451 = t12445 + t12446;
  t12441 = t12332*t12355;
  t12483 = t12451*t12373;
  t12484 = t12451*t12053;
  t12485 = t12426 + t12484;
  t12531 = 0.8*t12485;
  t12532 = t12441 + t12483 + t12531;
  t12047 = -0.4*t11485*t12035;
  t12185 = 0.4*t12052*t12053;
  t12247 = -1.*t12052*t12053;
  t12275 = t12217 + t12247;
  t12277 = 0.8*t12275;
  t12279 = t12047 + t12185 + t12277;
  t12320 = var2[4]*t12279;
  t12409 = var2[2]*t12408;
  t12412 = var2[3]*t12408;
  t12415 = t12320 + t12409 + t12412;
  t12423 = -0.4*t11485*t12355;
  t12424 = 0.4*t12035*t12053;
  t12428 = -1.*t12035*t12053;
  t12433 = t12426 + t12428;
  t12434 = 0.8*t12433;
  t12437 = t12423 + t12424 + t12434;
  t12438 = var2[4]*t12437;
  t12568 = var2[2]*t12532;
  t12569 = var2[3]*t12532;
  t12570 = t12438 + t12568 + t12569;
  p_output1[0]=0;
  p_output1[1]=0;
  p_output1[2]=0;
  p_output1[3]=0;
  p_output1[4]=0;
  p_output1[5]=0;
  p_output1[6]=t12415;
  p_output1[7]=0;
  p_output1[8]=t12570;
  p_output1[9]=t12415;
  p_output1[10]=0;
  p_output1[11]=t12570;
  p_output1[12]=t12279*var2[2] + t12279*var2[3] + (t12185 + 0.4*t11485*t12451 + 0.8*(t12247 - 1.*t11485*t12451))*var2[4];
  p_output1[13]=0;
  p_output1[14]=t12437*var2[2] + t12437*var2[3] + (0.4*t11485*t12052 + t12424 + 0.8*(-1.*t11485*t12052 + t12428))*var2[4];
  p_output1[15]=0;
  p_output1[16]=0;
  p_output1[17]=0;
  p_output1[18]=0;
  p_output1[19]=0;
  p_output1[20]=0;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var1,*var2;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 2)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "Two input(s) required (var1,var2).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var1 is wrong.");
    }
  mrows = mxGetM(prhs[1]);
  ncols = mxGetN(prhs[1]);
  if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) ||
    ( !(mrows == 7 && ncols == 1) && 
      !(mrows == 1 && ncols == 7))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var2 is wrong.");
    }

  /*  Assign pointers to each input.  */
  var1 = mxGetPr(prhs[0]);
  var2 = mxGetPr(prhs[1]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 3, (mwSize) 7, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var1,var2);


}

#else // MATLAB_MEX_FILE

#include "dJ_RightToe.hh"

namespace SymExpression
{

void dJ_RightToe_raw(double *p_output1, const double *var1,const double *var2)
{
  // Call Subroutines
  output1(p_output1, var1, var2);

}

}

#endif // MATLAB_MEX_FILE
